//
//  RWSettingViewController.m
//  Road Workout
//
//  Created by user on 14/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWSettingViewController.h"
#import "RWAppDelegate.h"
#import "RWFavoriteListViewController.h"
#import "ASIFormDataRequest.h"
#import "RWConstants.h"
#import "JSON.h"
#import "RWPlaceData.h"
#import "RWUtils.h"
#import "RWConstants.h"
#import "RWMyEventsViewController.h"
@interface RWSettingViewController ()

@end

@implementation RWSettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)
        
    
            if(!isAtLeast7)
            {
                
                UIImage* imageDone = [UIImage imageNamed:@"btn_back.png"];
                CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
                UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
                [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
                [doneBtn addTarget:self action:@selector(back:)
                  forControlEvents:UIControlEventTouchUpInside];
                
                btnBack =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
                
                
                self.navigationItem.leftBarButtonItem = btnBack;
                self.navigationItem.hidesBackButton = YES;
                
                
                
                [navBar pushNavigationItem:self.navigationItem animated:NO];
                
                navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
                
                self.navigationItem.title=@"Settings";
                
                if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
                {
                    [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                    [UIColor whiteColor], UITextAttributeTextColor,
                                                    [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                                    nil]];
                    [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
                }
                
            }
   
    self.navigationController.navigationBarHidden=YES;
	
}


-(void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];
    
}

-(IBAction)gotoFavoritePage:(id)sender
{
    if([RWUtils isConnectedToInternet])
    {
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(gotoFavoriteList) onTarget:self withObject:nil animated:TRUE];

    }
    else
    {
        
        [self getFavroiteListFromDatabase];
    }
    
}

-(void)gotoFavoriteList{

    NSString *strFavUrl = URL_FAVORITE;
    NSURL *urlFavList = [NSURL URLWithString:strFavUrl];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlFavList];
    
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(requestForFavListFail:)];
    [request setDidFinishSelector:@selector(requestForFavListSuccess:)];
    [request startSynchronous];
}


-(void)requestForFavListFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)requestForFavListSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    SBJSON *parser=[[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
    
    if(responseDict)
    {
        NSString *status= [responseDict objectForKey:@"error_code"];
        
        if (![status isEqualToString:@"0"])
        {
            NSString *strErrorMessage = [responseDict valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
        else
        {
            
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               
                               NSArray *arrPlaceData = [responseDict objectForKey:@"placeData"];
                               arrFavList = [NSMutableArray new];
                               for (int i = 0; i<arrPlaceData.count; i++) {
                                   
                                   NSDictionary *dicPlaceData = [arrPlaceData objectAtIndex:i];
                                   RWPlaceData *placeData = [RWPlaceData new];
                                   placeData.strAddress = [dicPlaceData objectForKey:@"locationaddress"];
                                   placeData.strLocationid = [dicPlaceData objectForKey:@"locationid"];
                                   placeData.strPlaceName = [dicPlaceData objectForKey:@"locationname"];
                                   placeData.strPlaceCity = [dicPlaceData objectForKey:@"locationcity"];
                                   
                                   [arrFavList addObject:placeData];
                               }
                               
                               [self performSegueWithIdentifier:@"favoritePage" sender:nil];
                           });
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"favoritePage"]) {
        RWFavoriteListViewController *favoriteListPage = (RWFavoriteListViewController*)[segue destinationViewController];
        favoriteListPage.arrFavoriteList = arrFavList;
    }
    if ([segue.identifier isEqualToString:@"MyEvents"]) {
        RWMyEventsViewController *myEventsListPage = (RWMyEventsViewController*)[segue destinationViewController];
        myEventsListPage.arrMyEventsList = arrMyEvntList;
    }
   
}


-(void)getFavroiteListFromDatabase
{
    
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutFavroiteList where favUserId = \"%@\"", [[NSUserDefaults standardUserDefaults] valueForKey:@"userid"]];
    
    @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
            arrFavList = [NSMutableArray new];
            
            while([resultSet next])
            {
                RWPlaceData *placeData = [RWPlaceData new];
                placeData.strLocationid=[resultSet stringForColumn:@"favLocationId"];
                placeData.strPlaceName=[resultSet stringForColumn:@"favLoactionName"];
                placeData.strPlaceCity=[resultSet stringForColumn:@"favCityName"];
                
                [arrFavList addObject:placeData];
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self performSegueWithIdentifier:@"favoritePage" sender:self];
    });
    
}


-(IBAction)gotoChangePasswordPage:(id)sender
{
    [self performSegueWithIdentifier:@"changePassword" sender:nil];
}
-(IBAction)logout:(id)sender
{
    [[NSUserDefaults standardUserDefaults] setValue:@"logout" forKey:@"Rememberme"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self dismissViewControllerAnimated:YES completion:NULL];
    RWAppDelegate *appdelegate = (RWAppDelegate *)[UIApplication sharedApplication].delegate;
    [appdelegate logout];
}

-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)gotoMyEvents:(id)sender {
    if([RWUtils isConnectedToInternet])
    {
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(gotoMyEventsList) onTarget:self withObject:nil animated:TRUE];
        
    }
    else
    {
        
         [[[UIAlertView alloc]initWithTitle:@"" message:@"Server not responding" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil]show];
    }
    
}
-(void)gotoMyEventsList
{
    
    NSString *strMyEventUrl = URL_MYEVENT;
    NSURL *urlMyEventList = [NSURL URLWithString:strMyEventUrl];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlMyEventList];
    
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(requestForMyEventsFail:)];
    [request setDidFinishSelector:@selector(requestForMyEventsListSuccess:)];
    [request startSynchronous];

}
-(void)requestForMyEventsFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}
-(void)requestForMyEventsListSuccess:(ASIFormDataRequest *)request
{

    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    SBJSON *parser=[[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
    
    if(responseDict)
    {
        NSString *status= [responseDict objectForKey:@"error_code"];
        
        if (![status isEqualToString:@"0"])
        {
            NSString *strErrorMessage = [responseDict valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
        else
        {
            
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               
                               NSArray *arrPlaceData = [responseDict objectForKey:@"placeData"];
                               arrMyEvntList = [[NSMutableArray alloc]init ];
                               for (int i = 0; i<arrPlaceData.count; i++)
                               {
                                   
                                   NSDictionary *dicPlaceData = [arrPlaceData objectAtIndex:i];
                                   RWPlaceData *placeData = [RWPlaceData new];
                                   placeData.address = [dicPlaceData objectForKey:@"address"];
                                   placeData.category_id = [dicPlaceData objectForKey:@"category_id"];
                                   placeData.city_id = [dicPlaceData objectForKey:@"city_id"];
                                   placeData.city_name = [dicPlaceData objectForKey:@"city_name"];
                                   placeData.continent_id = [dicPlaceData objectForKey:@"continent_id"];
                                   placeData.country_id = [dicPlaceData objectForKey:@"country_id"];
                                   placeData.description = [dicPlaceData objectForKey:@"description"];
                                   placeData.email = [dicPlaceData objectForKey:@"email"];
                                   placeData.end_date_time = [dicPlaceData objectForKey:@"end_date_time"];
                                   placeData.event_id = [dicPlaceData objectForKey:@"event_id"];
                                   placeData.event_name = [dicPlaceData objectForKey:@"event_name"];
                                   placeData.event_website = [dicPlaceData objectForKey:@"event_website"];
                                   placeData.featured_listing = [dicPlaceData objectForKey:@"featured_listing"];
                                   placeData.phone = [dicPlaceData objectForKey:@"phone"];
                                   placeData.school_id = [dicPlaceData objectForKey:@"school_id"];
                                   placeData.start_date_time = [dicPlaceData objectForKey:@"start_date_time"];
                                   placeData.state_id = [dicPlaceData objectForKey:@"state_id"];
                                   placeData.ticket_url = [dicPlaceData objectForKey:@"ticket_url"];
                                   placeData.userid = [dicPlaceData objectForKey:@"userid"];
                                   placeData.zip_code = [dicPlaceData objectForKey:@"zip_code"];
                                   placeData.state_name = [dicPlaceData objectForKey:@"state_name"];
                                   placeData.country_name = [dicPlaceData objectForKey:@"country_name"];
                                   placeData.continent_name = [dicPlaceData objectForKey:@"continent_name"];
                                   placeData.school_name = [dicPlaceData objectForKey:@"school_name"];
                                   placeData.category_name = [dicPlaceData objectForKey:@"category_name"];
                                   
                                   NSLog(@"%@",placeData.phone);
                            
                                   [arrMyEvntList addObject:placeData];
                                   
                                   
                               }
                               
                               [self performSegueWithIdentifier:@"MyEvents" sender:nil];
                           });
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }

    
}




- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (IBAction)showEmail:(id)sender {
    // Email Subject
    NSString *emailTitle = @"Email";
    // Email Content
   NSString *messageBody = @"";
    // To address
    NSArray *toRecipents = [NSArray arrayWithObject:@"admin@thebluetack.com"];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    [mc setSubject:emailTitle];
   [mc setMessageBody:messageBody isHTML:NO];
    [mc setToRecipients:toRecipents];
    
    // Present mail view controller on screen
    [self presentViewController:mc animated:YES completion:NULL];
    
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
