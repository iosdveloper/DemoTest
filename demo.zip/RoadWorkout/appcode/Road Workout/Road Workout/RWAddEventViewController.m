//
//  RWAddEventViewController.m
//  Road Workout
//
//  Created by Balkaran on 16/03/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import "RWAddEventViewController.h"
#import "RWPlaceData.h"


@interface RWAddEventViewController ()

@end

@implementation RWAddEventViewController
-(id)init{
    self = [super init];
    self.plcData=[[RWPlaceData alloc] init];
        return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImage* userLoaction = [UIImage imageNamed:@"btn_back.png"];
    CGRect imgBackframe = CGRectMake(0, 0, userLoaction.size.width, userLoaction.size.height);
    UIButton *backBtn = [[UIButton alloc] initWithFrame:imgBackframe];
    [backBtn setBackgroundImage:userLoaction forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(back:)
      forControlEvents:UIControlEventTouchUpInside];
    btnBack =[[UIBarButtonItem alloc] initWithCustomView:backBtn];
    continent_Id = @"1";
    country_Id = @"1";
    txtviewDis.placeholder = @"description";
    self.navigationItem.leftBarButtonItem = btnBack;
    self.navigationItem.hidesBackButton = YES;
    
      
    [navBar pushNavigationItem:self.navigationItem animated:NO];
    navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
    
    self.navigationItem.title=@"Add Event";

  keybordHideView.contentSize = CGSizeMake(keybordHideView.frame.size.width, 1200);
    NSString *strContinet = URL_ADD_EVENT ;
    url=[[NSURL alloc]initWithString:strContinet];
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

     txtSchool.text = [prefs stringForKey:@"SchoolName"];
     school_ID = [prefs stringForKey:@"SchoolId"];
    txtviewDis.clipsToBounds = YES;
    txtviewDis.layer.cornerRadius = 4.0f;
    txtviewDis.layer.borderColor = [UIColor lightGrayColor].CGColor;
    txtviewDis.layer.borderWidth = 0.5;
    btnSubmit.layer.cornerRadius = 4.0f;
    NSLog(@"%@",self.plcData.event_name);
    NSLog(@"%@",self.plcData);
    txtEventName.text=self.plcData.event_name;
    txtCategoryName.text=self.plcData.category_name;
    txtviewDis.text=self.plcData.description;
    txtEmailId.text=self.plcData.email;
    txtPhoneNo.text=self.plcData.phone;
    txtWebUrl.text=self.plcData.event_website;
    txtTicketUrl.text=self.plcData.ticket_url;
    txtStartDateTime.text=self.plcData.start_date_time;
    txtEndDateTime.text=self.plcData.end_date_time;
    txtEventAddress.text=self.plcData.address;
    txtSchool.text=self.plcData.school_name;
    txtState.text=self.plcData.state_name;
    txtCity.text=self.plcData.city_name;
    txtZipCode.text=self.plcData.zip_code;
    txtContinenet.text=self.plcData.continent_name;
    txtCountry.text=self.plcData.country_name;
    event_id= self.plcData.event_id;
    categories_ID=self.plcData.category_id;
    state_Id=self.plcData.state_id;
    city_ID=self.plcData.city_id;
    school_ID=self.plcData.school_id;
    if (![txtEventName.text isEqualToString: @""]) {
        txtEventName.enabled=NO;
        self.navigationItem.title=@"Edit Event";
       
    }
    if (![txtSchool.text isEqualToString:@"" ]) {
        txtSchool.enabled=NO;
        btnSchool.userInteractionEnabled=NO;
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)submitBtnClick:(id)sender
{
 
    BOOL isValid = YES;
    
    if(!txtEventName.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter Event name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtCategoryName.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter Category name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if (![Validate isValidEmailId:txtEmailId.text])
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter valid email address" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    
   else if (!txtSchool.text.length > 0)
  {
       [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter School name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
       isValid = NO;
    }
    else if(!txtPhoneNo.text.length > 0)
    {
        isValid = NO;
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter phone number" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
    else if(!txtCity.text.length > 0)
    {
        isValid = NO;
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter city name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
    else if(!txtState.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter state name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtCountry.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter country name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtContinenet.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter Continenet name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }

    
    
    
    if(isValid)
    {
        [txtEventName resignFirstResponder];
        [txtCategoryName resignFirstResponder];
        [txtPhoneNo resignFirstResponder];
        [txtCity resignFirstResponder];
        [txtState resignFirstResponder];
        [txtCountry resignFirstResponder];
        [txtContinenet resignFirstResponder];
        [txtEmailId resignFirstResponder];
        [txtWebUrl resignFirstResponder];
        [txtTicketUrl resignFirstResponder];
        [txtStartDateTime resignFirstResponder];
        [txtEndDateTime resignFirstResponder];
        [txtEventAddress resignFirstResponder];
        [txtZipCode resignFirstResponder];
        [txtviewDis resignFirstResponder];
        [txtSchool resignFirstResponder];
        
        if([RWUtils isConnectedToInternet])
        {
            NSString *s = txtPhoneNo.text;
            NSString *s1= [s stringByReplacingOccurrencesOfString:@" " withString:@""];
            NSString *s2 = [s1 stringByReplacingOccurrencesOfString:@"(" withString:@""];
            NSString *s3 = [s2 stringByReplacingOccurrencesOfString:@")" withString:@""];
            strPoneNo = [s3 stringByReplacingOccurrencesOfString:@"-" withString:@""];
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            if (self.plcData.event_id ==0) {
                [HUD showWhileExecuting:@selector(requestForAddEvent:) onTarget:self withObject:nil animated:TRUE];
                
            }
            else
            {
                
            [HUD showWhileExecuting:@selector(requestForEditEvent:) onTarget:self withObject:nil animated:TRUE];
            
            }
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }
    
    
    

}
#pragma mark - ADD Event API

-(void)requestForAddEvent:(id)sender
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:url];
  
    [request setPostValue:txtEventName.text forKey:@"event_name"];
     [request setPostValue:categories_ID forKey:@"category_id"];
    [request setPostValue:txtviewDis.text forKey:@"description"];
    [request setPostValue:txtEmailId.text forKey:@"email"];
    [request setPostValue:strPoneNo forKey:@"phone"];
    [request setPostValue:txtWebUrl.text forKey:@"website_url"];
    [request setPostValue:txtTicketUrl.text forKey:@"ticket_url"];
    [request setPostValue:txtStartDateTime.text forKey:@"start_date_time"];
    [request setPostValue:txtEndDateTime.text forKey:@"end_date_time"];
    [request setPostValue:txtEventAddress.text forKey:@"address"];
    [request setPostValue:city_ID forKey:@"city"];
    [request setPostValue:state_Id forKey:@"state"];
    [request setPostValue:txtZipCode.text forKey:@"zip_code"];
    [request setPostValue:country_Id forKey:@"country"];
    [request setPostValue:continent_Id forKey:@"continent"];
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setPostValue:@"0" forKey:@"featured_listing"];
    [request setPostValue:school_ID forKey:@"school_id"];
    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(AddEventFail:)];
    [request setDidFinishSelector:@selector(AddEventSuccess:)];
    [request startSynchronous];
    
}

-(void)AddEventFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)AddEventSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Event Added Successfully" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
            
         
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}
/////////////////////////////
#pragma mark - Edit Event API

-(void)requestForEditEvent:(id)sender
{
    NSString *strEdit= URL_EDIT_MYEVENTS;
    url= [[NSURL alloc]initWithString:strEdit];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:url];
    
    [request setPostValue:txtEventName.text forKey:@"event_name"];
    [request setPostValue:categories_ID forKey:@"category_id"];
    [request setPostValue:txtviewDis.text forKey:@"description"];
    [request setPostValue:txtEmailId.text forKey:@"email"];
    [request setPostValue:strPoneNo forKey:@"phone"];
    [request setPostValue:txtWebUrl.text forKey:@"website_url"];
    [request setPostValue:txtTicketUrl.text forKey:@"ticket_url"];
    [request setPostValue:txtStartDateTime.text forKey:@"start_date_time"];
    [request setPostValue:txtEndDateTime.text forKey:@"end_date_time"];
    [request setPostValue:txtEventAddress.text forKey:@"address"];
    [request setPostValue:city_ID forKey:@"city"];
    [request setPostValue:state_Id forKey:@"state"];
    [request setPostValue:txtZipCode.text forKey:@"zip_code"];
    [request setPostValue:country_Id forKey:@"country"];
    [request setPostValue:continent_Id forKey:@"continent"];
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setPostValue:@"0" forKey:@"featured_listing"];
    [request setPostValue:school_ID forKey:@"school_id"];
    [request setPostValue:event_id forKey:@"event_id"];
    //[request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"event_id"] forKey:@"event_id"];


    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(EditEventFail:)];
    [request setDidFinishSelector:@selector(EditEventSuccess:)];
    [request startSynchronous];
    
}

-(void)EditEventFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)EditEventSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            [[[UIAlertView alloc] initWithTitle:@"" message:@"Event Updated Successfully" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
            
            [self.navigationController popToViewController:[[self.navigationController viewControllers] objectAtIndex:2] animated:YES];

        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}







-(IBAction)selectCompletionDate:(id)sender
{
    [self.view endEditing:YES];
    if (!datePickerView) {
        
           UIButton *btn =(UIButton *)sender;
        if(btn.tag ==1){
            startDate =YES;
        }
        else{
            startDate = NO;
        }
        
        datePickerView = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height, self.view.bounds.size.width, 200)];
        datePickerView.backgroundColor = [UIColor whiteColor];
        datePicker = [[UIDatePicker alloc]initWithFrame:CGRectMake(0, 44, datePickerView.bounds.size.width, 156)];
        datePicker.datePickerMode = UIDatePickerModeDateAndTime;
       
        
        [datePicker setMinimumDate:[NSDate date]];
        [datePickerView addSubview:datePicker];
        
        UIToolbar *bar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, datePickerView.bounds.size.width, 44)];
        //bar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        if ([bar respondsToSelector:@selector(barTintColor)]) {
            bar.barTintColor = [UIColor lightGrayColor];
        }else
        {
            bar.tintColor = [UIColor darkGrayColor];
        }
        
        UIBarButtonItem *cancel = [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancel:)];
        cancel.tintColor = [UIColor whiteColor];
        
        UIBarButtonItem *done = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(done:)];
        UIBarButtonItem *flexi = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        done.tintColor = [UIColor whiteColor];
                    bar.items = [NSArray arrayWithObjects:cancel,flexi,done, nil];
        [datePickerView addSubview:bar];
        [self.view addSubview:datePickerView];
    }
    if (datePickerView.frame.origin.y>=self.view.bounds.size.height) {
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect = datePickerView.frame;
            rect.origin.y-=200;
            datePickerView.frame = rect;
        }];
    }
}


-(void)cancel:(id)sender
{
    [UIView animateWithDuration:0.5 animations:^{
        CGRect rect = datePickerView.frame;
        rect.origin.y += 200;
        datePickerView.frame = rect;
    } completion:^(BOOL finished) {
        [datePicker removeFromSuperview];
        [datePickerView removeFromSuperview];
        datePicker = nil;
        datePickerView = nil;
    }];
}

-(void)done:(id)sender
{
   
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd hh:mm"];
    
    NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
  
    if(startDate){
        txtStartDateTime.text = strDate;
        
        date1 = datePicker.date;
    }
    else
    {
        date2 = datePicker.date;
        if ([date1 compare:date2] == NSOrderedDescending) {
          [[[UIAlertView alloc] initWithTitle:@"" message:@"end date can't be earlier then start date " delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
               txtEndDateTime.text =@"";
        } else if ([date1 compare:date2] == NSOrderedAscending) {
            NSLog(@"date2 is earlier than date2");
            
           txtEndDateTime.text =strDate;
        } else {
            [[[UIAlertView alloc] initWithTitle:@"" message:@"select start date first " delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        }
        
    }
    
    
   [UIView animateWithDuration:0.5 animations:^{
        CGRect rect = datePickerView.frame;
        rect.origin.y += 200;
        datePickerView.frame = rect;
    } completion:^(BOOL finished) {
        [datePicker removeFromSuperview];
        [datePickerView removeFromSuperview];
        datePicker = nil;
        datePickerView = nil;
           }];
}

#pragma mark - IBAction Methods

-(IBAction)btnSchoolDidClick:(id)sender{
    [txtEventName resignFirstResponder];
    [txtviewDis resignFirstResponder];
    [txtEmailId resignFirstResponder];
    [txtPhoneNo resignFirstResponder];
    [txtWebUrl resignFirstResponder];
    [txtTicketUrl resignFirstResponder];
    [txtEventAddress resignFirstResponder];
    [txtZipCode resignFirstResponder];
    chekBtnClik = @"btnsclool";
    [self performSegueWithIdentifier:@"segue_category_Sclool" sender:nil];
}


-(IBAction)btnCategoryDidClick:(id)sender{
    [txtEventName resignFirstResponder];
    [txtviewDis resignFirstResponder];
    [txtEmailId resignFirstResponder];
    [txtPhoneNo resignFirstResponder];
    [txtWebUrl resignFirstResponder];
    [txtTicketUrl resignFirstResponder];
    [txtEventAddress resignFirstResponder];
    [txtZipCode resignFirstResponder];
    chekBtnClik = @"btncatgories";
     [self performSegueWithIdentifier:@"segue_category_Sclool" sender:nil];
}

-(IBAction)btnContinenetDidClick:(id)sender{
    [txtEventName resignFirstResponder];
    [txtviewDis resignFirstResponder];
    [txtEmailId resignFirstResponder];
    [txtPhoneNo resignFirstResponder];
    [txtWebUrl resignFirstResponder];
    [txtTicketUrl resignFirstResponder];
    [txtEventAddress resignFirstResponder];
    [txtZipCode resignFirstResponder];
    txtContinenet.text = nil;
    txtCountry.text = nil;
    txtState.text = nil;
    txtCity.text = nil;
    [self performSegueWithIdentifier:@"segue_Continent" sender:nil];
    
    
    
}
-(IBAction)btnCountryDidClick:(id)sender{
    [txtEventName resignFirstResponder];
    [txtviewDis resignFirstResponder];
    [txtEmailId resignFirstResponder];
    [txtPhoneNo resignFirstResponder];
    [txtWebUrl resignFirstResponder];
    [txtTicketUrl resignFirstResponder];
    [txtEventAddress resignFirstResponder];
    [txtZipCode resignFirstResponder];
    BOOL isCheck = YES;
  
    if(!txtContinenet.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please select Continenet First " delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
       isCheck= NO;
    }
    
     else if(isCheck) {
         
         txtCountry.text = nil;
         txtState.text = nil;
         txtCity.text = nil;
        [self performSegueWithIdentifier:@"segue_Continent" sender:nil];
    }

    
    
}


-(IBAction)btnStateDidClick:(id)sender{
    [txtEventName resignFirstResponder];
    [txtviewDis resignFirstResponder];
    [txtEmailId resignFirstResponder];
    [txtPhoneNo resignFirstResponder];
    [txtWebUrl resignFirstResponder];
    [txtTicketUrl resignFirstResponder];
    [txtEventAddress resignFirstResponder];
    [txtZipCode resignFirstResponder];
     BOOL isCheck =YES;
    if(!txtCountry.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please Select Country First" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
          isCheck = NO;
    }
    else if(isCheck) {
        
        txtState.text = nil;
        txtCity.text = nil;
        [self performSegueWithIdentifier:@"segue_Continent" sender:nil];
    }
    
}

-(IBAction)btnCityDidClick:(id)sender{
    BOOL isCheck = YES;
    [txtSchool resignFirstResponder];
    [txtCategoryName resignFirstResponder];
    [txtCity resignFirstResponder];
    [txtState resignFirstResponder];
    [txtContinenet resignFirstResponder];
    [txtCountry resignFirstResponder];
    if(!txtState.text.length > 0)
   {
       [[[UIAlertView alloc] initWithTitle:@"" message:@"please Select province(state) First" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
         isCheck = NO;
   }
   else if(isCheck) {
       
       
       txtCity.text = nil;
       [self performSegueWithIdentifier:@"segue_Continent" sender:nil];
   }
}



#pragma mark - NAVIGATION

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
  
    if ([segue.identifier isEqualToString:@"segue_Continent"]) {
       RWAddEventInformationViewController *obC = (RWAddEventInformationViewController*)[segue destinationViewController];
        obC.delegate = self;
        if(!txtContinenet.text.length > 0 && !txtCountry.text.length > 0 && !txtState.text.length >0&& !txtCity.text.length > 0 )
        {
         obC.yourTitle= @"Continent";
        }else if(txtContinenet.text.length > 0 && !txtCountry.text.length > 0 && !txtState.text.length >0&& !txtCity.text.length > 0 )
        {
             obC.continet_id = continent_Id;
             obC.yourTitle =@"Country";
        }
        else if(txtContinenet.text.length > 0 && txtCountry.text.length > 0 && !txtState.text.length >0&& !txtCity.text.length > 0  )
        {
             obC.yourTitle =@"State";
            obC.continet_id = continent_Id;
            obC.country_id = country_Id;
        }
        else if(txtContinenet.text.length > 0 && txtCountry.text.length > 0 && txtState.text.length >0&& !txtCity.text.length > 0  )
        {
            obC.yourTitle =@"City";
            obC.country_id = country_Id;
            obC.state_id = state_Id;
        }
     }
     if ([segue.identifier isEqualToString:@"segue_category_Sclool"])
     {
          RWCategoriesListViewController*obCatandSchool = (RWCategoriesListViewController*)[segue destinationViewController];
          obCatandSchool.delegate = self;
         if([chekBtnClik isEqualToString:@"btnsclool"]){
             obCatandSchool.yourTitle =@"School";
         }else{
            obCatandSchool.yourTitle =@"Categories";
         }
     }
}

#pragma mark - TextField Delegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    int length = [self getLength:txtPhoneNo.text];
    //NSLog(@"Length  =  %d ",length);
    
    if(length == 10)
    {
        if(range.length == 0)
            return NO;
    }
    
    if(length == 3)
    {
        NSString *num = [self formatNumber:textField.text];
        txtPhoneNo.text = [NSString stringWithFormat:@"(%@) ",num];
        if(range.length > 0)
            txtPhoneNo.text = [NSString stringWithFormat:@"%@",[num substringToIndex:3]];
    }
    else if(length == 6)
    {
        NSString *num = [self formatNumber:textField.text];
        //NSLog(@"%@",[num  substringToIndex:3]);
        //NSLog(@"%@",[num substringFromIndex:3]);
        txtPhoneNo.text = [NSString stringWithFormat:@"(%@) %@-",[num  substringToIndex:3],[num substringFromIndex:3]];
        if(range.length > 0)
            txtPhoneNo.text = [NSString stringWithFormat:@"(%@) %@",[num substringToIndex:3],[num substringFromIndex:3]];
    }
    
    return YES;
}

-(NSString*)formatNumber:(NSString*)mobileNumber
{
    
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    NSLog(@"%@", mobileNumber);
    
    int length = [mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
        NSLog(@"%@", mobileNumber);
        
    }
    
    
    return mobileNumber;
}


-(int)getLength:(NSString*)mobileNumber
{
    
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    int length = [mobileNumber length];
    
    return length;
    
    
}






#pragma -AddEventInfoDelegate Methods
-(void)setContinentId:(NSString *)continent_id name:(NSString *)continent_name{
  
    continent_Id = continent_id;
    txtContinenet.text = continent_name;
    
}

-(void)setCountryId:(NSString *)country_id name:(NSString *)country_name{
  
    txtCountry.text = country_name;
    country_Id = country_id;
    
}

-(void)setStateId:(NSString *)state_id name:(NSString *)state_name{
   
    txtState.text = state_name;
    state_Id = state_id;
    
}
-(void)setCityId:(NSString *)city_id name:(NSString *)city_name;{
    txtCity.text = city_name;
    city_ID = city_id;
 
}

#pragma -AddCategoriesSchoolInfoDelegate Methods
-(void)setCategoriesId:(NSString *)categories_id name:(NSString *)categories_name{
   
    txtCategoryName.text = categories_name;
    categories_ID = categories_id;

    
}
-(void)setSchoolId:(NSString *)school_id name:(NSString *)School_name{
    txtSchool.text = School_name;
    school_ID = school_id;
 
}
#pragma -TextField Delegate Methods
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    [txtSchool resignFirstResponder];
    [txtCategoryName resignFirstResponder];
    [txtCity resignFirstResponder];
    [txtState resignFirstResponder];
    [txtContinenet resignFirstResponder];
    [txtCountry resignFirstResponder];
    
    return  YES;
 }
- (IBAction)SubmitButton1:(id)sender {
    [self submitBtnClick:nil];
}

- (IBAction)SubmitButton2:(id)sender {
    [self submitBtnClick:nil];
}
@end
