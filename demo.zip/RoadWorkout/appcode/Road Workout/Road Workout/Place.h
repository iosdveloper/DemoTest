//
//  Place.h
//
//  Created by Sugartin on 11/16/2012.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Place : NSObject {


	double latitude;
	double longitude;
}


@property (nonatomic) double latitude;
@property (nonatomic) double longitude;

@end
