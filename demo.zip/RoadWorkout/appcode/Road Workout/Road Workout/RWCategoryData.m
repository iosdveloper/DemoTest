//
//  RWCategoryData.m
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWCategoryData.h"

@implementation RWCategoryData
@synthesize strCategoryid,strCategoryName,strStatus,strTotalPlaces;

@end
