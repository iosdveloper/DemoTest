//
//  RWMapViewController.m
//  Road Workout
//
//  Created by user on 15/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWMapViewController.h"
#import "RWUtils.h"

@interface RWMapViewController ()

@end

@implementation RWMapViewController
@synthesize arrLocationList,strLati,strLongi,strMPAddress;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillDisappear:(BOOL)animated
{
    viewRange.hidden=YES;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden=YES;
    NSString *strLocationList = URL_LOCATION_LIST;
    urlLocationList=[NSURL URLWithString:strLocationList];
    NSString *strLocationDetals = URL_LOCATION_DETAIL;
    urlLocationDetail=[NSURL URLWithString:strLocationDetals];
    routes = [[NSMutableArray alloc]init];
    isLeftToRight=YES;
    arrClassData = [[NSMutableArray alloc]init];
    arrSearchData = [[NSMutableArray alloc] init];
    
    strMpLatitude = strLati;
    strMpLongitude = strLongi;
    strRange=@"30";
    isSelectRange=NO;
    locationList= [[NSMutableArray alloc]init];
    locationList=arrLocationList;
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)
    {
        
        UIImage* userLoaction = [UIImage imageNamed:@"btn_setting.png"];
        CGRect imgBackframe = CGRectMake(0, 0, userLoaction.size.width, userLoaction.size.height);
        UIButton *backBtn = [[UIButton alloc] initWithFrame:imgBackframe];
        [backBtn setBackgroundImage:userLoaction forState:UIControlStateNormal];
        [backBtn addTarget:self action:@selector(setting:)
          forControlEvents:UIControlEventTouchUpInside];
        [backBtn setShowsTouchWhenHighlighted:YES];
        
        
        UIImage* imageDone = [UIImage imageNamed:@"btn_setting1.png"];
        CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
        UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
        [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
        [doneBtn addTarget:self action:@selector(gotoSettingPage:)
          forControlEvents:UIControlEventTouchUpInside];
        
        btnRange =[[UIBarButtonItem alloc] initWithCustomView:backBtn];
        btnSetting =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
        
        self.navigationItem.leftBarButtonItem = btnRange;
        self.navigationItem.hidesBackButton = YES;
        
        self.navigationItem.rightBarButtonItem = btnSetting;
        
        [navBar pushNavigationItem:self.navigationItem animated:NO];
        navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
        
        self.navigationItem.title=@"Locations";
        
        
        if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
        {
            [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                            [UIColor whiteColor], UITextAttributeTextColor,
                                            [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                            nil]];
            [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
        }
        
    }
    if(IS_IPHONE_5)
    {
        viewRange.frame=CGRectMake(-160, 64, 160, 566);
    }
    else
    {
        viewRange.frame=CGRectMake(-160, 64, 160, 376);
    }
    [self.view addSubview:viewRange];
    viewRange.hidden=YES;
    viewRange.layer.cornerRadius=10.0;
    tblRange.layer.cornerRadius=10.0;
    viewRange.layer.borderWidth=1.0;
    viewRange.layer.borderColor=[UIColor whiteColor].CGColor;
    
   
    arrRangeAdddress = [[NSArray alloc]initWithObjects:@"1",@"2",@"5",@"10",@"25",@">25",nil];
    arrRangeCity = [[NSArray alloc]initWithObjects:@"50",@"100",@"200",@"300",@"400",@"500",@">500",nil];
    arrRangeCountry = [[NSArray alloc]initWithObjects:@"200",@"400",@"600",@"800",@"1000",@"2000",@">2000", nil];
    
    routeView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, mapLocation.frame.size.width, mapLocation.frame.size.height)];
    routeView.userInteractionEnabled = NO;
    [mapLocation addSubview:routeView];
    
    lineColor = [UIColor blueColor];
    
    [segMapControl addTarget:self
                      action:@selector(changeMapMode:)
               forControlEvents:UIControlEventValueChanged];
    isMap=YES;
  
    [self mapUpdate];
}



-(void)changeMapMode:(id)sender
{
  
        UISegmentedControl *segmentedControl = (UISegmentedControl *)sender;
        if (segmentedControl.selectedSegmentIndex==0) {
            isMap=YES;
        }
        else
        {
            isMap=NO;
        }
    [self mapUpdate];
}

-(void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];
}


-(void)mapUpdate
{
    mapLocation.delegate=self;
	if (isMap) {
        mapLocation.mapType=MKMapTypeStandard;
    }
    else{
        mapLocation.mapType=MKMapTypeSatellite;
    }
    
    
	NSMutableArray* annotations=[[NSMutableArray alloc] init];
    
    for (RWPlaceData *place in locationList)
    {
        
        CLLocationCoordinate2D theCoordinate;
        theCoordinate.latitude = [place.strPlaceLatitude floatValue];
        theCoordinate.longitude = [place.strPlaceLongitude floatValue];
        RWAnnotationData* myAnnotation=[[RWAnnotationData alloc] init];
        myAnnotation.coordinate=theCoordinate;
        myAnnotation.title=place.strPlaceName;
        myAnnotation.subtitle=place.strAddress;
        myAnnotation.Loactionid=place.strLocationid;
        myAnnotation.identity=[place.strIsFavAdded doubleValue];
        [annotations addObject: myAnnotation];
    }
    [mapLocation addAnnotations:annotations];
   
    MKMapRect flyTo = MKMapRectNull;
	for (id <MKAnnotation> annotation in annotations) {
		NSLog(@"fly to on");
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
        if (MKMapRectIsNull(flyTo)) {
            flyTo = pointRect;
        }
        else
        {
            flyTo = MKMapRectUnion(flyTo, pointRect);
        }
        [mapLocation selectAnnotation:annotation animated:YES];

    }
    mapLocation.visibleMapRect = flyTo;

}





-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
    MKPinAnnotationView *pinView = nil;
   
    if([(RWAnnotationData*)annotation identity] == 1)
    {
        if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
                                      initWithAnnotation:annotation reuseIdentifier:@"com.invasivecode.pin"];
        pinView.pinColor =MKPinAnnotationColorGreen;
        pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
        UIButton* rightButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        rightButton.tag=[[(RWAnnotationData*)annotation Loactionid] intValue];
        [rightButton addTarget:self action:@selector(gotoLocationDetails:) forControlEvents:UIControlEventTouchUpInside];
        pinView.rightCalloutAccessoryView = rightButton;
    }
    else
    {
		pinView = (MKPinAnnotationView *)[mapLocation dequeueReusableAnnotationViewWithIdentifier:@"com.invasivecode.pin"];
		if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
										  initWithAnnotation:annotation reuseIdentifier:@"com.invasivecode.pin"];
        pinView.pinColor =MKPinAnnotationColorRed ;
		pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
        UIButton* rightButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        rightButton.tag=[[(RWAnnotationData*)annotation Loactionid] intValue];
        [rightButton addTarget:self action:@selector(gotoLocationDetails:) forControlEvents:UIControlEventTouchUpInside];
        pinView.rightCalloutAccessoryView = rightButton;
    }
	return pinView;
}

-(void)gotoLocationDetails:(UIButton *)sender
{
    strLocationId=[NSString stringWithFormat:@"%ld",(long)sender.tag];
       if([RWUtils isConnectedToInternet])
    {
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(gotoLocationDetail) onTarget:self withObject:nil animated:TRUE];
    }
    else
    {
        [self getLocationDetailsFromDatabase];
    }

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
        return [arrRange count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
        static NSString *cellIdentifier = @"RangeCell";
        UITableViewCell   *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                          reuseIdentifier:cellIdentifier];
        }
   
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(isAtLeast7)
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
        cell.backgroundColor=[UIColor clearColor];
    
    NSInteger dtnce=[[arrRange objectAtIndex:indexPath.row] integerValue];
    if (dtnce==1) {
        cell.textLabel.text=[NSString stringWithFormat:@"%ld mile",(long)dtnce];
    }
    else if(1<dtnce && dtnce<=2000)
    {
        cell.textLabel.text=[NSString stringWithFormat:@"%ld miles",(long)dtnce];
    }
    else
    {
        cell.textLabel.text=[NSString stringWithFormat:@"%@ miles",[arrRange objectAtIndex:indexPath.row]];
    }
    
        cell.textLabel.textColor = [UIColor whiteColor];
        [cell.textLabel setFrame:CGRectMake(30, 8, 80, 36)];
        return cell;
  
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    isSelectRange=YES;
    strRange=[arrRange objectAtIndex:indexPath.row];
    
    if([strRange isEqualToString:@">2000"])
    {
        strRange=@"10000";
    }
    if([strRange isEqualToString:@">500"])
    {
        strRange=@"10000";
    }
    if([strRange isEqualToString:@">25"])
    {
        strRange=@"30";
    }
    
    CGRect frame = viewRange.frame;
    frame.origin.x = -160;
    isLeftToRight=YES;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.2];
  
    viewRange.frame = CGRectMake(-160, viewRange.frame.origin.y, viewRange.frame.size.width, viewRange.frame.size.height);
    [UIView commitAnimations];
    
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(getLocationList) onTarget:self withObject:nil animated:TRUE];
}


-(void)getLocationList
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationList];
    
    if(address==1)
    {
        [request setPostValue:strMPAddress forKey:@"city"];
        [request setPostValue:strRange forKey:@"range"];
    }
    else if(address==2)
    {
        [request setPostValue:strMPAddress forKey:@"state"];
        [request setPostValue:strRange forKey:@"range"];
        
    }
    else if(address==3)
    {
        [request setPostValue:strMPAddress forKey:@"country"];
        [request setPostValue:strRange forKey:@"range"];
        
    }
    else
    {
        [request setPostValue:strRange forKey:@"range"];
    }

    [request setPostValue:strMpLatitude forKey:@"latitude"];
    [request setPostValue:strMpLongitude forKey:@"longitude"];
    [request setPostValue:strCategoryId forKey:@"categoryid"];
    
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getLocationListFail:)];
    [request setDidFinishSelector:@selector(getLocationListSuccess:)];
    [request startSynchronous];
    
}

-(void)getLocationListFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getLocationListSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            NSMutableArray *arrCategoryList=[responseData valueForKey:@"placesList"];
        
                               
                               locationList = [[NSMutableArray alloc]init];
                               for (int i=0; i<arrCategoryList.count; i++) {
                                   RWPlaceData *placeData=[[RWPlaceData alloc]init];
                                   placeData.strLocationid=[[arrCategoryList objectAtIndex:i] valueForKey:@"locationid"];
                                   placeData.strAddress=[[arrCategoryList objectAtIndex:i] valueForKey:@"address"];
                                   placeData.strDistance=[[[arrCategoryList objectAtIndex:i] valueForKey:@"distance"] integerValue];
                                   placeData.strPlaceName=[[arrCategoryList objectAtIndex:i] valueForKey:@"name"];
                                   placeData.strPlaceLatitude=[[arrCategoryList objectAtIndex:i] valueForKey:@"latitude"];
                                   placeData.strPlaceLongitude=[[arrCategoryList objectAtIndex:i] valueForKey:@"longitude"];
                                   placeData.strIsFavAdded = [NSString stringWithFormat:@"%@", [[arrCategoryList objectAtIndex:i] valueForKey:@"isfavorite"]];
                                   
                                   if (isSelectRange)
                                   {
                                       if (placeData.strDistance<=[strRange integerValue]) {
                                           [locationList addObject:placeData];                                       }
                                   }
                                   else
                                   {
                                      [locationList addObject:placeData];
                                       
                                   }

                                   
                                 
                        }
                               dispatch_async(dispatch_get_main_queue(), ^
                                              {
                                                  [self mapUpdate];
                                              });

            
            isSelectRange=NO;
        }
        else
        {
            strMpLatitude = strLati;
            strMpLongitude = strLongi;
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [searchBarLocation resignFirstResponder];
}

-(void)searchViewShouldBeginEditing:(UISearchBar *)searchBar
{
    
}



- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [self searchViewShouldBeginEditing:searchBar];
    
    for(id subview in [searchBar subviews])
    {
        if ([subview isKindOfClass:[UIButton class]]) {
            [subview setEnabled:YES];
        }
    }
    return YES;
}

-(void)searchViewShouldSearchButtonClick:(UISearchBar *)searchBar searchText:(NSString *)searchText
{

        if(searchText.length == 0)
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [searchBarLocation resignFirstResponder];
                           });
        }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [self.searchDisplayController.searchBar setText:@""];
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [searchBarLocation resignFirstResponder];
                   });
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if(searchBarLocation.text.length == 0)
    {
        [searchBarLocation resignFirstResponder];
    }
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    if ([segue.identifier isEqualToString:@"LocationDetails"])
    {
        RWLocationDetailViewController *details=(RWLocationDetailViewController*)[segue destinationViewController];
        details.locationDetail=locationDetail;
    }
   
}


-(IBAction)setting:(id)sender{
    
    if (address==1) {
        arrRange=arrRangeAdddress;
    }
    else if (address==2 || address == 3)
    {
        arrRange=arrRangeCountry;
    }
    else{
        arrRange=arrRangeAdddress;
    }
    
        viewRange.hidden=NO;
    CGRect frame = viewRange.frame;
    frame.origin.x = (isLeftToRight) ? 0 : -160;
    
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewRange.frame = frame;
    [UIView commitAnimations];
    
    if (isLeftToRight) {
        isLeftToRight=NO;
    }
    else{
        isLeftToRight=YES;
    }
    [tblRange reloadData];
    
}

-(void)gotoLocationDetail
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationDetail];
    [request setPostValue:strLocationId forKey:@"locationid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getLocationDetailsFail:)];
    [request setDidFinishSelector:@selector(getLocationDetailsSuccess:)];
    [request startSynchronous];
    
}

-(void)getLocationDetailsFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getLocationDetailsSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            NSMutableDictionary *arrCategoryList=[responseData valueForKey:@"location"];
            
            locationDetail=[[RWPlaceDetail alloc]init];
            locationDetail.strLocationid=[arrCategoryList valueForKey:@"locationid"];
            locationDetail.strName=[arrCategoryList valueForKey:@"name"];
            locationDetail.strGenre=[arrCategoryList  valueForKey:@"genre"];
            locationDetail.strDescription=[arrCategoryList  valueForKey:@"description"];
            locationDetail.strWebsite=[arrCategoryList  valueForKey:@"website"];
            locationDetail.strPhone=[arrCategoryList valueForKey:@"phone"];
            locationDetail.strZipcode=[arrCategoryList valueForKey:@"zipcode"];
            locationDetail.strAddress=[arrCategoryList valueForKey:@"address"];
            locationDetail.strCity=[arrCategoryList  valueForKey:@"city"];
            locationDetail.strState=[arrCategoryList  valueForKey:@"state"];
            locationDetail.strContinent=[arrCategoryList valueForKey:@"continent"];
            locationDetail.strCountry=[arrCategoryList  valueForKey:@"country"];
            locationDetail.strLatitude=[arrCategoryList  valueForKey:@"latitude"];
            locationDetail.strLongitude=[arrCategoryList valueForKey:@"longitude"];
            locationDetail.strYelpLink=[arrCategoryList valueForKey:@"yelp_link"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self performSegueWithIdentifier:@"LocationDetails" sender:self];
            });
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}


-(void)getLocationDetailsFromDatabase
{
    
    
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locId = \"%@\"", strLocationId];
    
    @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
            
            while([resultSet next])
            {
                locationDetail=[[RWPlaceDetail alloc]init];
                locationDetail.strLocationid=[resultSet stringForColumn:@"locId"];
                locationDetail.strName=[resultSet stringForColumn:@"locName"];
                locationDetail.strGenre=[resultSet stringForColumn:@"locCategoryName"];
                locationDetail.strDescription=[resultSet stringForColumn:@"locDescription"];
                locationDetail.strWebsite=[resultSet stringForColumn:@"locWebsite"];
                locationDetail.strPhone=[resultSet stringForColumn:@"locPhone"];
                locationDetail.strZipcode=[resultSet stringForColumn:@"locZipcode"];
                locationDetail.strAddress=[resultSet stringForColumn:@"locAddress"];
                locationDetail.strCity=[resultSet stringForColumn:@"locCity"];
                locationDetail.strState=[resultSet stringForColumn:@"locState"];
                locationDetail.strContinent=[resultSet stringForColumn:@"locContinent"];
                locationDetail.strCountry=[resultSet stringForColumn:@"locCountry"];
                locationDetail.strLatitude=[resultSet stringForColumn:@"locLatitude"];
                locationDetail.strLongitude=[resultSet stringForColumn:@"locLongitude"];
                locationDetail.strYelpLink=[resultSet stringForColumn:@"locYelpLink"];
                
                
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self performSegueWithIdentifier:@"LocationDetails" sender:self];
    });
    
    
    
    
    
}


-(IBAction)gotoSettingPage:(id)sender
{
    [self performSegueWithIdentifier:@"gotoSettingPageFromMap" sender:nil];
}

-(IBAction)locationList:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
    viewRange.hidden=YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
