//
//  RWPlaceCell.h
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWPlaceCell : UITableViewCell
@property (nonatomic, retain)IBOutlet UILabel *lblAddress;
@property (nonatomic, retain)IBOutlet UILabel *lblDistance;
@property (nonatomic, strong)IBOutlet UILabel*lblStartDate;
@property (nonatomic, strong)IBOutlet UILabel *lblEndDate;
@property (nonatomic,strong)IBOutlet UILabel *lblCatName;

@property (nonatomic, retain)IBOutlet UIButton *btnFavorite;

@end
