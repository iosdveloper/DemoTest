//
//  RWChangePasswordViewController.m
//  Road Workout
//
//  Created by user on 14/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWChangePasswordViewController.h"

@interface RWChangePasswordViewController ()

@end

@implementation RWChangePasswordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    btnSubmit.layer.cornerRadius = 4.0f;
    btnSubmit.layer.masksToBounds=YES;
    
    self.navigationController.navigationBarHidden=YES;
    NSString *strChangePassword = URL_CHANGE_PASSWORD;
    urlChangePassword=[NSURL URLWithString:strChangePassword];
    
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)
        
        
        if(!isAtLeast7)
        {
            
            UIImage* imageDone = [UIImage imageNamed:@"btn_back.png"];
            CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
            UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
            [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
            [doneBtn addTarget:self action:@selector(back:)
              forControlEvents:UIControlEventTouchUpInside];
            
            btnBack =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
            
            
            self.navigationItem.leftBarButtonItem = btnBack;
            self.navigationItem.hidesBackButton = YES;
            
            
            
            [navBar pushNavigationItem:self.navigationItem animated:NO];
            
            navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
            
            self.navigationItem.title=@"Change Password";
            
            if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
            {
                [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                [UIColor whiteColor], UITextAttributeTextColor,
                                                [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                                nil]];
                [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
            }
            
        }
    

    
    
	// Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
}

-(IBAction)submit:(id)sender
{
    BOOL isValid = YES;
    if(!txtOldPassword.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter Old Password" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtNewPassword.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter New Password" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtConfirmPassword.text.length > 0)
    {
        isValid = NO;
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter Confirm password" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
    else if(![txtConfirmPassword.text isEqualToString:txtNewPassword.text])
    {
        isValid = NO;
        [[[UIAlertView alloc] initWithTitle:@"" message:@"password does not match" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
    
    
    if(isValid)
    {
        [txtOldPassword resignFirstResponder];
        [txtNewPassword resignFirstResponder];
        [txtConfirmPassword resignFirstResponder];
        
        
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(changePassword) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }


}

-(void)changePassword
{
        ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlChangePassword];
        
        [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
        [request setPostValue:txtOldPassword.text forKey:@"password"];
        [request setPostValue:txtNewPassword.text forKey:@"newpassword"];
           [request setDelegate:self];
        [request setDidFailSelector:@selector(requestForForgotPasswordFail:)];
        [request setDidFinishSelector:@selector(requestForForgotPasswordSuccess:)];
        [request startSynchronous];
    }
    
    -(void)requestForForgotPasswordFail:(ASIFormDataRequest *)request
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
    -(void)requestForForgotPasswordSuccess:(ASIFormDataRequest *)request
    {
        NSString *responseString = [request responseString];
        responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
        responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        SBJSON *parser=[[SBJSON alloc]init];
        
        NSDictionary *results = [parser objectWithString:responseString error:nil];
        NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
        
        if(responseDict)
        {
            NSString *status= [responseDict objectForKey:@"error_code"];
            
            if (![status isEqualToString:@"0"])
            {
                NSString *strErrorMessage = [responseDict valueForKey:@"error_msg"];
                dispatch_async(dispatch_get_main_queue(), ^
                               {
                                   [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                               });
            }
            else
            {
                NSString *strSuccessMessage = [responseDict valueForKey:@"success_msg"];
                dispatch_async(dispatch_get_main_queue(), ^
                               {
                                   [[[UIAlertView alloc]initWithTitle:nil message:strSuccessMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                                   txtOldPassword.text=nil;
                                    txtNewPassword.text=nil;
                                    txtConfirmPassword.text=nil;
                               });
            }
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [RWUtils alertForServerNotResponding];
                           });
        }
    }

    
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
