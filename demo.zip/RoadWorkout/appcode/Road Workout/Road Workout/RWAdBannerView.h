//
//  RWIAdBannerView.h
//  Road Workout
//
//  Created by vishnu on 18/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <iAd/iAd.h>

@interface RWAdBannerView : ADBannerView

@end
