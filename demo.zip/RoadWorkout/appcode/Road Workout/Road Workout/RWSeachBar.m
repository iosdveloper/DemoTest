//
//  RWSeachBarView.m
//  Road Workout
//
//  Created by vishnu on 11/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWSeachBar.h"

@implementation RWSeachBar

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
    }
    
    return self;
}

-(void)drawRect:(CGRect)rect{
    
    [self setBackgroundImage:[UIImage imageNamed:@"searchBar_bg.png"]];
    UIImage *searchFieldImage = [UIImage imageNamed:@"searchBar_bg.png"];
    [self setSearchFieldBackgroundImage:searchFieldImage forState:UIControlStateNormal];
}
@end
