//
//  RWLocationDetailViewController.h
//  Road Workout
//
//  Created by user on 16/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RWPlaceDetail.h"
#import <MapKit/MapKit.h>
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import <QuartzCore/QuartzCore.h>
#import "RWPlaceDetail.h"
#import <CoreLocation/CoreLocation.h>
#import <Social/Social.h>

@interface RWLocationDetailViewController : UIViewController<MKMapViewDelegate,UIWebViewDelegate,CLLocationManagerDelegate>
{
    IBOutlet UIImageView *imvLink;
    IBOutlet UIImageView *imvPhone;
    IBOutlet UIImageView *imvBorder;
    
    IBOutlet UILabel *lblName;
    IBOutlet UILabel *lblBorder;
    IBOutlet UILabel *lblDot1;
    IBOutlet UILabel *lblDot2;
    IBOutlet UILabel *lbldiscription;
    
    IBOutlet UIView *viewbar1;
    IBOutlet UIView *viewbar2;
    IBOutlet UIView *viewMapView;
    IBOutlet UIView *viewWeb;
    
    IBOutlet MKMapView *mpLoc;

    IBOutlet UIButton *btnFullScreen;
    IBOutlet UIButton *btnWebView;
    IBOutlet UIButton *btnYelp;
    IBOutlet UIButton *btnWebsite;
    IBOutlet UIButton *btnPhoneNum;
    IBOutlet UIButton *btnTickets;
    IBOutlet UIButton *btnShare;
    
    IBOutlet UIWebView *webLongDes;
    IBOutlet UIWebView *webDiscription;
    
    IBOutlet UISegmentedControl *segMapControl;
    IBOutlet UISegmentedControl *segUserControl;
    
    IBOutlet UIBarButtonItem *btnBack;
    IBOutlet UIBarButtonItem *btnSetting;
    IBOutlet UINavigationBar *navBar;
    
    CGRect frameMap;
    
    
    CLLocationManager *locationManager;
    
    BOOL isMap;
    BOOL isFullNot;
    BOOL haveAlreadyReceivedCoordinates;
    
    NSURL *urlLocationDetail;
    
    MBProgressHUD *HUD;
    RWPlaceDetail *locationDetail;
    
    NSArray* routes;
    UIView *schoolView;
    UIImageView *routeView;
    UIColor* lineColor;
    UILabel *l1;

}




-(IBAction)back:(id)sender;
-(IBAction)getCall:(id)sender;
-(IBAction)gotoWebPage:(id)sender;
-(IBAction)gotoSettingPage:(id)sender;
-(IBAction)gotoReviewYelpPage:(id)sender;
-(IBAction)gotoFullScreen:(id)sender;

-(IBAction)openWebView:(id)sender;
-(IBAction)closeWebView:(id)sender;

@property (nonatomic, copy) void (^completionHandler)(void);
@property(nonatomic,strong)RWPlaceDetail *locationDetail;

@end
