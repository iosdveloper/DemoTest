//
//  RWForgotPasswordViewController.h
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
#import "MBProgressHUD.h"
#import "Validate.h"
#import "SBJSON.h"

@interface RWForgotPasswordViewController : UIViewController<UITextFieldDelegate>

{
    IBOutlet UITextField *txtEmail;
   
    IBOutlet UIImageView *imvBorder;
    IBOutlet UIBarButtonItem *btnCan;
    IBOutlet UINavigationBar *navBar;
    IBOutlet UIButton *btnSubmit;
    
    IBOutlet UILabel *lblBorder;
   
    MBProgressHUD *HUD;
    
    NSURL *urlForgotPassword;
    
}

-(IBAction)btnSubmitClicked:(id)sender;
-(IBAction)btnCancelClicked:(id)sender;

@end
