//
//  RWLoginData.m
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWLoginData.h"

@implementation RWLoginData

@synthesize strAddedOn, strName, strUserId, strEmail;

@end
