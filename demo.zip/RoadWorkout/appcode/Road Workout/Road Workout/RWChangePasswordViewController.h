//
//  RWChangePasswordViewController.h
//  Road Workout
//
//  Created by user on 14/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "RWUtils.h"

@interface RWChangePasswordViewController : UIViewController
{
    IBOutlet UITextField *txtOldPassword;
    IBOutlet UITextField *txtNewPassword;
    IBOutlet UITextField *txtConfirmPassword;
   
    IBOutlet UIImageView *imvBorder;
    IBOutlet UILabel *lblBorder;
    IBOutlet UIBarButtonItem *btnBack;
    IBOutlet UINavigationBar *navBar;
    IBOutlet UIButton  *btnSubmit;
   
    NSURL *urlChangePassword;
    
    MBProgressHUD *HUD;
    
    
}

-(IBAction)submit:(id)sender;
-(IBAction)back:(id)sender;
@end
