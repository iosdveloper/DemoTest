//
//  RWCategoriesViewController.m
//  Road Workout
//
//  Created by vishnu on 11/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//







#import "RWCategoriesViewController.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "RWConstants.h"
#import "RWUtils.h"
#import "RWCategoryData.h"
#import "RWPlaceData.h"
#import <QuartzCore/QuartzCore.h>


@implementation RWCategoriesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
    }
    return self;
}


-(void)viewWillDisappear:(BOOL)animated
{
    CGRect frame = viewselectadd.frame;
    frame.size.height =  0;
    viewselectadd.frame = frame;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    btnSchoollist.hidden = YES;
    lblschoolnames.hidden =YES;
    
    self.navigationController.navigationBarHidden=YES;
    NSString *strCategoryList = URL_CATEGORY_LIST;
    urlCategoryList=[NSURL URLWithString:strCategoryList];
    
    NSString *strLocationList = URL_LOCATION_LIST;
    urlLocationList=[NSURL URLWithString:strLocationList];
    
    NSString *strSchoolList = URL_GET_ALL_SCHOOL;
    urlSchoolList=[NSURL URLWithString:strSchoolList];
    
    isLeftToRight=YES;
    haveAlreadyReceivedCoordinates = NO;
    canAccessLocation = YES;
    arrClassData = [[NSMutableArray alloc]init];
    arrSearchData = [[NSMutableArray alloc] init];
    
    tblCityAddress.frame = CGRectMake(8, 116, 306, 0);
   
    
    tblCategory.hidden=YES;
    lblCategory.hidden=YES;
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)
    {

    UIImage* userLoaction = [UIImage imageNamed:@"map_ic.png"];
    CGRect imgBackframe = CGRectMake(0, 0, userLoaction.size.width, userLoaction.size.height);
    UIButton *backBtn = [[UIButton alloc] initWithFrame:imgBackframe];
    [backBtn setBackgroundImage:userLoaction forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(getCurrentUserLoaction:)
      forControlEvents:UIControlEventTouchUpInside];
    [backBtn setShowsTouchWhenHighlighted:YES];
    
    
    UIImage* imageDone = [UIImage imageNamed:@"btn_setting1.png"];
    CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
    UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
    [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
    [doneBtn addTarget:self action:@selector(gotoSettingPage:)
      forControlEvents:UIControlEventTouchUpInside];
    
    btnUserLoc =[[UIBarButtonItem alloc] initWithCustomView:backBtn];
    btnSetting =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
    
    self.navigationItem.leftBarButtonItem = btnUserLoc;
    self.navigationItem.hidesBackButton = YES;
    
    self.navigationItem.rightBarButtonItem = btnSetting;
    
    [navBar pushNavigationItem:self.navigationItem animated:NO];
       
        navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
    
        self.navigationItem.title=@"Categories";
        
        if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
        {
            [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                  [UIColor whiteColor], UITextAttributeTextColor,
                                                                  [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                                                  nil]];
            [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
        }
    
    }
    
    arrAddressOption=[[NSArray alloc]initWithObjects:@"Address",@"School",@"City",@"State/Prov.",@"Country",nil];
    
    [searchBarLocation setBackgroundImage:[UIImage imageNamed:@"searchBar_bg.png"]];
    UIImage *searchFieldImage = [UIImage imageNamed:@"searchBar_bg.png"];
    [searchBarLocation setSearchFieldBackgroundImage:searchFieldImage forState:UIControlStateNormal];
    [searchBarCategories setBackgroundImage:[UIImage imageNamed:@"searchBar_bg.png"]];
    [searchBarCategories setSearchFieldBackgroundImage:searchFieldImage forState:UIControlStateNormal];

   
    searchBarLocation.delegate = self;
    searchBarCategories.delegate = self;
    searchBarLocation.placeholder = @"address, city, zip code";
    searchBarCategories.placeholder = @"categories";
    
    if ([RWUtils isConnectedToInternet])
    {
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD show];
        
      

        
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        if([locationManager respondsToSelector:@selector(requestAlwaysAuthorization)])
        {
            [ locationManager requestAlwaysAuthorization];
        }
   
        locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
        [locationManager startUpdatingLocation];
    }
    
        
    //for FavoriteList Database
    [self performSelectorInBackground:@selector(favListForUser) withObject:nil];
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    if (status == kCLAuthorizationStatusAuthorizedAlways || status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
    }
}

-(void)viewWillAppear:(BOOL)animated
{
     [super viewWillAppear:animated];
    //reducing this method
}


///////////////////////////////////////CATEGORYLIST APICALL //////////////////////////////////////////////

-(void)getCategoryList:(NSString *)addressSearch
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlCategoryList];

    if(address==1)
    {
       [request setPostValue:addressSearch forKey:@"school"];
    }
    else if(address==2){
         [request setPostValue:addressSearch forKey:@"city"];
    }
    else if(address==3)
    {
        [request setPostValue:addressSearch forKey:@"state"];
    }
    else if(address==4)
    {
        [request setPostValue:addressSearch forKey:@"country"];
    }
    else
    {
        [request setPostValue:@"30" forKey:@"range"];
        
    }
    [request setPostValue:strCatLatitude forKey:@"latitude"];
    [request setPostValue:strCatLongitude forKey:@"longitude"];
    

    [request setDelegate:self];
    [request setDidFailSelector:@selector(getCategoryListFail:)];
    [request setDidFinishSelector:@selector(getCategoryListSuccess:)];
    [request startSynchronous];

}

-(void)getCategoryListFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
  
}

-(void)getCategoryListSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            NSMutableArray *arrCategoryList=[responseData valueForKey:@"categorylist"];
           
            categoryList =[[NSMutableArray alloc]init];
                            NSMutableArray   *arrSort = [[NSMutableArray alloc]init];
                               for (int i=0; i<arrCategoryList.count; i++)
                               {
                                    RWCategoryData *categoryData=[[RWCategoryData alloc]init];
                                   categoryData.strCategoryid=[[arrCategoryList objectAtIndex:i] valueForKey:@"category_id"];
                                   categoryData.strCategoryName=[[arrCategoryList objectAtIndex:i] valueForKey:@"category_name"];
                                   categoryData.strTotalPlaces=[NSString stringWithFormat:@"%@",[[arrCategoryList objectAtIndex:i] valueForKey:@"totalPlaces"]];
                                   categoryData.strStatus=[[arrCategoryList objectAtIndex:i] valueForKey:@"status"];
                                  
                                   if (![categoryData.strTotalPlaces isEqualToString:@"0"])
                                   {
                                        [arrSort addObject:categoryData];
                                   }
                                }
            
            NSSortDescriptor *sortDescriptor;
            sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"strCategoryName" ascending:YES];
            NSArray *arrSortDescriptors = [NSArray arrayWithObject:sortDescriptor];
            categoryList = [[arrSort sortedArrayUsingDescriptors:arrSortDescriptors] mutableCopy];
            
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               if (categoryList.count==0) {
                                   [UIView beginAnimations:nil context:nil];
                                   [UIView setAnimationDuration:0.5];
                                   searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
                               //    btnAddEvent.frame =CGRectMake(269, 72, 44, 44);
                                   [UIView commitAnimations];
                                   tblCategory.hidden=YES;
                                   lblCategory.hidden=NO;
                               }
                               else
                               {
                                   [self performSelectorInBackground:@selector(overallLocationlitDetail) withObject:nil];
                                   [UIView beginAnimations:nil context:nil];
                                   [UIView setAnimationDuration:0.5];
                                    searchBarCategories.frame=CGRectMake(8, 122, 305, 44);
                                 //  btnAddEvent.frame =CGRectMake(269, 122, 44, 44);

                                   [UIView commitAnimations];
                                   arrClassData = [categoryList mutableCopy];
                                   tblCategory.hidden=NO;
                                   lblCategory.hidden=YES;
                                   [tblCategory reloadData];
                               }
                               
                            
                           });
            strSchoolName  = searchBarLocation.text ;
        strAddressName=[searchBarLocation.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [UIView beginAnimations:nil context:nil];
                               [UIView setAnimationDuration:0.5];
                               searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
                             //  btnAddEvent.frame =CGRectMake(269, 72, 44, 44);

                               [UIView commitAnimations];
                               tblCategory.hidden=YES;
                               lblCategory.hidden=NO;
                           });
        }
    }
    else
    {
        [HUD hide];
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    [HUD hide];
  
}
///////////////////////////////////////CATEGORYLIST END//////////////////////////////////////////////



////////////////////////////LATITUDE LONGITUDE TO ADDRESS APICALL ////////////////////////////////////////

-(void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
    canAccessLocation=YES;
    if (haveAlreadyReceivedCoordinates)
    {
        return;
    }
    haveAlreadyReceivedCoordinates=YES;
   strLatitude = [NSString stringWithFormat:@"%0.06f",newLocation.coordinate.latitude];
   strLongitude = [NSString stringWithFormat:@"%0.06f",newLocation.coordinate.longitude];
    
     [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%0.06f",newLocation.coordinate.latitude] forKey:CURRENTLET];
     [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%0.06f",newLocation.coordinate.longitude] forKey:CURRENTLOG];
    
//    strLatitude = @"45.366395";
//    strLongitude =@"-71.849829";

    strCatLatitude = strLatitude;
    strCatLongitude = strLongitude;
    
    [self getAddressFromLatLon:[strCatLatitude doubleValue] withLongitude:[strCatLongitude doubleValue]];
    [locationManager stopUpdatingLocation];
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    canAccessLocation = NO;
      [HUD hide];
}



-(void )getAddressFromLatLon:(double)pdblLatitude withLongitude:(double)pdblLongitude
{

    [locationManager stopUpdatingLocation];
    NSString *urlString = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%0.06f,%0.06f&sensor=true",pdblLatitude, pdblLongitude];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getFail:)];
    [request setDidFinishSelector:@selector(getSuccess:)];
    [request startSynchronous];
    
}

-(void)getFail:(ASIFormDataRequest *)request
{
    [locationManager stopUpdatingLocation];
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                       [HUD hide];
                   });
}

-(void)getSuccess:(ASIFormDataRequest *)request
{
    [locationManager stopUpdatingLocation];
    locationManager=nil;
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseData = [results valueForKey:@"results"];
    
    if(responseData.count!=0)
    {
        NSMutableArray *status=[responseData valueForKey:@"formatted_address"];
        strUserAddress=[status objectAtIndex:0];
        strCurrentCountry=[status objectAtIndex:(status.count-1)];

        if (strLatitude && strLongitude)
        {
            [HUD hide];
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(getCategoryList:) onTarget:self withObject:nil animated:TRUE];
        }
        searchBarLocation.text = strUserAddress;
    }
    else
    {
        [HUD hide];
        NSString *strMess=[results valueForKey:@"error_message"];
        dispatch_async(dispatch_get_main_queue(),
                       ^{
                            [[[UIAlertView alloc]initWithTitle:@"Error Message" message:strMess delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
                        });
    }
}


////////////////////////////ADDRESS TO LATITUDE LONGITUDE APICALL ////////////////////////////////////////

- (void) geoCodeUsingAddress:(NSString *)address1
{
    CLLocationCoordinate2D center;
    NSString *strAddressPass1;
    NSString *strAddressPass2;
    
    
    
    if (address==2)
    {
        strAddressPass1=[address1 stringByAppendingString:@",Canada"];
        strAddressPass2=[address1 stringByAppendingString:@",USA"];
        
        NSString *esc_addr =  [strAddressPass1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=true&address=%@", esc_addr];
        NSString *resulting = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
        
        SBJSON *parser = [[SBJSON alloc]init];
        NSDictionary *results = [parser objectWithString:resulting error:nil];
        
        if ([[results valueForKey:@"status"] isEqualToString:@"ZERO_RESULTS"] || !results)
        {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.5];
            searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
           // btnAddEvent.frame =CGRectMake(269, 72, 44, 44);

            [UIView commitAnimations];
            
            tblCategory.hidden=YES;
            lblCategory.hidden=NO;
        }
        else
        {
            NSMutableArray *arrAddressList = [[NSMutableArray alloc] init];
            arrCityList = [[NSMutableArray alloc]init];
            arrAddressList=[results valueForKey:@"results"];
           
            for (int i=0; i<arrAddressList.count; i++)
            {
                RWCityFilterDetails *cityDetails=[[RWCityFilterDetails alloc]init];
                cityDetails.strCityName = [[arrAddressList objectAtIndex:i] valueForKey:@"formatted_address"];
                cityDetails.strCityLatitude = [[[[arrAddressList objectAtIndex:i] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
                cityDetails.strCityLongitude = [[[[arrAddressList objectAtIndex:i] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
                cityDetails.strCityType = [[[arrAddressList objectAtIndex:i] valueForKey:@"types"] objectAtIndex:0];
            
                if ([cityDetails.strCityType isEqualToString:@"locality"])
                {
                    [arrCityList addObject:cityDetails];
                }
            }
            
            NSString *esc_addr =  [strAddressPass2 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=true&address=%@", esc_addr];
            NSString *resulting = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
            
            SBJSON *parser = [[SBJSON alloc]init];
            NSDictionary *results = [parser objectWithString:resulting error:nil];
            
            NSMutableArray *arrAddressList1 = [[NSMutableArray alloc] init];
        
            arrAddressList1=[results valueForKey:@"results"];
                
            for (int i=0; i<arrAddressList1.count; i++)
            {
                    RWCityFilterDetails *cityDetails=[[RWCityFilterDetails alloc]init];
                    cityDetails.strCityName = [[arrAddressList1 objectAtIndex:i] valueForKey:@"formatted_address"];
                    cityDetails.strCityLatitude = [[[[arrAddressList1 objectAtIndex:i] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
                    cityDetails.strCityLongitude = [[[[arrAddressList1 objectAtIndex:i] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
                NSMutableArray *arrTypes = [[arrAddressList1 objectAtIndex:i] valueForKey:@"types"];
                if (arrTypes.count>0) {
                    
                    cityDetails.strCityType = [arrTypes objectAtIndex:0];
                }
                    if ([cityDetails.strCityType isEqualToString:@"locality"])
                    {
                        [arrCityList addObject:cityDetails];
                    }
            }

            NSMutableArray *arrData = [[NSMutableArray alloc]init];
            
            if (arrCityList.count>0)
            {
                for (int i = 0; i<[arrCityList count]; i++)
                {
                    RWCityFilterDetails *historyHolder = [[RWCityFilterDetails alloc]init];
                    historyHolder = [arrCityList objectAtIndex:i];
                    
                    [arrData addObject: historyHolder.strCityName];
                }
                
                NSArray *copy = [arrData copy];
                NSInteger index = [copy count] - 1;
                for (id object in [copy reverseObjectEnumerator])
                {
                    if ([arrData indexOfObject:object inRange:NSMakeRange(0, index)] != NSNotFound)
                    {
                        [arrCityList removeObjectAtIndex:index];
                    }
                    index--;
                }
                if (arrCityList.count>7)
                {
                    tblCityAddress.frame = CGRectMake(8, 122, 306, 310);
                }
                else
                {
                    tblCityAddress.frame = CGRectMake(8, 122, 306, 44);
                    tblCityAddress.frame = CGRectMake(8, 122, 306, tblCityAddress.frame.size.height*arrCityList.count);
                }
                
                [tblCityAddress reloadData];
                

            }
            else
            {
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:0.5];
                searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
              //  btnAddEvent.frame =CGRectMake(269, 72, 44, 44);

                [UIView commitAnimations];
                
                tblCategory.hidden=YES;
                lblCategory.hidden=NO;

            }
            
            
            
        }
        
    }
    else
    {
        strAddressPass1 = address1;

        NSString *esc_addr =  [strAddressPass1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=true&address=%@", esc_addr];
        NSString *resulting = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
        
        SBJSON *parser = [[SBJSON alloc]init];
        NSDictionary *results = [parser objectWithString:resulting error:nil];
        
        if ([[results valueForKey:@"status"] isEqualToString:@"ZERO_RESULTS"] || !results)
        {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.5];
            searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
           // btnAddEvent.frame =CGRectMake(269, 72, 44, 44);

            [UIView commitAnimations];
            
            tblCategory.hidden=YES;
            lblCategory.hidden=NO;
        }
        else
        {
                NSDictionary *geomatry = [results valueForKey:@"results"];
                NSDictionary *location = [geomatry valueForKey:@"geometry"];
                NSArray *result=[location valueForKey:@"location"];
                NSString *locationDetail1=[result objectAtIndex:0];
                if (result)
                {
                    center.latitude = [[locationDetail1 valueForKey:@"lat"] doubleValue];
                    center.longitude = [[locationDetail1 valueForKey:@"lng"] doubleValue];
                }
                strCatLatitude =[NSString stringWithFormat:@"%f",center.latitude];
                 strCatLongitude =[NSString stringWithFormat:@"%f",center.longitude];
                address=helpAddress;
                HUD=[[MBProgressHUD alloc] initWithView:self.view];
                [self.view addSubview:HUD];
                [HUD showWhileExecuting:@selector(getCategoryList:) onTarget:self withObject:searchBarLocation.text animated:TRUE];
            }
        }
}


////////////////////////ADDRESS TO LATITUDE LONGITUDE APICALL End ///////////////////////////////////



////////////////////////////TableView Start ////////////////////////////////////////

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   if (tableView==tblSelectChoice)
   {
        return [arrAddressOption count];
   }
   else if(tableView==tblCategory)
   {
       if (searchBarCategories.text.length>0)
       {
           return [arrSearchData count];
       }
       else
       {
           return [categoryList count];
       }
    }
    else
    {
        return [arrCityList count];
    }
}
#pragma mark - Table view data source

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
    
  
    
    if(isAtLeast7)
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if (tableView==tblSelectChoice)
    {
        static NSString *cellIdentifier = @"Cell";
        UITableViewCell   *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                         reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=[arrAddressOption objectAtIndex:indexPath.row];
        cell.textLabel.textColor =[UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor colorWithRed:0/255.0 green:12.0/255.0 blue:55.0/255.0 alpha:1];
        [cell.textLabel setFont:[UIFont systemFontOfSize:14.0]];
        return cell;
    }
    else if (tableView==tblCityAddress)
    {
        static NSString *cellIdentifier = @"CityCell";
        UITableViewCell   *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                         reuseIdentifier:cellIdentifier];
        }
 
            RWCityFilterDetails *cityListData=[[RWCityFilterDetails alloc]init];
            cityListData = [arrCityList objectAtIndex:indexPath.row];
            cell.textLabel.text = cityListData.strCityName;
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        return cell;
    }
    else
    {
        static NSString *cellIdentifier = @"CategoryCell";
        RWCategoryCell   *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (cell == nil)
        {
            cell = [[RWCategoryCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                         reuseIdentifier:cellIdentifier];
        }
        
        CGSize titleStringSize;
        categoryListData=[[RWCategoryData alloc]init];
        
        if (searchBarCategories.text.length>0)
        {
            categoryListData = [arrSearchData objectAtIndex:indexPath.row];
        }
        else
        {
            categoryListData = [categoryList objectAtIndex:indexPath.row];
        }
        
        NSString *strTitle = categoryListData.strCategoryName;
       
        
        if(strTitle==(id) [NSNull null] || [strTitle length]==0 || [strTitle isEqualToString:@""])
        {
            [cell.lblTitle setText:@""];
        }
        else
        {
            titleStringSize = [strTitle sizeWithFont:[UIFont systemFontOfSize:15]];
            [cell.lblTitle setFrame:CGRectMake(10,10,titleStringSize.width,21)];
            [cell.lblTitle setText:strTitle];
        }
        NSString *strCount;
        if([categoryListData.strTotalPlaces integerValue] > 50)
        {
            strCount = [NSString stringWithFormat:@"(50+)"];
        }
        else
        {
            strCount = [NSString stringWithFormat:@"(%@)", categoryListData.strTotalPlaces];
        }
        
        if(strCount==(id) [NSNull null] || [strCount length]==0 || [strCount isEqualToString:@""])
        {
            [cell.lblCount setText:@""];
        }
        else
        {
            [cell.lblCount setText:strCount];
            [cell.lblCount setFrame:CGRectMake(titleStringSize.width+10,10,42,21)];
        }
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==tblSelectChoice)
    {
        isLeftToRight=YES;
        searchBarLocation.text=nil;
        searchBarLocation.placeholder=[arrAddressOption objectAtIndex:indexPath.row];
        helpAddress=indexPath.row;
        strAddressTag=indexPath.row;
        tblCategory.hidden=YES;
        lblCategory.hidden = YES;
        btnSchoollist.hidden = YES;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        viewselectadd.frame=CGRectMake(174, 112, 95, 0);
        tblSelectChoice.frame=CGRectMake(0, 0, 95, 0);
        if(indexPath.row == 1){
            [self getSchoolListRequest:nil];
        }
        
        searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
      //  btnAddEvent.frame =CGRectMake(269, 72, 44, 44);

        [UIView commitAnimations];
        
    }
    else if (tableView==tblCityAddress)
    {

            tblCityAddress.frame = CGRectMake(8, 122, 306, 0);
            RWCityFilterDetails *cityAddress=[[RWCityFilterDetails alloc]init];
            cityAddress=[arrCityList objectAtIndex:indexPath.row];
            searchBarLocation.text=cityAddress.strCityName;
            strCatLatitude = cityAddress.strCityLatitude;
            strCatLongitude = cityAddress.strCityLongitude;
            NSString *strCityAddress=[cityAddress.strCityName stringByReplacingOccurrencesOfString:@" " withString:@""];
            address=helpAddress;
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(getCategoryList:) onTarget:self withObject:strCityAddress animated:TRUE];
     
    }
    else
    {
        if(searchBarCategories.text.length>0)
        {
            categoryListData = [arrSearchData objectAtIndex:indexPath.row];
        }
        else
        {
            categoryListData = [categoryList objectAtIndex:indexPath.row];
        }
        
        strCategoryId=categoryListData.strCategoryid;
        
        if ([categoryListData.strTotalPlaces integerValue] <=50)
        {
            strRange = [NSString stringWithFormat:@"10000"];
        }
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(getLocationLongList) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [self getLocationListFromDatabase];
        }
    }
}

//////////////////////////////////CATEGORYLIST TABLE  END//////////////////////////////////////////////



-(void)getSchoolListRequest:(id *)sender
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlSchoolList];
    [HUD show];
     [request setDelegate:self];
    [request setDidFailSelector:@selector(getSchoolFail:)];
    [request setDidFinishSelector:@selector(getSchoolSuccess:)];
    [request startSynchronous];
}
-(void)getSchoolFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                       [HUD hide];
                   });
}

-(void)getSchoolSuccess:(ASIFormDataRequest *)request
{
    locationList = [[NSMutableArray alloc]init];
    
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            arrSchool = [responseData valueForKey:@"data"];
            btnSchoollist.hidden = NO;
             [HUD hide];
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                           [HUD hide];
                       });
    }
    
}



/////////////////////////////////////// SearchBar Start //////////////////////////////////////////////


-(void)searchViewShouldBeginEditing:(UISearchBar *)searchBar
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    viewselectadd.frame=CGRectMake(174, 112, 95, 0);
    tblCityAddress.frame = CGRectMake(8, 122, 306, 0);
    [UIView commitAnimations];
    tblCategory.userInteractionEnabled = YES;
}

-(void)searchViewShouldSearchButtonClick:(UISearchBar *)searchBar searchText:(NSString *)searchText
{
    if (![searchBar.text isEqualToString:currentSearchText])
    {
        if(searchText.length == 0)
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [UIView beginAnimations:nil context:nil];
                               [UIView setAnimationDuration:0.5];
                               btnSelectChoice.frame=CGRectMake(166, 0, 95, 44);
                               btnAddEvent.frame =CGRectMake(261, 0, 44, 44);
                               searchBarLocation.frame=CGRectMake(0, 0, 166, 44);
                               [UIView commitAnimations];

                               [searchBarCategories resignFirstResponder];
                               [searchBarLocation resignFirstResponder];
                           });
        }
        else
        {
            [arrSearchData removeAllObjects];
            
            for (RWCategoryData *contact in arrClassData)
            {
                NSString *strName = [NSString stringWithFormat:@"%@", contact.strCategoryName];
                NSRange nameRange = [strName rangeOfString:searchText options:NSCaseInsensitiveSearch];
                
                if(nameRange.location != NSNotFound)
                {
                    [arrSearchData addObject:contact];
                }
                
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^
        {
            [tblCategory reloadData];
        });
    }
}
#pragma -mark searchbar Delegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    
    if (searchBar== searchBarCategories){
    [UIView commitAnimations];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
  //  btnAddEvent.frame=CGRectMake(320, 122, 44, 44);
    [UIView commitAnimations];
    }
    
    if(searchBarCategories.text.length == 0)
    {
        
       
        if (searchBar== searchBarCategories) {
            [UIView commitAnimations];
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.5];
         //   btnAddEvent.frame=CGRectMake(269, 122, 44, 44);
            [UIView commitAnimations];
        }
    }
    
    [self searchViewShouldBeginEditing:searchBar];
    
    for(id subview in [searchBar subviews])
    {
        if ([subview isKindOfClass:[UIButton class]]) {
            [subview setEnabled:YES];
        }
    }
    return YES;
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    if (searchBar== searchBarLocation) {
        if(searchBarLocation.text.length != 0)
        {
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:0.5];
                btnSelectChoice.frame=CGRectMake(305, 0, 95, 44);
                btnAddEvent.frame =CGRectMake(315, 0, 44, 44);
                searchBarLocation.frame=CGRectMake(0, 0, 305, 44);
                viewselectadd.frame=CGRectMake(174, 112, 95, 0);
               [UIView commitAnimations];
        }
    }
    
    if(searchBarCategories.text.length == 0)
    {
        
        [searchBarCategories resignFirstResponder];
    }
    
    
    if (searchBar== searchBarCategories) {
        [UIView commitAnimations];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
      //  btnAddEvent.frame=CGRectMake(320, 122, 44, 44);
        [UIView commitAnimations];
    }
    
   
    [self searchViewShouldSearchButtonClick:searchBar searchText:searchBar.text];
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    if (searchBarLocation.text.length == 0) {
        [self getCurrentUserLoaction:self];
    }
   
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [self.searchDisplayController.searchBar setText:@""];
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [tblCategory reloadData];
                   });
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    if (searchBar==searchBarLocation)
    {
        [searchBarLocation resignFirstResponder];
        if([RWUtils isConnectedToInternet])
        {
            address=strAddressTag;
            [self geoCodeUsingAddress:searchBarLocation.text];
        }
        else
        {
          //  [self getDataFromDataBase];
        }
    }
    else
    {
        [searchBar setShowsCancelButton:NO animated:YES];
        [searchBar resignFirstResponder];
        [self searchViewShouldSearchButtonClick:searchBar searchText:searchBar.text];
        
        if (![searchBar.text isEqualToString:currentSearchText])
        {
            currentSearchText = searchBar.text;
        }
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [searchBarLocation resignFirstResponder];
     [searchBarCategories resignFirstResponder];
}

///////////////////////////////////////SearchBar End //////////////////////////////////////////////





///////////////////////////////////////PLACESLIST APICALL //////////////////////////////////////////////

-(void)getLocationLongList
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationList];
    if([categoryListData.strTotalPlaces integerValue] > 50)
    {
          if(address== 1)
         {
             [request setPostValue:strSchoolName  forKey:@"school"];
             [request setPostValue:@"500" forKey:@"range"];
              strRange = @"500";
           
         }
           else  if(address==2)
        {
            [request setPostValue:strAddressName forKey:@"city"];
            [request setPostValue:@"100" forKey:@"range"];
             strRange = @"100";
        }
        else if(address==3)
        {
            [request setPostValue:strAddressName forKey:@"state"];
            [request setPostValue:@"500" forKey:@"range"];
             strRange = @"500";
            
        }
        else if(address==4)
        {
            [request setPostValue:strAddressName forKey:@"country"];
            [request setPostValue:@"500" forKey:@"range"];
             strRange = @"500";
        }
        else
        {
            [request setPostValue:@"30" forKey:@"range"];
             strRange = @"30";
        }
    }
    
    else
    {
        if(address== 1)
        {
            [request setPostValue:strSchoolName  forKey:@"school"];
            [request setPostValue:@"1000" forKey:@"range"];
           // strRange = @"1000";
            
        }
        else if(address==2)
        {
            [request setPostValue:strAddressName forKey:@"city"];
            [request setPostValue:@"10000" forKey:@"range"];
        }
        else if(address==3)
        {
            [request setPostValue:strAddressName forKey:@"state"];
            [request setPostValue:@"10000" forKey:@"range"];
            
        }
        else if(address==4)
        {
            [request setPostValue:strAddressName forKey:@"country"];
            [request setPostValue:@"10000" forKey:@"range"];
        }
        else
        {
             [request setPostValue:@"30" forKey:@"range"];
              strRange = @"30";
        }
        
    }
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:CURRENTLET] forKey:@"current_user_latitude"];
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:CURRENTLOG]  forKey:@"current_user_longitude"];
    

    [request setPostValue:strCatLatitude forKey:@"latitude"];
    [request setPostValue:strCatLongitude forKey:@"longitude"];
    [request setPostValue:strCategoryId forKey:@"categoryid"];
    
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getLocationListFail:)];
    [request setDidFinishSelector:@selector(getLocationListSuccess:)];
    [request startSynchronous];
    
}

-(void)getLocationListFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                       [HUD hide];
                   });
}

-(void)getLocationListSuccess:(ASIFormDataRequest *)request
{
    locationList = [[NSMutableArray alloc]init];
    
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            NSMutableArray *arrCategoryList=[responseData valueForKey:@"placesList"];
            //NSMutableArray *arrLocation = [[NSMutableArray alloc]init];
            
            NSSortDescriptor *sortDescriptor1;
            sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"start_date_time" ascending:YES];
            NSArray *arrSortDescriptors1 = [NSArray arrayWithObject:sortDescriptor1];
            NSMutableArray *arrNewSortedDate = [[arrCategoryList sortedArrayUsingDescriptors:arrSortDescriptors1] mutableCopy];
            
//            NSSortDescriptor *sortDescriptor2;
//            sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"distance" ascending:NO];
//            NSArray *arrSortDescriptors2 = [NSArray arrayWithObject:sortDescriptor2];
//            NSMutableArray *arrNewSorted = [[arrNewSortedDate  sortedArrayUsingDescriptors:arrSortDescriptors2] mutableCopy];
            
            
            
            for (int i=0; i < arrNewSortedDate.count; i++)
            {
                RWPlaceData *placeData=[[RWPlaceData alloc]init];
                placeData.strLocationid=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"locationid"];
                placeData.strAddress=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"address"];
                placeData.strDistance=[[[arrNewSortedDate objectAtIndex:i] valueForKey:@"distance"] doubleValue];
                placeData.strPlaceName=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"name"];
                placeData.strPlaceLatitude=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"latitude"];
                placeData.strPlaceLongitude=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"longitude"];
                placeData.strStart_Date_Time=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"start_date_time"];
                placeData.strEnd_Date_Time=[[arrNewSortedDate objectAtIndex:i] valueForKey:@"end_date_time"];
                placeData.strCatName = [[arrNewSortedDate objectAtIndex:i] valueForKey:@"category_name"];

                placeData.strIsFavAdded = [NSString stringWithFormat:@"%@", [[arrNewSortedDate objectAtIndex:i] valueForKey:@"isfavorite"]];
            
                if(locationList.count <= 50)
                {
                    [locationList addObject:placeData];
                }
                else
                {
                    break;
                }
                
            }
                               
//            NSSortDescriptor *sortDescriptor;
//            sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"strDistance" ascending:YES];
//            NSArray *arrSortDescriptors = [NSArray arrayWithObject:sortDescriptor];
//            locationList = [[arrLocation sortedArrayUsingDescriptors:arrSortDescriptors] mutableCopy];
            
            dispatch_async(dispatch_get_main_queue(), ^
                {
                    [self performSegueWithIdentifier:@"LocationList" sender:self];
                });

        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });

        }
        
    }
    else
    {
        
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                           [HUD hide];
                       });
    }
    
}

///////////////////////////////////////PLACESLIST END //////////////////////////////////////////////




-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"LocationList"])
    {
        RWLocationsViewController *location=(RWLocationsViewController*)[segue destinationViewController];
        location.arrLocationList=locationList;
        location.strLong = strCatLongitude;
        location.strLat = strCatLatitude;
        location.currentSearchText = strAddressName;
        location.addressTag=address;
      
    }
}



-(IBAction)gotoSettingPage:(id)sender
{
    [self performSegueWithIdentifier:@"settingRoadWorkOut" sender:nil];
}


-(IBAction)getCurrentUserLoaction:(id)sender
{
    address=0;
    lblschoolnames.hidden = YES;
    btnSchoollist.hidden = YES;
     searchBarLocation.hidden = NO;
    if (canAccessLocation)
    {
        haveAlreadyReceivedCoordinates=NO;
        searchBarLocation.placeholder=@"address, city,zip code";
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
        [locationManager startUpdatingLocation];
    }
    else
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"We need to know your Current Location. \n To re-enable, please go to Settings and turn on Location Service for this app." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
}

-(IBAction)showGotoAddressPage:(id)sender
{
     searchBarLocation.hidden = NO;
    lblschoolnames.hidden = YES;
    btnSchoollist.hidden = YES;
    viewselectadd.frame=CGRectMake(174, 112, 95, 0);
    CGRect frame = viewselectadd.frame;
    CGRect frame1 = tblSelectChoice.frame;
    frame.size.height = (isLeftToRight) ? 148 : 0;
    frame1.size.height = (isLeftToRight) ? 148 : 0;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    viewselectadd.frame = frame;
    tblSelectChoice.frame = frame1;
    [UIView commitAnimations];
    
    if (isLeftToRight)
    {
        isLeftToRight=NO;
    }
    else
    {
        isLeftToRight=YES;
    }
  
    
    [tblSelectChoice reloadData];
}




///////////////////////////////////////DataBase START //////////////////////////////////////////////


-(void)favListForUser
{
    NSString *strFavUrl = URL_FAVORITE;
    NSURL *urlFavList = [NSURL URLWithString:strFavUrl];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlFavList];
    
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(requestForFavListFail:)];
    [request setDidFinishSelector:@selector(requestForFavListSuccess:)];
    [request startSynchronous];
}


-(void)requestForFavListFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}


-(void)requestForFavListSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    SBJSON *parser=[[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
    
    if(responseDict)
    {
        NSString *status= [responseDict objectForKey:@"error_code"];
        
        if (![status isEqualToString:@"0"])
        {
        }
        else
        {
            NSArray *arrPlaceData = [responseDict objectForKey:@"placeData"];
            for (int i = 0; i<arrPlaceData.count; i++)
            {
                NSDictionary *dicPlaceData = [arrPlaceData objectAtIndex:i];
                RWPlaceData *placeData = [RWPlaceData new];
                placeData.strLocationid = [dicPlaceData objectForKey:@"locationid"];
                placeData.strPlaceName = [dicPlaceData objectForKey:@"locationname"];
                placeData.strPlaceCity = [dicPlaceData objectForKey:@"locationcity"];
                
                if (!db)
                {
                    db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
                }
                
                NSString *query1;
                
                query1 = [NSString stringWithFormat:@"Select count() FROM RoadWorkOutFavroiteList where favLocationId = \"%@\" and favUserId = \"%@\"",placeData.strLocationid,[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"]];
                
                NSString *query = [NSString stringWithFormat:@"INSERT into RoadWorkOutFavroiteList('favLocationId','favCityName', 'favLoactionName','favUserId')VALUES(\"%@\",\"%@\",\"%@\",\"%@\")",placeData.strLocationid,placeData.strPlaceCity,placeData.strPlaceName,[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"]];
                @try
                {
                    [db open];
                    FMResultSet *resultSet = [db executeQuery:query1];
                    [resultSet next];
                    int count =  [resultSet intForColumn:@"count()"];
                    [resultSet close];
                    if (count == 0) {
                        if ([db executeUpdate:query])
                        {
                            NSLog(@"success in insertation");
                        }
                        else
                        {
                            NSLog(@"error in insertation");
                        }
                    }
                    else
                    {
                        NSLog(@"already data exits ");
                    }
                    [db close];
                }
                @catch (NSException *e)
                {
                    NSLog(@"%@",e);
                }
            }
            
        }
    }
}



-(void)overallLocationlitDetail
{
    arrLocationData = [[NSMutableArray alloc]init];
    
    NSString *strLocationData = URL_LOCATION_DATA;
    urlLocationData = [[NSURL alloc]initWithString:strLocationData];
    
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationData];
    
    NSString *addressDatabase=[searchBarLocation.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    


    if(address==1)
    {
        [request setPostValue:addressDatabase forKey:@"city"];
    }
    else if(address==2)
    {
        [request setPostValue:addressDatabase forKey:@"state"];
    }
    else if(address==3)
    {
        [request setPostValue:addressDatabase forKey:@"country"];
        
    }
    else
    {
        [request setPostValue:@"30" forKey:@"range"];
    }
    
    [request setPostValue:strCatLatitude forKey:@"latitude"];
    [request setPostValue:strCatLongitude forKey:@"longitude"];
    
    [request setDelegate:self];
    //[request setDidFailSelector:@selector(getLocationDetailsFail:)];
    [request setDidFinishSelector:@selector(getLocationDetailsSuccess:)];
    [request startSynchronous];
    
    
}

-(void)getLocationDetailsSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            arrUpdateDate = [[NSMutableArray alloc]init];
            NSMutableArray *arrCategoryList=[responseData valueForKey:@"location"];
            for (int i=0; i<arrCategoryList.count; i++)
            {
                locationDetail=[[RWPlaceDetail alloc]init];
                
                locationDetail.strLocationid=[[arrCategoryList objectAtIndex:i] valueForKey:@"locationid"];
                locationDetail.strName=[[arrCategoryList objectAtIndex:i] valueForKey:@"name"];
                locationDetail.strGenre=[[arrCategoryList objectAtIndex:i]  valueForKey:@"genre"];
                locationDetail.strDescription=[[arrCategoryList objectAtIndex:i]  valueForKey:@"description"];
                locationDetail.strWebsite=[[arrCategoryList objectAtIndex:i] valueForKey:@"website"];
                locationDetail.strPhone=[[arrCategoryList objectAtIndex:i] valueForKey:@"phone"];
                locationDetail.strZipcode=[[arrCategoryList objectAtIndex:i] valueForKey:@"zipcode"];
                locationDetail.strAddress=[[arrCategoryList objectAtIndex:i] valueForKey:@"address"];
                locationDetail.strCity=[[arrCategoryList objectAtIndex:i]  valueForKey:@"city"];
                locationDetail.strState=[[arrCategoryList objectAtIndex:i]  valueForKey:@"state"];
                locationDetail.strContinent=[[arrCategoryList objectAtIndex:i] valueForKey:@"continent"];
                locationDetail.strCountry=[[arrCategoryList objectAtIndex:i]  valueForKey:@"country"];
                locationDetail.strLatitude=[[arrCategoryList objectAtIndex:i]  valueForKey:@"latitude"];
                locationDetail.strLongitude=[[arrCategoryList objectAtIndex:i] valueForKey:@"longitude"];
                locationDetail.strYelpLink=[[arrCategoryList objectAtIndex:i] valueForKey:@"yelp_link"];
                locationDetail.strAddedOn=[[arrCategoryList objectAtIndex:i]  valueForKey:@"addedon"];
                locationDetail.strUpdatedOn=[[arrCategoryList objectAtIndex:i] valueForKey:@"updatedon"];
                locationDetail.strCategoryId=[[arrCategoryList objectAtIndex:i]  valueForKey:@"categoryid"];
                locationDetail.strDistance=[[arrCategoryList objectAtIndex:i] valueForKey:@"distance"];
                
                if ([locationDetail.strDistance doubleValue]<=50)
                {
                    [arrLocationData addObject:locationDetail];
                    [arrUpdateDate addObject:locationDetail.strUpdatedOn];
                }
                
            }
            if (arrLocationData.count>0)
            {
                
                [self performSelectorInBackground:@selector(locationDetailDatabase:) withObject:arrLocationData];

            }
            
        }
    }
}

-(void)locationDetailDatabase:(NSMutableArray *)locData
{
    NSString *query3;
    NSString *query4;
    NSString *addressDatabase=[searchBarLocation.text stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceCharacterSet]];
    

    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }

    if(address == 1)
    {
        query3 = [NSString stringWithFormat:@"SELECT count()  FROM RoadWorkOutLocation where locCity like \"%@\"", addressDatabase];
        query4 = [NSString stringWithFormat:@"Delete FROM RoadWorkOutLocation where locCity like \"%@\"", addressDatabase];
    }
    else if(address == 2)
    {
        query3 = [NSString stringWithFormat:@"SELECT count()  FROM RoadWorkOutLocation where locState like \"%@\"",addressDatabase];
        query4 = [NSString stringWithFormat:@"delete  FROM RoadWorkOutLocation where locState like \"%@\"",addressDatabase];
    }
    else if(address == 3)
    {
        query3 = [NSString stringWithFormat:@"SELECT count()  FROM RoadWorkOutLocation where locCountry like \"%@\"",addressDatabase];
        query4 = [NSString stringWithFormat:@"delete  FROM RoadWorkOutLocation where locCountry like \"%@\"",addressDatabase];
    }
    else
    {
        query3 = [NSString stringWithFormat:@"SELECT count()  FROM RoadWorkOutLocation where locAddress like \"%@\"",addressDatabase];
        query4 = [NSString stringWithFormat:@"delete  FROM RoadWorkOutLocation where locAddress like \"%@\"",addressDatabase];
    }
    @try
    {
        [db open];
        
        FMResultSet *resultSet = [db executeQuery:query3];
        [resultSet next];
        int count =  [resultSet intForColumn:@"count()"];
        [resultSet close];
        
        if (count > locData.count)
        {
           if ([db executeUpdate:query4])
            {
                NSLog(@"Delete  Table");
            }
           
            for (int i=0; i<locData.count; i++)
            {
                RWPlaceDetail *loc=[[RWPlaceDetail alloc]init];
                
                loc=[locData objectAtIndex:i];
                
                NSString *query = [NSString stringWithFormat:@"INSERT into RoadWorkOutLocation('locId','locName', 'locCategoryName','locDescription','locWebsite','locPhone','locZipcode','locAddress','locCity','locState','locContinent','locCountry','locLatitude','locLongitude','locYelpLink','locAddedOn','locUpdatedOn','locCategoryId','locDistance')VALUES(\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",loc.strLocationid,loc.strName,loc.strGenre,loc.strDescription,loc.strWebsite,loc.strPhone,loc.strZipcode,loc.strAddress,loc.strCity,loc.strState,loc.strContinent,loc.strCountry,loc.strLatitude,loc.strLongitude,loc.strYelpLink,loc.strAddedOn,loc.strUpdatedOn,loc.strCategoryId,loc.strDistance];
                
                @try
                {
                    if ([db executeUpdate:query])
                    {
                        NSLog(@"success in insertation");
                    }
                    else
                    {
                        NSLog(@"error in insertation");
                    }
                }
                @catch (NSException *e)
                {
                    NSLog(@"%@",e);
                }
            }
        }
        else
        {
            for (int i=0; i<locData.count; i++)
            {
                
                RWPlaceDetail *loc=[[RWPlaceDetail alloc]init];
                loc=[locData objectAtIndex:i];
                
                NSString *query1;
                
                query1 = [NSString stringWithFormat:@"Select locUpdatedOn FROM RoadWorkOutLocation where locId = \"%@\"",loc.strLocationid];
                
                NSString *query = [NSString stringWithFormat:@"INSERT into RoadWorkOutLocation('locId','locName', 'locCategoryName','locDescription','locWebsite','locPhone','locZipcode','locAddress','locCity','locState','locContinent','locCountry','locLatitude','locLongitude','locYelpLink','locAddedOn','locUpdatedOn','locCategoryId','locDistance')VALUES(\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",loc.strLocationid,loc.strName,loc.strGenre,loc.strDescription,loc.strWebsite,loc.strPhone,loc.strZipcode,loc.strAddress,loc.strCity,loc.strState,loc.strContinent,loc.strCountry,loc.strLatitude,loc.strLongitude,loc.strYelpLink,loc.strAddedOn,loc.strUpdatedOn,loc.strCategoryId,loc.strDistance];
                @try
                {
                    [db open];
                    FMResultSet *resultSet = [db executeQuery:query1];
                    [resultSet next];
                    NSString *updateDate =  [resultSet stringForColumn:@"locUpdatedOn"];
                    [resultSet close];
                    if ([updateDate isEqualToString:loc.strUpdatedOn])
                    {
                        NSLog(@"already data exits ");
                    }
                    else
                    {
                        NSString *delQuery=[NSString stringWithFormat:@"delete  FROM RoadWorkOutLocation where locId = \"%@\"",loc.strLocationid];
                        
                        if ([db executeUpdate:delQuery])
                        {
                            NSLog(@"success in deletion");
                            if ([db executeUpdate:query])
                            {
                                NSLog(@"success in insertation");
                            }
                            else
                            {
                                NSLog(@"error in insertation");
                            }
                            
                        }
                        else
                        {
                            NSLog(@"error in deletionError");
                        }
                        
                    }
                    
                    
                    [db close];
                }
                @catch (NSException *e)
                {
                    NSLog(@"%@",e);
                }
            }

        }
        [db close];
        
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
}


-(void)getLocationListFromDatabase
{
    address=helpAddress;
    locationList = [[NSMutableArray alloc]init];
    arrLocationData = [[NSMutableArray alloc]init];
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    if(address == 1)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locCity like \"%@\" and locCategoryId = \"%@\"", strAddressName,strCategoryId];
    }
    else if(address == 2)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locState like \"%@\" and locCategoryId = \"%@\"", strAddressName,strCategoryId];
    }
    else if(address == 3)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locCountry like \"%@\" and locCategoryId =\"%@\"",strAddressName,strCategoryId];
    }
    else
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locAddress like \"%@\" and locCategoryId = \"%@\"", strAddressName,strCategoryId];
    }
    @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
            arrCategoryData = [[NSMutableArray alloc]init];
            while([resultSet next])
            {
                RWPlaceData *placeData = [[RWPlaceData alloc]init];
                placeData.strPlaceName = [resultSet stringForColumn:@"locName"];
                placeData.strLocationid = [resultSet stringForColumn:@"locId"];
                placeData.strPlaceLatitude = [resultSet stringForColumn:@"locLatitude"];
                placeData.strPlaceLongitude = [resultSet stringForColumn:@"locLongitude"];
                
                [arrLocationData addObject:placeData];
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"strDistance" ascending:YES];
    NSArray *arrSortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    
    locationList = [[arrLocationData sortedArrayUsingDescriptors:arrSortDescriptors] mutableCopy];
    if (locationList.count>0) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self performSegueWithIdentifier:@"LocationList" sender:self];
        });
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [HUD hide];
                           [[[UIAlertView alloc]initWithTitle:@"Message" message:@"Location Couldn't Find" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                       });
        
    }
}


-(NSString *)returnMyString:(NSString *)changeString
{
    NSString *mystr=[changeString substringToIndex:3];
    NSString *lastChar = [changeString substringFromIndex:3];
    NSString *finalStr = [NSString stringWithFormat:@"%@ ", mystr];
    finalStr = [finalStr stringByAppendingString:lastChar];
    return finalStr;
}

-(void)getDataFromDataBase
{
    NSString *addressDatabase=[searchBarLocation.text stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceCharacterSet]];
    address=helpAddress;
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    if(address == 1)
    {
        NSString *strZip;
        NSString *strZip1 = [searchBarLocation.text stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceCharacterSet]];
        if (strZip1.length==6)
        {
            strZip = [self returnMyString:strZip1];
        }
        else if(strZip1.length==7)
        {
            strZip=[strZip1 stringByReplacingOccurrencesOfString:@" " withString:@""];
        }
        
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locZipCode like \"%@\" or locZipCode like \"%@\"", strZip1, strZip];
    }
    else if(address == 2)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locCity like \"%@\"", addressDatabase];
    }
    else if(address == 3)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locState like \"%@\"", addressDatabase];
    }
    else if(address == 4)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locCountry like \"%@\"",addressDatabase];
    }
    else
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locAddress like \"%@\"",addressDatabase];
    }
    @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
            arrCategoryData = [[NSMutableArray alloc]init];
            while([resultSet next])
            {
                RWCategoryData *ListData = [[RWCategoryData alloc]init];
                ListData.strCategoryid = [resultSet stringForColumn:@"locCategoryId"];
                ListData.strCategoryName = [resultSet stringForColumn:@"locCategoryName"];
                
                [arrCategoryData addObject:ListData];
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    
    [self updateArrayWithCities];
}



-(void)updateArrayWithCities
{
    arrCategoryName = [[NSMutableArray alloc] init];
    for (int i = 0; i<[arrCategoryData count]; i++)
    {
        RWCategoryData *historyHolder = [[RWCategoryData alloc]init];
        historyHolder = [arrCategoryData objectAtIndex:i];
        
        [arrCategoryName addObject: historyHolder.strCategoryName];
    }
    
    NSArray *copy = [arrCategoryName copy];
    NSInteger index = [copy count] - 1;
    for (id object in [copy reverseObjectEnumerator]) {
        if ([arrCategoryName indexOfObject:object inRange:NSMakeRange(0, index)] != NSNotFound) {
            [arrCategoryName removeObjectAtIndex:index];
        }
        index--;
    }
    
    categoryList = [[NSMutableArray alloc]init];
    
    for(int i=0; i<[arrCategoryName count]; i++)
    {
        NSMutableArray *arrData = [[NSMutableArray alloc]init];
        int count=0;
        for(int j = 0; j<[arrCategoryData count]; j++)
        {
            RWCategoryData *historyHolder = [[RWCategoryData alloc]init];
            historyHolder = [arrCategoryData objectAtIndex:j];
            
            NSString *strDate1 = [arrCategoryName objectAtIndex:i];
            
            NSString *strDate2 = historyHolder.strCategoryName;
            
            if ([strDate1 isEqualToString:strDate2])
            {
                [arrData addObject:historyHolder];
                count++;
            }
        }
        categoryListData=[[RWCategoryData alloc]init];
        categoryListData=[arrData objectAtIndex:0];
        categoryListData.strCategoryName=[arrCategoryName objectAtIndex:i];
        categoryListData.strTotalPlaces=[NSString stringWithFormat:@"%d",count];
        [categoryList addObject:categoryListData];
        NSLog(@"%@", categoryList);
    }
   
    if (categoryList.count==0) {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        searchBarCategories.frame=CGRectMake(8, 72, 305, 44);
       
        [UIView commitAnimations];
        
        tblCategory.hidden=YES;
        lblCategory.hidden=NO;
        
    }
    else
    {
        strAddressName=[searchBarLocation.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        searchBarCategories.frame=CGRectMake(8, 122, 305, 44);
       
        [UIView commitAnimations];
        arrClassData = [categoryList mutableCopy];
        tblCategory.hidden=NO;
        lblCategory.hidden=YES;
        [tblCategory reloadData];
    }
}


///////////////////////////////////////DataBase End //////////////////////////////////////////////


-(IBAction)btnSchoolClicked:(id)sender
{
    if (arrSchool.count > 0) {
        self.popUp = [MLTableAlert tableAlertWithTitle:@"School List" cancelButtonTitle:@"" numberOfRows:^NSInteger (NSInteger section)
                      {
                          return [arrSchool count];
                      }
                                              andCells:^UITableViewCell* (MLTableAlert *anAlert, NSIndexPath *indexPath)
                      {
                          static NSString *CellIdentifier = @"CellIdentifier";
                          
                          UITableViewCell *cell = [anAlert.table dequeueReusableCellWithIdentifier:CellIdentifier];
                          if (cell == nil)
                              cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                            reuseIdentifier:CellIdentifier];
                          cell.backgroundColor = [UIColor clearColor];
                          
                          
                          if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
                              [cell setLayoutMargins:UIEdgeInsetsZero];
                          }
                          if ([anAlert.table respondsToSelector:@selector(setSeparatorInset:)]) {
                              [anAlert.table setSeparatorInset:UIEdgeInsetsZero];
                          }
                          
                          if ([anAlert.table respondsToSelector:@selector(setLayoutMargins:)]) {
                              [anAlert.table setLayoutMargins:UIEdgeInsetsZero];
                          }
                          
                          anAlert.table.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
                          
                      
                              cell.textLabel.text = [[arrSchool objectAtIndex:indexPath.row]valueForKey:@"school_name"];
                              cell.textLabel.textColor = [UIColor blackColor];
                              //cell.textLabel.text = [[aobjectAtIndex:indexPath.row]valueForKey:@"title"];
                        
                          
                          return cell;
                      }];
        
        // Setting custom alert height
        if([[UIDevice currentDevice]userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        {
            if ([[UIScreen mainScreen] bounds].size.height >= 568)
            {
                self.popUp.height = 500;
            }
            else
            {
                self.popUp.height = 420;
            }
        }
        else
        {
            //[ipad]
        }
        
        [self.popUp configureSelectionBlock:^(NSIndexPath *selectedIndex){
            
            
            
            searchBarLocation.text = [[arrSchool objectAtIndex:selectedIndex.row]valueForKey:@"school_name"];
            searchBarLocation.hidden = YES;
            lblschoolnames.hidden = NO;
            lblschoolnames.text = searchBarLocation.text;
           
            address=strAddressTag;
            
                [self geoCodeUsingAddress:searchBarLocation.text];
            
            
        } andCompletionBlock:^{
            
            
        }];
        
        // show the alert
        [self.popUp show];
    }else{
        
       
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
