//
//  RWPlaceCell.m
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWPlaceCell.h"

@implementation RWPlaceCell
@synthesize lblAddress,lblDistance,btnFavorite;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
