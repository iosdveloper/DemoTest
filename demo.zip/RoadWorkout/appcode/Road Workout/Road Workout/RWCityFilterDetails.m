//
//  RWCityFilterDetails.m
//  Road Workout
//
//  Created by user on 11/12/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWCityFilterDetails.h"

@implementation RWCityFilterDetails
@synthesize strAddress,strCityLatitude ,strCityLongitude,strCityName,strCityType;
@end
