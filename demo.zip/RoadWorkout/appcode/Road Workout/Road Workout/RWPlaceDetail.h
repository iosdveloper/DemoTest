//
//  RWPlaceDetail.h
//  Road Workout
//
//  Created by user on 16/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RWPlaceDetail : NSObject



@property(nonatomic, strong) NSString *strLocationid;
@property(nonatomic, strong) NSString *strName;
@property(nonatomic, strong) NSString *strGenre;
@property(nonatomic, strong) NSString *strDescription;
@property(nonatomic, strong) NSString *strWebsite;
@property(nonatomic, strong) NSString *strPhone;
@property(nonatomic, strong) NSString *strZipcode;
@property(nonatomic, strong) NSString *strAddress;
@property(nonatomic, strong) NSString *strCity;
@property(nonatomic, strong) NSString *strState;
@property(nonatomic, strong) NSString *strContinent;
@property(nonatomic, strong) NSString *strCountry;
@property(nonatomic, strong) NSString *strLatitude;
@property(nonatomic, strong) NSString *strLongitude;
@property(nonatomic, strong) NSString *strYelpLink;
@property(nonatomic, strong) NSString *strAddedOn;
@property(nonatomic, strong) NSString *strUpdatedOn;
@property(nonatomic, strong) NSString *strCategoryId;
@property(nonatomic, strong) NSString *strDistance;
@property(nonatomic, strong) NSString *strTicketUrl;
@property(nonatomic, strong) NSString *strSocial_link;
@property(nonatomic,strong)  NSString *strStartDate;
@property(nonatomic,strong)  NSString *strEndDate;
@property(nonatomic,strong)  NSString *strSchoolname;





@end
