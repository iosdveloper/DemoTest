//
//  RWSplashViewController.m
//  Road Workout
//
//  Created by Balkaran on 28/05/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import "RWSplashViewController.h"

@interface RWSplashViewController ()

@end

@implementation RWSplashViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self performSegueWithIdentifier:@"segue_splash" sender:nil];
    });    // Do any additional setup after loading the view.
}



@end
