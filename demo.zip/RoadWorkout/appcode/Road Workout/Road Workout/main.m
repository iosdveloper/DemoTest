//
//  main.m
//  Road Workout
//
//  Created by vishnu on 29/10/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//com.roadworkout.UConversation
//com.roadworkout.UConversation

#import <UIKit/UIKit.h>

#import "RWAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RWAppDelegate class]));
    }
}
