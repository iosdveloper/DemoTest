//
//  RWCategoryCell.h
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWCategoryCell : UITableViewCell


@property (nonatomic, retain)IBOutlet UILabel *lblTitle;
@property (nonatomic, retain)IBOutlet UILabel *lblCount;

@end
