//
//  Place.m
//
//  Created by Sugartin on 11/16/2012.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Place.h"


@implementation Place


@synthesize latitude;
@synthesize longitude;


@end
