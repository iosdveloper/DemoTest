//
//  RWViewController.h
//  Road Workout
//
//  Created by vishnu on 29/10/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "Validate.h"
#import <Social/Social.h>
#import <Accounts/Accounts.h>

@interface RWLoginViewController : UIViewController<UITextFieldDelegate>

{
    IBOutlet UIButton *btnCreateAccount;
    IBOutlet UIButton *btnSubmit;
    IBOutlet UIButton *btnSigninWithFacebook;
    
    IBOutlet UIImageView *imgLogo;
    
    IBOutlet UILabel *lblOr;
    
    IBOutlet UIView *viewWithOrLeft;
    IBOutlet UIView *viewWithOrRight;
    IBOutlet UIView *viewWithEmail;
    IBOutlet UIView *viewWithPassword;
    
    IBOutlet UITextField *txtEmail;
    IBOutlet UITextField *txtPassword;
    
    UIImageView *imgCover;
    
    NSArray *arrayOfAccounts;
    id facebookResponse;
    
    MBProgressHUD *HUD;
    
    NSURL *urlLogin;
    
    NSString *userId;
    NSString *strEmailId;
    
    BOOL isLoginFromFacebook;
}

-(IBAction)btnSubmitClicked:(id)sender;
-(IBAction)btnSignInWithFacebookClicked:(id)sender;

@end
