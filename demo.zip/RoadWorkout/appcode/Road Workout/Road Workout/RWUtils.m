//
//  RWCommonFunction.m
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWUtils.h"
#import "Reachability.h"

@implementation RWUtils



+ (NSString *) getDatabasePathFromName:(NSString *)dbName {
	return [self getDatabaseFolderPath:dbName];
}

+(NSString *) getDatabaseFolderPath : (NSString *)dbName {
	NSString *databaseName = [dbName stringByAppendingString:@".sqlite"];
	NSString *databasePath = [[self getDocumentsDirectoryPath] stringByAppendingPathComponent:databaseName];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	if([fileManager fileExistsAtPath:databasePath]) return databasePath;
	else {
		NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:databaseName];
        
		[fileManager copyItemAtPath:databasePathFromApp toPath:databasePath error:nil];
	}
	return databasePath;
}

+ (NSString *) getDocumentsDirectoryPath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	return [paths objectAtIndex:0];
}


+(BOOL)isConnectedToInternet
{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return !(networkStatus == NotReachable);
}
+(void)alertForNoInternetConnection
{
    [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"No internet connection" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil]show];
}

+(void)alertForServerNotResponding
{
    [[[UIAlertView alloc]initWithTitle:@"" message:@"Server not responding" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil]show];
}


@end
