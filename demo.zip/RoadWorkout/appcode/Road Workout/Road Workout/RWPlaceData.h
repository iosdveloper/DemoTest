//
//  RWPlaceData.h
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RWPlaceData : NSObject
{
    NSString *strLocationid;
    NSString *strPlaceName;
    NSString *strAddress;
    
}
@property(nonatomic,strong)NSString *strEventid;
@property(nonatomic,strong)NSString *strLocationid;
@property(nonatomic,strong)NSString *strPlaceName;
@property(nonatomic,strong)NSString *strPlaceCity;
@property(nonatomic,strong)NSString *strAddress;
@property(nonatomic)float strDistance;
@property(nonatomic,strong)NSString *strPlaceLatitude;
@property(nonatomic,strong)NSString *strPlaceLongitude;
@property(nonatomic,strong)NSString *strIsFavAdded;
@property(nonatomic,strong)NSString *strEnd_Date_Time;
@property(nonatomic,strong)NSString *strStart_Date_Time;
@property(nonatomic,strong)NSString *strCatName;
@property(nonatomic,strong)NSString *address;
@property(nonatomic,strong)NSString *category_id;
@property(nonatomic,strong)NSString *city_id;
@property(nonatomic,strong)NSString *city_name;
@property(nonatomic,strong)NSString *continent_id;
@property(nonatomic,strong)NSString *country_id;
@property(nonatomic,strong)NSString *description;
@property(nonatomic,strong)NSString *email;
@property(nonatomic,strong)NSString *end_date_time;
@property(nonatomic,strong)NSString *event_id;
@property(nonatomic,strong)NSString *event_name;
@property(nonatomic,strong)NSString *event_website;
@property(nonatomic,strong)NSString *featured_listing;
@property(nonatomic,strong)NSString *phone;
@property(nonatomic,strong)NSString *school_id;
@property(nonatomic,strong)NSString *start_date_time;
@property(nonatomic,strong)NSString *state_id;
@property(nonatomic,strong)NSString *ticket_url;
@property(nonatomic,strong)NSString *userid;
@property(nonatomic,strong)NSString *zip_code;
@property(nonatomic,strong)NSString *state_name;
@property(nonatomic,strong)NSString *country_name;
@property(nonatomic,strong)NSString *continent_name;
@property(nonatomic,strong)NSString *school_name;
@property(nonatomic,strong)NSString *category_name;

@end

