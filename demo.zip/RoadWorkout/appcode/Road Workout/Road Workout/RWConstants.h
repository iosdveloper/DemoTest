//
//  RWConstants.h
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>


#define IS_IPHONE_5 ([[UIScreen mainScreen] bounds].size.height == 568)
#define IDIOM    UI_USER_INTERFACE_IDIOM()
#define IPHONE     UIUserInterfaceIdiomPhone

//#define FbClientID @"222391174606689"
#define FbClientID @"1048673521818561"
#define MAIN_URL @"http://182.237.17.106:8080/uconversation/services/"
//#define MAIN_URL @"http://192.168.1.200:8080/roadworkout/services/"
//#define MAIN_URL @"http://122.176.45.15:8080/roadworkout/services/"
//#define MAIN_URL @"http://www.myroadworkout.com/MRWLocationApp/services/"
#define URL_LOGIN [NSString stringWithFormat:@"%@login", MAIN_URL];
#define URL_FORGOTPASSWORD [NSString stringWithFormat:@"%@forgotpassword", MAIN_URL];
#define URL_USER_REGISTRATION [NSString stringWithFormat:@"%@userregistration", MAIN_URL];
#define URL_CATEGORY_LIST [NSString stringWithFormat:@"%@categorylist", MAIN_URL];
#define URL_LOCATION_LIST [NSString stringWithFormat:@"%@placeslist", MAIN_URL];
#define URL_CHANGE_PASSWORD [NSString stringWithFormat:@"%@changepassword", MAIN_URL];
#define URL_LOCATION_DETAIL [NSString stringWithFormat:@"%@placeslistdetail", MAIN_URL];
#define URL_ADD_FAVORITE [NSString stringWithFormat:@"%@setplace", MAIN_URL];
#define URL_FAVORITE [NSString stringWithFormat:@"%@getplace", MAIN_URL];
#define URL_DELETE_FAVORITE [NSString stringWithFormat:@"%@deletefavorite", MAIN_URL];

#define URL_MYEVENT [NSString stringWithFormat:@"%@myevent", MAIN_URL];
#define URL_DELETE_MYEVENTS [NSString stringWithFormat:@"%@deleteevent", MAIN_URL];
#define URL_EDIT_MYEVENTS [NSString stringWithFormat:@"%@editevent", MAIN_URL];

//#define URL_GETALLSCHOOL [NSString stringWithFormat:@"%@getallschool", MAIN_URL];

#define URL_LOCATION_DATA [NSString stringWithFormat:@"%@getlocationdata", MAIN_URL];

#define URL_CONTINENT_DATA [NSString stringWithFormat:@"%@getcontinent", MAIN_URL];
#define URL_COUNTRY_DATA [NSString stringWithFormat:@"%@getcountry", MAIN_URL];
#define URL_STATE_DATA [NSString stringWithFormat:@"%@getstate", MAIN_URL];
#define URL_CITY_DATA [NSString stringWithFormat:@"%@getcity", MAIN_URL];
#define URL_GET_ALL_SCHOOL [NSString stringWithFormat:@"%@getallschool", MAIN_URL];
#define URL_GET_ALL_CATEGORIES [NSString stringWithFormat:@"%@getallcategories", MAIN_URL];
#define URL_ADD_EVENT [NSString stringWithFormat:@"%@addevent", MAIN_URL];
#define CURRENTLOG @"currentlog"
#define CURRENTLET @"currentlet"
@interface RWConstants : NSObject

@end
