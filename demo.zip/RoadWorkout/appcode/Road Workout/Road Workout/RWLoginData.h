//
//  RWLoginData.h
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RWLoginData : NSObject

{
    NSString *strName;
    NSString *strUserId;
    NSString *strAddedOn;
    NSString *strEmail;
}

@property(nonatomic, strong) NSString *strName;
@property(nonatomic, strong) NSString *strUserId;
@property(nonatomic, strong) NSString *strAddedOn;
@property(nonatomic, strong) NSString *strEmail;

@end
