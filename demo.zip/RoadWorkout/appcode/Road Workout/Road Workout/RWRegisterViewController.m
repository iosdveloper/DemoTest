//
//  RWRegisterViewController.m
//  Road Workout
//
//  Created by user on 11/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWRegisterViewController.h"
#import "RWConstants.h"
#import "RWCategoriesListViewController.h"
@interface RWRegisterViewController ()

@end

@implementation RWRegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    isRegFromFacebook = NO;
    btnsubmit.layer.cornerRadius =  4.0f;
   // btnsubmit.layer.borderWidth = 0.5;
    btnsubmit.layer.masksToBounds =YES;
    btnFB.layer.cornerRadius = 4.0f;
    btnFB.layer.masksToBounds = YES;
    
    self.navigationController.navigationBarHidden=YES;
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
  if(!isAtLeast7)
        {
            UIImage* imageDone = [UIImage imageNamed:@"btn-done.png"];
            CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
            UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
            [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
            [doneBtn addTarget:self action:@selector(done:)
              forControlEvents:UIControlEventTouchUpInside];
            
            btnCan =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
            self.navigationItem.leftBarButtonItem = btnCan;
            self.navigationItem.hidesBackButton = YES;
             [navBar pushNavigationItem:self.navigationItem animated:NO];
            
            navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
            
            self.navigationItem.title=@"Create New Account";
            
            if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
            {
                [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                [UIColor whiteColor], UITextAttributeTextColor,
                                                [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                                nil]];
                [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
            }
        }
    
  	NSString *strUserRegistration = URL_USER_REGISTRATION;
    urlRegistration = [[NSURL alloc]initWithString:strUserRegistration];
    
}

-(void)viewDidAppear:(BOOL)animated
{
    
    [super viewDidAppear:animated];
    
}

-(IBAction)btnSubmitClicked:(id)sender
{
    BOOL isValid = YES;
    
    if(!txtFirstName.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter first name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtLastName.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter last name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    
    else if (![Validate isValidEmailId:txtEmail.text])
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter valid email address" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }
    else if(!txtPassword.text.length > 0)
    {
        isValid = NO;
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter password" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
    else if(![txtConfirmPassword.text isEqualToString:txtPassword.text])
    {
        isValid = NO;
        [[[UIAlertView alloc] initWithTitle:@"" message:@"password does not match" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    } else if(!txtSchool.text.length > 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"please enter School name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        isValid = NO;
    }

    

    
    if(isValid)
    {
        [txtEmail resignFirstResponder];
        [txtLastName resignFirstResponder];
        [txtPassword resignFirstResponder];
        [txtFirstName resignFirstResponder];
        [txtConfirmPassword resignFirstResponder];
        [txtSchool resignFirstResponder];
        [txtPhone resignFirstResponder];
     //   strPnoneNumber =
        NSString *s = txtPhone.text;
        NSString *s1= [s stringByReplacingOccurrencesOfString:@" " withString:@""];
         NSString *s2 = [s1 stringByReplacingOccurrencesOfString:@"(" withString:@""];
         NSString *s3 = [s2 stringByReplacingOccurrencesOfString:@")" withString:@""];
          strPnoneNumber = [s3 stringByReplacingOccurrencesOfString:@"-" withString:@""];

        if([RWUtils isConnectedToInternet])
        {
            isRegFromFacebook = NO;
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(userRegistration) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }
}

-(IBAction)done:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(IBAction)btnRegisterWithFacebookclicked:(id)sender
{
    if([RWUtils isConnectedToInternet])
    {
        isRegFromFacebook = YES;
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD show];
        NSLog(@"Here");
        [self performSelectorInBackground:@selector(loginWithFacebook) withObject:nil];
    }
    
    else
    {
        [RWUtils alertForNoInternetConnection];
    }
}

-(void)loginWithFacebook
{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        ACAccountStore *account = [[ACAccountStore alloc] init];
        ACAccountType *accountType1 = [account accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
        NSDictionary *options = @{ ACFacebookAppIdKey: FbClientID, ACFacebookPermissionsKey: @[@"user_birthday",@"user_hometown",@"user_location",@"email",@"basic_info,user_photos"], ACFacebookAudienceKey: ACFacebookAudienceEveryone };
        // Request access from the user to use their Facebook accounts.
        [account requestAccessToAccountsWithType:accountType1 options:options completion:^(BOOL granted, NSError *error){
            
            // Did user allow us access?
            if (granted == YES)
            {
                // Populate array with all available Twitter accounts
                arrayOfAccounts = [account accountsWithAccountType:accountType1];
                userId = [NSString stringWithFormat:@"%@", [[[arrayOfAccounts valueForKey:@"properties"] valueForKey:@"uid"] objectAtIndex:0]];
                // Populate the tableview
                if ([arrayOfAccounts count] > 0)
                    [self requestForFacebook];
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                [HUD hide];
                [[[UIAlertView alloc] initWithTitle:@"" message:@"unable to login with facebook." delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
                });
            }
        }];
    }
    else
    {
         dispatch_async(dispatch_get_main_queue(), ^{
        [HUD hide];
        [[[UIAlertView alloc]initWithTitle:@"Message" message:@"Please login to Facebook in settings." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
         });
    }
}



-(void)requestForFacebook
{
    [self updateFacebook];
}

-(void)updateFacebook
{
    ACAccountStore *account_store = [[ACAccountStore alloc] init];
    ACAccountType *account_type_facebook = [account_store accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
    
    arrayOfAccounts = [account_store accountsWithAccountType:account_type_facebook];
    if (arrayOfAccounts.count>0) {
        ACAccount *acc = [arrayOfAccounts objectAtIndex:0];
        NSURL *url = [NSURL URLWithString:[@"https://graph.facebook.com" stringByAppendingPathComponent:userId]];
        SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                                requestMethod:SLRequestMethodGET
                                                          URL:url
                                                   parameters:nil];
        request.account = acc;
        [request performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
            NSLog(@"Facebook request received, status code %ld", (long)urlResponse.statusCode);
            NSString *response = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSLog(@"Response data: %@", response);
            if(error != nil)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Error"
                                                                message:@"There was an error talking to Facebook. Please try again later."
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
                [alert show];
                });
                [HUD hide];
                return;
            }
            
            // Parse the JSON response
            NSError *jsonError = nil;
            facebookResponse = [NSJSONSerialization JSONObjectWithData:responseData
                                                               options:0
                                                                 error:&jsonError];
            
            if(jsonError != nil)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Error"
                                                                message:@"Facebook is not acting properly right now. Please try again later."
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
                [alert show];
                });
                [HUD hide];
                return;
            }
            NSLog(@"%@", facebookResponse);
            [self FBGraphResponse];
            
        }];
    }else
    {
        dispatch_async(dispatch_get_main_queue(), ^{
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Error"
                                                        message:@"Facebook is not acting properly right now. Please try again later."
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [HUD hide];
        });
        return;
    }
}

- (void)FBGraphResponse
{
    @try
    {
        if (facebookResponse)
        {
            userId=[NSString stringWithFormat:@"%@",[facebookResponse objectForKey:@"id"]];
            strEmailId = [facebookResponse objectForKey:@"email"];
            strFirstName = [facebookResponse objectForKey:@"first_name"];
            strLastName = [facebookResponse objectForKey:@"last_name"];
            [self userRegistration];
            
        }else
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
            [HUD hide];
            [[[UIAlertView alloc] initWithTitle:@"" message:@"unable to login with facebook." delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
                           });
        }
        
    }
    @catch (NSException *exception)
    {
       
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                            [HUD hide];
                           UIAlertView *objALert = [[UIAlertView alloc]initWithTitle:@"Alert" message:[NSString stringWithFormat:@"Something bad happened due to %@",[exception reason]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                           [objALert show];
                       });
    }
    
}

/////////////////////// API Calling /////////////////////

-(void)userRegistration
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlRegistration];
    
    if(isRegFromFacebook)
    {
        [request setPostValue:strEmailId forKey:@"email"];
        [request setPostValue:strFirstName forKey:@"firstname"];
        [request setPostValue:strLastName forKey:@"lastname"];
        [request setPostValue:@"F" forKey:@"regfrom"];
    }
    else
    {
        [request setPostValue:txtEmail.text forKey:@"email"];
        [request setPostValue:txtPassword.text forKey:@"password"];
        [request setPostValue:txtFirstName.text forKey:@"firstname"];
        [request setPostValue:txtLastName.text forKey:@"lastname"];
        [request setPostValue:txtSchool.text forKey:@"school_name"];
        [request setPostValue:strPnoneNumber forKey:@"phone"];
        [request setPostValue:@"S" forKey:@"regfrom"];
    }
    
    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(requestForForgotPasswordFail:)];
    [request setDidFinishSelector:@selector(requestForForgotPasswordSuccess:)];
    [request startSynchronous];
}

-(void)requestForForgotPasswordFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                       [HUD hide];
                   });
}

-(void)requestForForgotPasswordSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    SBJSON *parser=[[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
    
    if(responseDict)
    {
        NSString *status= [responseDict objectForKey:@"error_code"];
        
        if (![status isEqualToString:@"0"])
        {
            NSString *strErrorMessage = [responseDict valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
        else
        {
            loginData = [[RWLoginData alloc] init];
            
            loginData.strUserId = [responseDict valueForKey:@"userid"];
        
            NSString *strSchool = [responseDict objectForKey:@"school"];
            NSString *strSchoolId = [responseDict objectForKey:@"school_id"];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            
            [prefs setObject:strSchool forKey:@"SchoolName"];
            [prefs setObject:strSchoolId forKey:@"SchoolId"];
            
            [[NSUserDefaults standardUserDefaults] setObject:loginData.strUserId forKey:@"userid"];
            
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"email"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userid"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"password"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"Remember"];
            [[NSUserDefaults standardUserDefaults] synchronize];

            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               if (isRegFromFacebook==NO)
                               {
                                   UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Save your Login Details?", nil) message:NSLocalizedString(@"Would you like The Blue Tack to \nremember your login credentials?", nil) delegate:self cancelButtonTitle:NSLocalizedString(@"No, Thanks" , nil) otherButtonTitles:NSLocalizedString(@"Yes Please!" , nil), nil];
                                   [alertView show];
                               }
                               else
                               {
                                   [[NSUserDefaults standardUserDefaults] setObject:txtEmail.text forKey:@"email"];
                                   [[NSUserDefaults standardUserDefaults] setObject:loginData.strUserId forKey:@"userid"];
                                   [self performSegueWithIdentifier:@"regToCategory" sender:self];
                               }
                          

                           
                           });
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [HUD hide];
                           [RWUtils alertForServerNotResponding];
                       });
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (alertView.cancelButtonIndex == buttonIndex)
    {
        [[NSUserDefaults standardUserDefaults] setObject:loginData.strUserId forKey:@"userid"];
        [[NSUserDefaults standardUserDefaults] setObject:txtEmail.text forKey:@"email"];
        [self performSegueWithIdentifier:@"regToCategory" sender:self];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"Rememberme"];
        [[NSUserDefaults standardUserDefaults] setObject:loginData.strUserId forKey:@"userid"];
        [[NSUserDefaults standardUserDefaults] setObject:txtEmail.text forKey:@"email"];
        [[NSUserDefaults standardUserDefaults] setObject:txtPassword.text forKey:@"password"];
        [[NSUserDefaults standardUserDefaults] setObject:@"yes" forKey:@"Remember"];
        [[NSUserDefaults standardUserDefaults] synchronize];
       [self performSegueWithIdentifier:@"regToCategory" sender:self];
    }
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    int length = [self getLength:txtPhone.text];
    //NSLog(@"Length  =  %d ",length);
    
    if(length == 10)
    {
        if(range.length == 0)
            return NO;
    }
    
    if(length == 3)
    {
        NSString *num = [self formatNumber:textField.text];
        txtPhone.text = [NSString stringWithFormat:@"(%@) ",num];
        if(range.length > 0)
            txtPhone.text = [NSString stringWithFormat:@"%@",[num substringToIndex:3]];
    }
    else if(length == 6)
    {
        NSString *num = [self formatNumber:textField.text];
        //NSLog(@"%@",[num  substringToIndex:3]);
        //NSLog(@"%@",[num substringFromIndex:3]);
        txtPhone.text = [NSString stringWithFormat:@"(%@) %@-",[num  substringToIndex:3],[num substringFromIndex:3]];
        if(range.length > 0)
            txtPhone.text = [NSString stringWithFormat:@"(%@) %@",[num substringToIndex:3],[num substringFromIndex:3]];
    }
    
    return YES;
}

-(NSString*)formatNumber:(NSString*)mobileNumber
{
    
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    NSLog(@"%@", mobileNumber);
    
    int length = [mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
        NSLog(@"%@", mobileNumber);
        
    }
    
    
    return mobileNumber;
}


-(int)getLength:(NSString*)mobileNumber
{
    
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    int length = [mobileNumber length];
    
    return length;
    
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnSchoolDidClicked:(id)sender {
    [txtEmail resignFirstResponder];
    [txtLastName resignFirstResponder];
    [txtPassword resignFirstResponder];
    [txtFirstName resignFirstResponder];
    [txtConfirmPassword resignFirstResponder];
    [txtSchool resignFirstResponder];
    [txtPhone resignFirstResponder];
    [self performSegueWithIdentifier:@"Segue_school_list" sender:nil];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"Segue_school_list"])
    {
        RWCategoriesListViewController*obCatandSchool = (RWCategoriesListViewController*)[segue destinationViewController];
        obCatandSchool.delegate = (id)self;
        obCatandSchool.yourTitle =@"School";
    }
    
}
-(void)setSchoolId:(NSString *)school_id name:(NSString *)School_name{
    txtSchool.text = School_name;
 
}
@end
