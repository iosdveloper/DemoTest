//
//  RWMyEventsViewController.h
//  Road Workout
//
//  Created by Ashish kumar on 26/06/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "RWSeachBar.h"
#import "RWPlaceDetail.h"
@interface RWMyEventsViewController : UIViewController<UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource>
{
NSMutableArray *arrMyEventsList;
NSMutableArray *arrCities;
NSMutableArray *arrHistoryDetails;
NSMutableArray *arrClassData;
NSMutableArray *arrSearchData;
 NSMutableArray *arrMyEvntEditList;

IBOutlet RWSeachBar *searchBarCategories;

//RWPlaceDetail *locationDetail;
MBProgressHUD *HUD;

IBOutlet UIView *container;
IBOutlet UITableView *tblMyEvents;
IBOutlet UIBarButtonItem *btnBack;
IBOutlet UINavigationBar *navBar;

NSString *strLocationId;
NSString *strfavLocationID;
NSString *currentSearchText;
    
NSString *strEventId;
NSString *strMyEventId;
    
NSURL *urlLocationDetail;

}
@property(nonatomic,retain)NSMutableArray *arrMyEventsList;
- (IBAction)btnBAck:(id)sender;

@end
