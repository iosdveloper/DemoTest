//
//  RWCategoriesListViewController.m
//  Road Workout
//
//  Created by Balkaran on 24/03/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import "RWCategoriesListViewController.h"

@implementation RWCategoriesListViewController

@synthesize yourTitle,delegate;
- (void)viewDidLoad{
    
    UIImage* userLoaction = [UIImage imageNamed:@"btn_back.png"];
    CGRect imgBackframe = CGRectMake(0, 0, userLoaction.size.width, userLoaction.size.height);
    UIButton *backBtn = [[UIButton alloc] initWithFrame:imgBackframe];
    [backBtn setBackgroundImage:userLoaction forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(back:)
      forControlEvents:UIControlEventTouchUpInside];
    btnBack =[[UIBarButtonItem alloc] initWithCustomView:backBtn];
    
    
    self.navigationItem.leftBarButtonItem = btnBack;
    self.navigationItem.hidesBackButton = YES;
    
    
    [navBar pushNavigationItem:self.navigationItem animated:NO];
    navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
    
    self.navigationItem.title = yourTitle;
    
    if([yourTitle isEqualToString:@"Categories"])
    {
        NSString *strContinet = URL_GET_ALL_CATEGORIES;
        url = [[NSURL alloc]initWithString:strContinet];
        
    }
    else  if([yourTitle isEqualToString:@"School"])
    {
        NSString *strContinet = URL_GET_ALL_SCHOOL;
        url = [[NSURL alloc]initWithString:strContinet];
        
    }
    
    [self getCategories];
 
}
-(void)getCategories{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:url];
  
    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getCategoriesFail:)];
    [request setDidFinishSelector:@selector(getCategoriesSuccess:)];
    [request startSynchronous];
    
}

-(void)getCategoriesFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getCategoriesSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
           arryInfo = [responseData valueForKey:@"data"];
            
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    [tableCat reloadData];
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return arryInfo.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"categoriesCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:CellIdentifier];
    }
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    NSString *strInfo;
    if([yourTitle isEqualToString:@"Categories"])
    {
        strInfo =[[arryInfo objectAtIndex:indexPath.row] valueForKey:@"category_name"];
        
    }
    if([yourTitle isEqualToString:@"School"])
    {
        strInfo =[[arryInfo objectAtIndex:indexPath.row] valueForKey:@"school_name"];
        
    }
   

    UILabel *lblinfo = (UILabel*)[cell.contentView viewWithTag:1];
    lblinfo.text = strInfo;
    return cell;
    
}





#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([yourTitle isEqualToString:@"Categories"])
    {
        NSString *strid =[[arryInfo objectAtIndex:indexPath.row] valueForKey:@"category_id"];
        NSString *strName =[[arryInfo objectAtIndex:indexPath.row] valueForKey:@"category_name"];
        [delegate setCategoriesId:strid name:strName];
        
    }
    if([yourTitle isEqualToString:@"School"])
    {
        NSString *strid =[[arryInfo objectAtIndex:indexPath.row] valueForKey:@"id"];
        NSString *strName =[[arryInfo objectAtIndex:indexPath.row] valueForKey:@"school_name"];
        [delegate setSchoolId:strid name:strName];
        
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)back:(id)sender
{
    
   
    [self.navigationController popViewControllerAnimated:YES];
}
@end
