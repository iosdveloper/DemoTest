//
//  RWCategoriesListViewController.h
//  Road Workout
//
//  Created by Balkaran on 24/03/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
@protocol AddCategoriesSchoolInfoDelegate<NSObject>
-(void)setCategoriesId:(NSString *)categories_id name:(NSString *)categories_name;
-(void)setSchoolId:(NSString *)school_id name:(NSString *)School_name;

@end
@interface RWCategoriesListViewController : UIViewController
{
    MBProgressHUD *HUD;
    NSURL *url;
    NSArray *arryInfo;
    IBOutlet UIBarButtonItem *btnBack;
    IBOutlet UINavigationBar *navBar;
    IBOutlet UITableView *tableCat;
}
@property(nonatomic,strong) NSString *yourTitle;
@property(nonatomic,assign) id<AddCategoriesSchoolInfoDelegate> delegate;
@end
