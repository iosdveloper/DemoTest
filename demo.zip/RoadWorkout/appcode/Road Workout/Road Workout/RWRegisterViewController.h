//
//  RWRegisterViewController.h
//  Road Workout
//
//  Created by user on 11/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SBJSON.h"
#import "ASIFormDataRequest.h"
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "MBProgressHUD.h"
#import "Validate.h"
#import <Accounts/Accounts.h>
#import <Social/Social.h>
#import "RWUtils.h"

@interface RWRegisterViewController : UIViewController<UITextFieldDelegate>

{
    NSURL *urlRegistration;
    
    IBOutlet UITextField *txtFirstName;
    IBOutlet UITextField *txtLastName;
    IBOutlet UITextField *txtPassword;
    IBOutlet UITextField *txtConfirmPassword;
    IBOutlet UITextField *txtEmail;
    IBOutlet UITextField *txtPhone;
    IBOutlet UITextField *txtSchool;
    IBOutlet UIBarButtonItem *btnCan;
    IBOutlet UINavigationBar *navBar;
    IBOutlet UIButton *btnsubmit;
    IBOutlet UIButton *btnFB;
    NSString *strPnoneNumber;
    
    IBOutlet UIImageView *imvBorder;
    
    IBOutlet UILabel *lblBorder;
    
    
    MBProgressHUD *HUD;
    
    NSString *userId;
    NSString *strEmailId;
    NSString *strFirstName;
    NSString *strLastName;
    
    NSArray *arrayOfAccounts;
    
    id facebookResponse;
    
    BOOL isRegFromFacebook;
    
   
    
}

-(IBAction)done:(id)sender;
-(IBAction)btnSubmitClicked:(id)sender;
-(IBAction)btnRegisterWithFacebookclicked:(id)sender;


@end
