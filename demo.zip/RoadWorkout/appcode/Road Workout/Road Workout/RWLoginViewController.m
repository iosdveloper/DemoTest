//
//  RWViewController.m
//  Road Workout
//
//  Created by vishnu on 29/10/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWLoginViewController.h"
#import "RWCategoriesViewController.h"

@interface RWLoginViewController ()

@end

@implementation RWLoginViewController

- (void)viewDidLoad
{

    
    [super viewDidLoad];
    btnSubmit.layer.cornerRadius = 4.0f;
    btnSubmit.layer.masksToBounds=YES;
    btnSigninWithFacebook.layer.masksToBounds = YES;
    btnSigninWithFacebook.layer.cornerRadius = 4.0f;
    //viewWithEmail.layer.cornerRadius = 4.0f;
    viewWithEmail.layer.masksToBounds = YES;
    viewWithEmail.layer.borderColor = [UIColor lightGrayColor].CGColor;
    viewWithEmail.layer.borderWidth = 0.5;
    //viewWithPassword.layer.cornerRadius = 4.0f;
    viewWithPassword.layer.masksToBounds = YES;
    viewWithPassword.layer.borderColor= [UIColor lightGrayColor].CGColor;
    viewWithPassword.layer.borderWidth = 0.5;
    
    self.navigationController.navigationBarHidden=YES;
   
        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"Rememberme"] isEqualToString:@"logout"])
        {
             txtEmail.text=[[NSUserDefaults standardUserDefaults] valueForKey:@"email"];
        }
        else if([[[NSUserDefaults standardUserDefaults] valueForKey:@"Remember"] isEqualToString:@"yes"])
        {
            RWCategoriesViewController *vc = (RWCategoriesViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"categoryPage"];
            [self.navigationController pushViewController:vc animated:YES];

        }
  

	if(!IS_IPHONE_5)
    {
        imgLogo.frame = CGRectMake(59, 69, 202, 130);
        viewWithEmail.frame = CGRectMake(31, 216, 258, 33);
        viewWithPassword.frame = CGRectMake(31, 252, 258, 33);
        btnSubmit.frame = CGRectMake(31, 299, 258, 33);
        btnSigninWithFacebook.frame = CGRectMake(31, 411, 258, 33);
        viewWithOrLeft.frame = CGRectMake(31, 351, 110, 1);
        viewWithOrRight.frame = CGRectMake(179, 351, 110, 1);
        lblOr.frame = CGRectMake(152, 341, 110, 21);
        btnCreateAccount.frame = CGRectMake(75, 372, 170, 30);
    }
    else
    {
        imgLogo.frame = CGRectMake(59, 85, 202, 130);
        viewWithEmail.frame = CGRectMake(31, 245, 258, 33);
        viewWithPassword.frame = CGRectMake(31, 281, 258, 33);
        btnSubmit.frame = CGRectMake(31, 335, 258, 33);
        btnSigninWithFacebook.frame = CGRectMake(31, 480, 258, 33);
        viewWithOrLeft.frame = CGRectMake(31, 395, 110, 1);
        viewWithOrRight.frame = CGRectMake(179, 395, 110, 1);
        lblOr.frame = CGRectMake(152, 385, 110, 21);
        btnCreateAccount.frame = CGRectMake(75, 425, 170, 30);
    }
    
    NSString *strLoginUrl = URL_LOGIN;
    urlLogin = [[NSURL alloc]initWithString:strLoginUrl];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    isLoginFromFacebook = NO;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    txtEmail.text=nil;
    txtPassword.text=nil;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtEmail resignFirstResponder];
    [txtPassword resignFirstResponder];
    [self setViewOnResignTextField];
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    if(IS_IPHONE_5)
    {
        self.view.frame = CGRectMake(0, -20, 320, 568);
    }
    else
    {
        self.view.frame = CGRectMake(0, -20, 320, 480);
    }
    
    [UIView commitAnimations];
    return YES;
}



-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self setViewOnResignTextField];
    return YES;
}



-(void)setViewOnResignTextField
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    if(IS_IPHONE_5)
    {
        self.view.frame = CGRectMake(0, 0, 320, 568);
    }
    else
    {
        self.view.frame = CGRectMake(0, 0, 320, 480);
    }
    
    [UIView commitAnimations];
}




-(IBAction)btnSignInWithFacebookClicked:(id)sender
{
    if([RWUtils isConnectedToInternet])
    {
        isLoginFromFacebook = YES;
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD show];
        NSLog(@"Here");
        [self performSelectorInBackground:@selector(loginWithFacebook) withObject:nil];
    }
    
    else
    {
        [RWUtils alertForNoInternetConnection];
    }
}




-(void)loginWithFacebook
{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        ACAccountStore *account = [[ACAccountStore alloc] init];
        ACAccountType *accountType1 = [account accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
        NSDictionary *options = @{ ACFacebookAppIdKey: FbClientID, ACFacebookPermissionsKey: @[@"user_birthday",@"user_hometown",@"user_location",@"email",@"basic_info,user_photos"], ACFacebookAudienceKey: ACFacebookAudienceEveryone };
        // Request access from the user to use their Facebook accounts.
        [account requestAccessToAccountsWithType:accountType1 options:options completion:^(BOOL granted, NSError *error){
            
            // Did user allow us access?
            if (granted == YES)
            {
                // Populate array with all available Facebook accounts
                arrayOfAccounts = [account accountsWithAccountType:accountType1];
                userId = [NSString stringWithFormat:@"%@", [[[arrayOfAccounts valueForKey:@"properties"] valueForKey:@"uid"] objectAtIndex:0]];
                // Populate the tableview
                if ([arrayOfAccounts count] > 0)
                    [self requestForFacebook];
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                [HUD hide];
                [[[UIAlertView alloc] initWithTitle:@"" message:@"unable to login with facebook." delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
                });
            }
        }];
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^{
        [HUD hide];
        [[[UIAlertView alloc]initWithTitle:@"Message" message:@"Please login to Facebook in settings." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
        });
    }
}





-(void)requestForFacebook
{
    [self updateFacebook];
}





-(void)updateFacebook
{
    ACAccountStore *account_store = [[ACAccountStore alloc] init];
    ACAccountType *account_type_facebook = [account_store accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
    
    arrayOfAccounts = [account_store accountsWithAccountType:account_type_facebook];
    if (arrayOfAccounts.count>0) {
        ACAccount *acc = [arrayOfAccounts objectAtIndex:0];
        NSURL *url = [NSURL URLWithString:[@"https://graph.facebook.com" stringByAppendingPathComponent:userId]];
        SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                                requestMethod:SLRequestMethodGET
                                                          URL:url
                                                   parameters:nil];
        request.account = acc;
        [request performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
            NSLog(@"Facebook request received, status code %ld", (long)urlResponse.statusCode);
            NSString *response = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSLog(@"Response data: %@", response);
            if(error != nil)
            {
                dispatch_async(dispatch_get_main_queue(),^{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Error"
                                                                message:@"There was an error talking to Facebook. Please try again later."
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
                [alert show];
                });
                [HUD hide];
                return;
            }
            
            // Parse the JSON response
            NSError *jsonError = nil;
            facebookResponse = [NSJSONSerialization JSONObjectWithData:responseData
                                                               options:0
                                                                 error:&jsonError];
            
            if(jsonError != nil)
            {
                dispatch_async(dispatch_get_main_queue(),^{
                  
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Error"
                                                                    message:@"Facebook is not acting properly right now. Please try again later."
                                                                   delegate:nil
                                                          cancelButtonTitle:@"OK"
                                                          otherButtonTitles:nil];
                    [alert show];

                
                });
                
                
                               [HUD hide];
                return;
            }
            NSLog(@"%@", facebookResponse);
            [self FBGraphResponse];
            
        }];
    }else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Error"
                                                        message:@"Facebook is not acting properly right now. Please try again later."
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [HUD hide];
                       });
        return;
    }
}





- (void)FBGraphResponse
{
    @try
    {
        if (facebookResponse)
        {
            userId=[NSString stringWithFormat:@"%@",[facebookResponse objectForKey:@"id"]];
            strEmailId = [facebookResponse objectForKey:@"email"];
            [self login];
            
        }else
        {
            [HUD hide];
            dispatch_async(dispatch_get_main_queue(), ^{
            [[[UIAlertView alloc] initWithTitle:@"" message:@"unable to login with facebook." delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
            });
        }
        
    }
    @catch (NSException *exception)
    {
        [HUD hide];
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           UIAlertView *objALert = [[UIAlertView alloc]initWithTitle:@"Alert" message:[NSString stringWithFormat:@"Something bad happened due to %@",[exception reason]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                           [objALert show];
                       });
    }
    
}





-(IBAction)btnSubmitClicked:(id)sender
{
    BOOL isValid = YES;
    
    if (![Validate isValidEmailId:txtEmail.text])
    {
        [[[UIAlertView alloc]initWithTitle:@"" message:@"email is not valid" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
        isValid = NO;
    }else
        if (txtPassword.text.length == 0)
        {
            [[[UIAlertView alloc]initWithTitle:@"" message:@"please enter password" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
            isValid = NO;
        }
    
    
    if(isValid)
    {
        isLoginFromFacebook = NO;
        [txtPassword resignFirstResponder];
        [txtEmail resignFirstResponder];
        [self setViewOnResignTextField];
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(login) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }
}





-(void)login
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLogin];
    
    
    if(isLoginFromFacebook == YES)
    {
        [request setPostValue:strEmailId forKey:@"username"];
        [request setPostValue:@"F" forKey:@"loginfrom"];
    }
    else
    {
        [request setPostValue:txtEmail.text forKey:@"username"];
        [request setPostValue:@"S" forKey:@"loginfrom"];
        [request setPostValue:txtPassword.text forKey:@"password"];
    }
    [request setDelegate:self];
    [request setDidFailSelector:@selector(requestForLoginFail:)];
    [request setDidFinishSelector:@selector(requestForLoginSuccess:)];
    [request startSynchronous];
}





-(void)requestForLoginFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [HUD hide];
                       [RWUtils alertForServerNotResponding];
                   });
}



-(void)requestForLoginSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    SBJSON *parser=[[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
    
    if(responseDict)
    {
        NSString *status= [responseDict objectForKey:@"error_code"];
        
        if (![status isEqualToString:@"0"])
        {
          
            
            NSString *strErrorMessage = [responseDict valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
        else
        {
            NSMutableDictionary *dictLoginResponse = [[NSMutableDictionary alloc]init];
            dictLoginResponse = [responseDict valueForKey:@"loginData"];
            
         
            NSString *strSchool = [dictLoginResponse objectForKey:@"school"];
            NSString *strSchoolId = [dictLoginResponse objectForKey:@"school_id"];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            
            [prefs setObject:strSchool forKey:@"SchoolName"];
            [prefs setObject:strSchoolId forKey:@"SchoolId"];
            
            loginData = [[RWLoginData alloc] init];
            
            loginData.strUserId = [dictLoginResponse valueForKey:@"userid"];
            [[NSUserDefaults standardUserDefaults] setObject:loginData.strUserId forKey:@"userid"];
           
            loginData.strName = [dictLoginResponse valueForKey:@"name"];
            loginData.strEmail = [dictLoginResponse valueForKey:@"email"];
            [[NSUserDefaults standardUserDefaults] setObject:loginData.strEmail forKey:@"email"];
            loginData.strAddedOn = [dictLoginResponse valueForKey:@"addedon"];
            
            dispatch_async(dispatch_get_main_queue(), ^
                        {
                               if(isLoginFromFacebook == NO)
                               {
                                   
                                   if (![[NSUserDefaults standardUserDefaults] valueForKey:@"Remember"])
                                    {
                                        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Save your Login Details?", nil) message:NSLocalizedString(@"Would you like The Blue Tack to \nremember your login credentials?", nil) delegate:self cancelButtonTitle:NSLocalizedString(@"No, Thanks" , nil) otherButtonTitles:NSLocalizedString(@"Yes Please!" , nil), nil];
                                        [alertView show];
                                    }
                                   else
                                   {
                                       UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                       RWCategoriesViewController *vc = (RWCategoriesViewController *)[storyboard instantiateViewControllerWithIdentifier:@"categoryPage"];
                                       [self.navigationController pushViewController:vc animated:YES];

                                   }
                               }
                               else
                               {
                                   UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                   RWCategoriesViewController *vc = (RWCategoriesViewController *)[storyboard instantiateViewControllerWithIdentifier:@"categoryPage"];
                                   [self.navigationController pushViewController:vc animated:YES];

                               }
                        });
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [HUD hide];
                           [RWUtils alertForServerNotResponding];
                       });
    }
}




- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
    if (alertView.cancelButtonIndex == buttonIndex)
		{
			
			UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            RWCategoriesViewController *vc = (RWCategoriesViewController *)[storyboard instantiateViewControllerWithIdentifier:@"categoryPage"];
            [self.navigationController pushViewController:vc animated:YES];

		}
		else
		{
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"Rememberme"];
			[[NSUserDefaults standardUserDefaults] setObject:loginData.strUserId forKey:@"userid"];
			[[NSUserDefaults standardUserDefaults] setObject:txtEmail.text forKey:@"email"];
            [[NSUserDefaults standardUserDefaults] setObject:txtPassword.text forKey:@"password"];
            [[NSUserDefaults standardUserDefaults] setObject:@"yes" forKey:@"Remember"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
    
            RWCategoriesViewController *vc = (RWCategoriesViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"categoryPage"];
            [self.navigationController pushViewController:vc animated:YES];
           
		}
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
