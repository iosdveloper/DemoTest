//
//  RWCategoryData.h
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RWCategoryData : NSObject
{
    NSString *strCategoryid;
    NSString *strCategoryName;
    NSString *strTotalPlaces;
    NSString *strStatus;
}
@property(nonatomic,strong)NSString *strCategoryid;
@property(nonatomic,strong)NSString *strCategoryName;
@property(nonatomic,strong)NSString *strTotalPlaces;
@property(nonatomic,strong)NSString *strStatus;
@end
