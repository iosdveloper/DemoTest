//
//  RWPlaceData.m
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWPlaceData.h"

@implementation RWPlaceData
@synthesize strAddress,strDistance,strLocationid,strPlaceName,strPlaceLatitude,strPlaceLongitude,strIsFavAdded,strPlaceCity,strEnd_Date_Time,strStart_Date_Time,strCatName,address,category_id,city_id,city_name,continent_id,country_id,description,email,end_date_time,event_id,event_name,event_website,featured_listing,phone,school_id,start_date_time,state_id,ticket_url,userid,zip_code,strEventid,state_name,country_name,continent_name,school_name,category_name;

@end
