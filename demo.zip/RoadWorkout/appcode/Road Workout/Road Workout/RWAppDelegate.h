//
//  RWAppDelegate.h
//  Road Workout
//
//  Created by vishnu on 29/10/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "RWPlaceDetail.h"


@interface RWAppDelegate : UIResponder <UIApplicationDelegate>
{
    MBProgressHUD *HUD;
    NSURL *urlLocationData;
    NSMutableArray *arrLocationData;
    RWPlaceDetail *locationDetail;

}

@property (strong, nonatomic) UIWindow *window;

-(void)logout;
-(void)loginDirectly;
@end
