//
//  RWCommonFunction.h
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RWLoginData.h"
#import "FMDatabase.h"

RWLoginData *loginData;
FMDatabase *db;

BOOL isDelete;
BOOL isSelectRange;
BOOL restoreSuccess;
BOOL canAccessLocation;
BOOL isPulledToRefresh;

int address;
NSString *strRange;
NSString *strLatitude;
NSString *strCategoryId;
NSString *strLongitude;
NSString *strUserAddress;

@interface RWUtils : NSObject

+(BOOL)isConnectedToInternet;
+(void)alertForNoInternetConnection;
+(void)alertForServerNotResponding;
+ (NSString *) getDocumentsDirectoryPath;
+(NSString *) getDatabaseFolderPath : (NSString *)dbName;
+ (NSString *) getDatabasePathFromName:(NSString *)dbName;



@end
