//
//  RWMapViewController.h
//  Road Workout
//
//  Created by user on 15/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "ASIFormDataRequest.h"
#import "MBProgressHUD.h"
#import "RWPlaceData.h"
#import "RWSeachBar.h"
#import "RWConstants.h"
#import "RWAnnotationData.h"
#import "SBJSON.h"
#import "RWPlaceDetail.h"
#import "RWLocationDetailViewController.h"
#import "Place.h"


@interface RWMapViewController : UIViewController<MKMapViewDelegate,UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>

{
    RWSeachBar *searchBarLocation;
    RWPlaceData *placeListData;
    

    NSString *strMpLatitude;
    NSString *strMpLongitude;
    NSString *strLocationId;
    NSString *currentSearchText;

    NSArray *arrRangeAdddress;
    NSArray *arrRangeCity;
    NSArray *arrRange;
    NSArray *arrRangeCountry;
    NSArray* routes;
    
    NSURL *urlLocationList;
    NSURL *urlLocationDetail;
    
    NSMutableArray *locationList;
    NSMutableArray *arrClassData;
    NSMutableArray *arrSearchData;
    

    MBProgressHUD *HUD;
    RWPlaceDetail *locationDetail;
  
    IBOutlet UITableView *tblRange;
    
    IBOutlet UIView *viewRange;
    IBOutlet UIView *viewBorder;
    
    IBOutlet MKMapView *mapLocation;
    
    IBOutlet UISegmentedControl *segMapControl;
    IBOutlet UIBarButtonItem *btnRange;
    IBOutlet UIBarButtonItem *btnSetting;
    IBOutlet UINavigationBar *navBar;
    
    BOOL isLeftToRight;
    BOOL isMap;
    BOOL isSelectRange;
    
    UIButton *infoButton;
    UIImageView *routeView;
    UIColor* lineColor;
    
}

@property(nonatomic,strong)NSMutableArray *arrLocationList;
@property(nonatomic,strong)NSString *strLati;
@property(nonatomic,strong)NSString *strLongi;
@property(nonatomic,strong)NSString *strMPAddress;



-(IBAction)setting:(id)sender;
-(IBAction)locationList:(id)sender;
-(IBAction)gotoSettingPage:(id)sender;


@end
