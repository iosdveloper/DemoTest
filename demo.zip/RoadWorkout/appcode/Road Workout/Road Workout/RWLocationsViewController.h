//
//  RWLocationsViewController.h
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RWSeachBar.h"
#import "RWPlaceData.h"
#import "RWPlaceCell.h"
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "RWPlaceData.h"
#import "RWConstants.h"
#import "RWMapViewController.h"
#import "RWPlaceDetail.h"
#import "RWLocationDetailViewController.h"
#import "RWUtils.h"
#import <QuartzCore/QuartzCore.h>
#import "MNMBottomPullToRefreshManager.h"


@interface RWLocationsViewController : UIViewController<UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,MNMBottomPullToRefreshManagerClient>
{
    IBOutlet RWSeachBar *searchBarLocation;
    
    IBOutlet UITableView *tblSelectChoice;
    IBOutlet UITableView *tblPlaces;
    IBOutlet UITableView *tblRange;
    
    IBOutlet UIView *viewRange;
    IBOutlet UIView *viewBorder;
    IBOutlet UIView *viewselectadd;
    IBOutlet UIView *viewSearchadd;
    
    IBOutlet UIButton *btnSelectChoice;
    IBOutlet UIButton *btnMap;
    IBOutlet UIBarButtonItem *btnRange;
    IBOutlet UIBarButtonItem *btnSetting;
    IBOutlet UINavigationBar *navBar;
    IBOutlet UIButton *btnADDEvent;

    
    IBOutlet UILabel *lblLocation;
    
    IBOutlet RWSeachBar *searchBarCategories;
    
    RWPlaceData *placeListData;
    MBProgressHUD *HUD;
    RWPlaceDetail *locationDetail;
   

    NSString *currentSearchText;
    NSString *strLocationId;
    NSString *strLocLatitude;
    NSString *strLocLongitude;
    NSString *strLocAddress;
    NSString *strAddressName;
    NSString *strFavLoactionId;
    

    NSArray *arrAddressOption;
    NSArray *arrRangeAdddress;
    NSArray *arrRangeCity;
    NSArray *arrRange;
    NSArray *arrRangeCountry;
   
    NSURL *urlLocationList;
    NSURL *urlLocationDetail;
    NSURL *urlAddFav;
    NSURL *urlLocationData;
   
    
    NSMutableArray *locationList;
    NSMutableArray *arrClassData;
    NSMutableArray *arrSearchData;
    NSMutableArray *arrLocationData;
   
    BOOL isLeftToRight;
    BOOL isAddFavorite;
    BOOL isMapHide;
    BOOL isSelectRange;
    BOOL isTableLoadedFirstTime;
    
    MNMBottomPullToRefreshManager *pullToRefreshManager_;
    NSUInteger reloads_;
    
    int helpAddress;
    int addressTag1;
}

@property (nonatomic, copy) void (^completionHandler)(void);
@property(nonatomic,strong)NSMutableArray *arrLocationList;
@property(nonatomic,strong)NSString *strLat;
@property(nonatomic,strong)NSString *strLong;
@property(nonatomic,strong)NSString *currentSearchText;
@property(nonatomic)NSInteger addressTag;

-(IBAction)setting:(id)sender;
-(IBAction)categoryList:(id)sender;
-(IBAction)gotoMapAge:(id)sender;
-(IBAction)gotoSettingPage:(id)sender;


  @end
