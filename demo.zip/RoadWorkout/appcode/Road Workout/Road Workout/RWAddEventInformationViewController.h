//
//  RWAddEventInformationViewController.h
//  Road Workout
//
//  Created by Balkaran on 21/03/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "MBProgressHUD.h"
MBProgressHUD *HUD;
@protocol AddEventInfoDelegate<NSObject>
-(void)setContinentId:(NSString *)continent_id name:(NSString *)continent_name;
-(void)setCountryId:(NSString *)country_id name:(NSString *)country_name;
-(void)setStateId:(NSString *)state_id name:(NSString *)state_name;
-(void)setCityId:(NSString *)city_id name:(NSString *)city_name;
@end
@interface RWAddEventInformationViewController : UIViewController
{
        NSURL *url;
      MBProgressHUD *HUD;
    IBOutlet UIBarButtonItem *btnBack;
    IBOutlet UINavigationBar *navBar;
       
    NSMutableArray *arryInfo;
    IBOutlet UITableView *tableinfo;
}

@property(nonatomic,strong) NSString *yourTitle;
@property(nonatomic,strong) NSString *continet_id;
@property(nonatomic,strong) NSString *country_id;
@property(nonatomic,strong) NSString *state_id;
@property(nonatomic,assign) id<AddEventInfoDelegate> delegate;
@end
