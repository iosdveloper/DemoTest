//
//  RWLocationsViewController.m
//  Road Workout
//
//  Created by user on 13/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWLocationsViewController.h"
#import "RWConstants.h"
@interface RWLocationsViewController ()

@end

@implementation RWLocationsViewController
@synthesize arrLocationList,strLong,strLat, currentSearchText,addressTag;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillDisappear:(BOOL)animated
{
        viewRange.hidden=YES;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden=YES;
   
    isLeftToRight = YES;
    isMapHide = NO;
    isSelectRange = NO;
    
    
    viewSearchadd.hidden=YES;
    NSString *strLocationList = URL_LOCATION_LIST;
    urlLocationList=[NSURL URLWithString:strLocationList];
    
    NSString *strLocationDetals = URL_LOCATION_DETAIL;
    urlLocationDetail=[NSURL URLWithString:strLocationDetals];
    
    NSString *strAddFavUrl = URL_ADD_FAVORITE;
    urlAddFav=[NSURL URLWithString:strAddFavUrl];
    
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)
    {
        
        UIImage* userLoaction = [UIImage imageNamed:@"btn_setting.png"];
        CGRect imgBackframe = CGRectMake(0, 0, userLoaction.size.width, userLoaction.size.height);
        UIButton *backBtn = [[UIButton alloc] initWithFrame:imgBackframe];
        [backBtn setBackgroundImage:userLoaction forState:UIControlStateNormal];
        [backBtn addTarget:self action:@selector(setting:)
          forControlEvents:UIControlEventTouchUpInside];
        [backBtn setShowsTouchWhenHighlighted:YES];
        
        
        UIImage* imageDone = [UIImage imageNamed:@"btn_setting1.png"];
        CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
        UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
        [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
        [doneBtn addTarget:self action:@selector(gotoSettingPage:)
          forControlEvents:UIControlEventTouchUpInside];
        
        btnRange =[[UIBarButtonItem alloc] initWithCustomView:backBtn];
        btnSetting =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
        
        self.navigationItem.leftBarButtonItem = btnRange;
        self.navigationItem.hidesBackButton = YES;
        
        self.navigationItem.rightBarButtonItem = btnSetting;
        
        [navBar pushNavigationItem:self.navigationItem animated:NO];
        navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
        
        self.navigationItem.title=@"Locations";
        
        
        if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
        {
            [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                            [UIColor whiteColor], UITextAttributeTextColor,
                                            [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                            nil]];
            [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
        }
        
    }
    

    
    
    
    
    
    arrRange = [[NSArray alloc]init];
    locationList = [[NSMutableArray alloc]init];
    arrClassData = [[NSMutableArray alloc]init];
    arrSearchData = [[NSMutableArray alloc] init];
    
    lblLocation.hidden=YES;
    
    strLocLatitude = strLat;
    strLocLongitude = strLong;
    
    strLocAddress = currentSearchText;
    strAddressName = currentSearchText;
    
    arrAddressOption = [[NSArray alloc]initWithObjects:@"Address",@"Zipcode",@"City",@"State",@"Country", nil];
    
    locationList=[arrLocationList mutableCopy];
    arrClassData=[arrLocationList mutableCopy];

    pullToRefreshManager_ = [[MNMBottomPullToRefreshManager alloc] initWithPullToRefreshViewHeight:60.0f tableView:tblPlaces withClient:self];
    
      
    UIImage *searchFieldImage = [UIImage imageNamed:@"searchBar_bg.png"];
    [searchBarLocation setSearchFieldBackgroundImage:searchFieldImage forState:UIControlStateNormal];
    [searchBarCategories setBackgroundImage:[UIImage imageNamed:@"searchBar_bg.png"]];
    [searchBarCategories setSearchFieldBackgroundImage:searchFieldImage forState:UIControlStateNormal];
    searchBarCategories.delegate = self;
    searchBarCategories.placeholder = @"Events";
    
    if(IS_IPHONE_5)
    {
        viewRange.frame=CGRectMake(-160, 64, 160, 566);
    }
    else
    {
        viewRange.frame=CGRectMake(-160, 64, 160, 376);
    }
    [self.view addSubview:viewRange];
    
    viewRange.hidden=YES;
    viewRange.layer.cornerRadius=10.0;
    tblRange.layer.cornerRadius=10.0;
    viewRange.layer.borderWidth=1.0;
    viewRange.layer.borderColor=[UIColor whiteColor].CGColor;
    
    arrRangeAdddress = [[NSArray alloc]initWithObjects:@"1",@"2",@"5",@"10",@"25",@">25", nil];
    arrRangeCity = [[NSArray alloc]initWithObjects:@"50",@"100",@"200",@"300",@"400",@"500",@">500", nil];
    arrRangeCountry = [[NSArray alloc]initWithObjects:@"200",@"400",@"600",@"800",@"1000",@"2000",@">2000", nil];
    
    isPulledToRefresh = YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    if (isDelete) {
        isDelete=NO;
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(getLocationList) onTarget:self withObject:nil animated:TRUE];
    }
}

///////////////////////////////////////TABLEVIEW START //////////////////////////////////////////////


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==tblRange)
    {
        return [arrRange count];
    }
    else
    {
        if (searchBarCategories.text.length>0) {
            
            return [arrSearchData count];
          
        }
        else
        {
           return [locationList count];
       
        }
    }
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
    if(isAtLeast7)
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if (tableView==tblPlaces)
    {
        static NSString *cellIdentifier = @"PlaceList";
        RWPlaceCell   *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (cell == nil)
        {
            cell = [[RWPlaceCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                      reuseIdentifier:cellIdentifier];
        }
        
        if (searchBarCategories.text.length>0)
        {
            placeListData = [arrSearchData objectAtIndex:indexPath.row];
        }
        else
        {
            placeListData = [locationList objectAtIndex:indexPath.row];
        }
        
        NSString *strTitle = placeListData.strPlaceName;
        
        if([placeListData.strIsFavAdded isEqualToString:@"0"])
        {
            cell.btnFavorite.alpha=0.5;
        }
        else
        {
            cell.btnFavorite.alpha=1.0;
        }
        
        
        [cell.btnFavorite addTarget:self action:@selector(btnFavClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnFavorite.tag = indexPath.row;
        
        if(strTitle==(id) [NSNull null] || [strTitle length]==0 || [strTitle isEqualToString:@""])
        {
            [cell.lblAddress setText:@""];
        }
        else
        {
            [cell.lblAddress setText:strTitle];
        }
        
        float dts=placeListData.strDistance;
        NSString *strDistnce;
        
        if (0<=dts && dts<=1)
        {
            strDistnce=[NSString stringWithFormat:@"%.2f mile",dts];
        }
        else if(10000>dts && dts>999)
        {
            strDistnce=[NSString stringWithFormat:@"%4.2fk miles",(long)dts*0.001];
        }
        else if(10000<dts)
        {
            strDistnce=[NSString stringWithFormat:@"%4.2fk miles",(long)dts*0.001];
        }
        else
        {
            strDistnce=[NSString stringWithFormat:@"%.2f miles",dts];
        }
        
        if ([RWUtils isConnectedToInternet])
        {
            [cell.lblDistance setText:strDistnce];
        }
        else
        {
            [cell.lblDistance setText:@""];
        }
        cell.lblStartDate.text = placeListData.strStart_Date_Time;
        cell.lblEndDate.text = placeListData.strEnd_Date_Time;
        cell.lblCatName.text = placeListData.strCatName;
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        return cell;
    }
    else
    {
        static NSString *cellIdentifier = @"RangeCell";
        UITableViewCell   *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                          reuseIdentifier:cellIdentifier];
        }
        
        NSInteger dtnce=[[arrRange objectAtIndex:indexPath.row] integerValue];
        if (dtnce==1) {
            cell.textLabel.text=[NSString stringWithFormat:@"%ld mile",(long)dtnce];
        }
        else if(1<dtnce && dtnce<=2000)
        {
            cell.textLabel.text=[NSString stringWithFormat:@"%ld miles",(long)dtnce];
        }
        else
        {
            cell.textLabel.text=[NSString stringWithFormat:@"%@ miles",[arrRange objectAtIndex:indexPath.row]];
        }
        cell.backgroundColor=[UIColor clearColor];
        cell.textLabel.textColor = [UIColor whiteColor];
        [cell.textLabel setFrame:CGRectMake(30, 8, 80, 36)];
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==tblPlaces)
    {
        if (searchBarCategories.text.length>0) {
            placeListData = [arrSearchData objectAtIndex:indexPath.row];
        }
        else
        {
            placeListData = [locationList objectAtIndex:indexPath.row];
        }
        
        strLocationId=placeListData.strLocationid;
        
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(gotoLocationDetail) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [self getLocationDetailsFromDatabase];
        }
    }
    else
    {
        isSelectRange=YES;
        isLeftToRight=YES;
        isPulledToRefresh = NO;
        strRange=[arrRange objectAtIndex:indexPath.row];
        
        if([strRange isEqualToString:@">2000"])
        {
            strRange=@"10000";
        }
        if([strRange isEqualToString:@">500"])
        {
            strRange=@"10000";
        }
        if([strRange isEqualToString:@">25"])
        {
            strRange=@"30";
        }
        
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(getLocationList) onTarget:self withObject:nil animated:TRUE];
        CGRect frame = viewRange.frame;
        frame.origin.x = -160;
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.2];
        viewRange.frame = frame;
        [UIView commitAnimations];
    }
}


///////////////////////////////////////TABLEVIEW END //////////////////////////////////////////////




-(void)btnFavClicked:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    RWPlaceData *placeDataHolder;
    if(searchBarCategories.text.length > 0)
    {
        placeDataHolder = [arrSearchData objectAtIndex:btn.tag];
    }
    else
    {
        placeDataHolder = [locationList objectAtIndex:btn.tag];
    }
    
    strFavLoactionId=placeDataHolder.strLocationid;
    if (btn.alpha==1.0)
    {
        [self setCompletionHandler:^(void)
         {
             placeDataHolder.strIsFavAdded = @"0";
             btn.alpha=0.5;
         }];
        
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(deleteFavorite:) onTarget:self withObject:placeDataHolder.strLocationid animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
        
    }
    else
    {
        [self setCompletionHandler:^(void)
         {
             placeDataHolder.strIsFavAdded = @"1";
             btn.alpha=1.0;
             [btn setUserInteractionEnabled:YES];
         }];
        
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(addFavorite:) onTarget:self withObject:placeDataHolder.strLocationid animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }
}

////////////////////////////DELETE FAVORITE APICALL //////////////////////////////////////////////

-(void)deleteFavorite:(NSString *)locationId{
    
    NSString *strDeleteFavoriteUrl = URL_DELETE_FAVORITE;
    NSURL *urlDeleteFavorite = [NSURL URLWithString:strDeleteFavoriteUrl];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlDeleteFavorite];
    [request setPostValue:locationId forKey:@"locationid"];
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getDeleteFavoriteFail:)];
    [request setDidFinishSelector:@selector(getDeleteFavoriteSuccess:)];
    [request startSynchronous];
    
}
-(void)getDeleteFavoriteFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getDeleteFavoriteSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
            NSString *status=[responseData valueForKey:@"error_code"];
            if ([status isEqualToString:@"0"])
            {
                    if ([self completionHandler])
                    {
                        self.completionHandler();
                    }
                [self performSelectorInBackground:@selector(deleteFromFavDatabase) withObject:nil];
            }
            else
            {
                NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
                dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
            }
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}

///////////////////////////////////////DELETE FAVORITE END //////////////////////////////////////////////






///////////////////////////////////////ADD FAVORITE APICALL //////////////////////////////////////////////


-(void)addFavorite:(NSString *)strLocId
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlAddFav];
    [request setPostValue:strLocId forKey:@"locationid"];
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(addFavoriteFail:)];
    [request setDidFinishSelector:@selector(addFavoriteSuccess:)];
    [request startSynchronous];
}

-(void)addFavoriteFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)addFavoriteSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            if ([self completionHandler]) {
                self.completionHandler();
            }
            
            [self performSelectorInBackground:@selector(insertIntoFavDatabase) withObject:nil];
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}

///////////////////////////////////////ADD FAVORITE END //////////////////////////////////////////////





///////////////////////////////////////PLACESLIST APICALL //////////////////////////////////////////////

-(void)getLocationList
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationList];
    if(address==1)
    {
        [request setPostValue:strAddressName forKey:@"city"];
         [request setPostValue:strRange forKey:@"range"];
    }
    else if(address==2)
    {
        [request setPostValue:strAddressName forKey:@"state"];
         [request setPostValue:strRange forKey:@"range"];
    }
    else if(address==3)
    {
        [request setPostValue:strAddressName forKey:@"country"];
         [request setPostValue:strRange forKey:@"range"];
    }
    else
    {
          [request setPostValue:strRange forKey:@"range"];
    }

    [request setPostValue:strLocLatitude forKey:@"latitude"];
    [request setPostValue:strLocLongitude forKey:@"longitude"];
    [request setPostValue:strCategoryId forKey:@"categoryid"];
    
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getLocationListFail:)];
    [request setDidFinishSelector:@selector(getLocationListSuccess:)];
    [request startSynchronous];
    
}

-(void)getLocationListFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getLocationListSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        if ([status isEqualToString:@"0"])
        {
            NSMutableArray *arrCategoryList=[responseData valueForKey:@"placesList"];
            NSMutableArray *arrsorted = [[NSMutableArray alloc]init];
            for (int i=0; i<arrCategoryList.count; i++)
            {
                RWPlaceData *placeData=[[RWPlaceData alloc]init];
                placeData.strLocationid=[[arrCategoryList objectAtIndex:i] valueForKey:@"locationid"];
                placeData.strAddress=[[arrCategoryList objectAtIndex:i] valueForKey:@"address"];
                placeData.strDistance=[[[arrCategoryList objectAtIndex:i] valueForKey:@"distance"] doubleValue];
                placeData.strPlaceName=[[arrCategoryList objectAtIndex:i] valueForKey:@"name"];
                placeData.strPlaceLatitude=[[arrCategoryList objectAtIndex:i] valueForKey:@"latitude"];
                placeData.strPlaceLongitude=[[arrCategoryList objectAtIndex:i] valueForKey:@"longitude"];
                placeData.strStart_Date_Time = [[arrCategoryList objectAtIndex:i] valueForKey:@"start_date_time"];
                 placeData.strEnd_Date_Time = [[arrCategoryList objectAtIndex:i] valueForKey:@"end_date_time"];
                 placeData.strCatName = [[arrCategoryList objectAtIndex:i] valueForKey:@"category_name"];
                 placeData.strIsFavAdded = [NSString stringWithFormat:@"%@", [[arrCategoryList objectAtIndex:i] valueForKey:@"isfavorite"]];
                
                if (isSelectRange)
                {
                    if (placeData.strDistance<=[strRange integerValue])
                    {
                        [arrsorted addObject:placeData];
                    }
                    else if([strRange isEqualToString:@">2000"] || [strRange isEqualToString:@">500"] || [strRange isEqualToString:@">25"])
                    {
                        [arrsorted addObject:placeData];
                    }
                }
                else
                {
                    [arrsorted addObject:placeData];
                }
                
            }
            NSSortDescriptor *sortDescriptor;
            sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"strStart_Date_Time" ascending:YES];
            NSArray *arrSortDescriptors = [NSArray arrayWithObject:sortDescriptor];
            locationList = [[arrsorted sortedArrayUsingDescriptors:arrSortDescriptors] mutableCopy];
            
            if (locationList.count>0)
            {
                dispatch_async(dispatch_get_main_queue(), ^
                {
                    arrClassData=[locationList mutableCopy];
                    tblPlaces.hidden=NO;
                    lblLocation.hidden=YES;
                    [tblPlaces reloadData];
                    
                    if(isPulledToRefresh)
                    {
                        [pullToRefreshManager_ tableViewReloadFinished];
                    }
                });
                if (isMapHide) {
                    isMapHide=NO;
                    btnMap.hidden=NO;
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^
                {
                    locationList=nil;
                    tblPlaces.hidden=YES;
                    lblLocation.hidden=NO;
                });
            }
            strLocAddress=searchBarLocation.text;
            isSelectRange=NO;
         }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^
            {
                locationList=nil;
                tblPlaces.hidden=YES;
                lblLocation.hidden=NO;
            });
        }
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
}

///////////////////////////////////////PLACESLIST END //////////////////////////////////////////////






///////////////////////////////////////Search Start //////////////////////////////////////////////



-(void)searchViewShouldBeginEditing:(UISearchBar *)searchBar
{
       tblPlaces.userInteractionEnabled = YES;
}

-(void)searchViewShouldSearchButtonClick:(UISearchBar *)searchBar searchText:(NSString *)searchText
{
    if (![searchBar.text isEqualToString:currentSearchText])
    {
        if(searchText.length == 0)
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                              
                               
                               [searchBarCategories resignFirstResponder];
                            });
        }
        else
        {
            [arrSearchData removeAllObjects];
            
            for (RWPlaceData *contact in arrClassData)
            {
                NSString *strName = [NSString stringWithFormat:@"%@", contact.strPlaceName];
                NSRange nameRange = [strName rangeOfString:searchText options:NSCaseInsensitiveSearch];
                
                if(nameRange.location != NSNotFound)
                {
                    [arrSearchData addObject:contact];
                }
                
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [tblPlaces reloadData];
                       });
    }
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [self searchViewShouldBeginEditing:searchBar];
    
    for(id subview in [searchBar subviews])
    {
        if ([subview isKindOfClass:[UIButton class]]) {
            [subview setEnabled:YES];
        }
    }
    return YES;
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    btnADDEvent.frame=CGRectMake(325, 72, 44, 44);
    [UIView commitAnimations];
    if(searchBarCategories.text.length == 0)
    {
        [searchBarCategories resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
         btnADDEvent.frame=CGRectMake(269, 72, 44, 44);
         [UIView commitAnimations];
       
    }
    
    [self searchViewShouldSearchButtonClick:searchBar searchText:searchBar.text];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [self.searchDisplayController.searchBar setText:@""];
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [tblPlaces reloadData];
                   });
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
  
        [searchBar setShowsCancelButton:NO animated:YES];
        [searchBar resignFirstResponder];
        [self searchViewShouldSearchButtonClick:searchBar searchText:searchBar.text];
        
        if (![searchBar.text isEqualToString:currentSearchText])
        {
            currentSearchText = searchBar.text;
        }
 
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [searchBarCategories resignFirstResponder];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(isPulledToRefresh)
    {
        [pullToRefreshManager_ tableViewReleased];
    }
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if(isPulledToRefresh)
    {
        [pullToRefreshManager_ tableViewScrolled];
    }
    else{
        
    }
}

- (void)bottomPullToRefreshTriggered:(MNMBottomPullToRefreshManager *)manager {
    if(isPulledToRefresh)
    {
        [self performSelector:@selector(loadTable) withObject:nil afterDelay:1.0f];
    }
}

- (void)loadTable
{
    
    if(locationList.count>50)
    {
        if (address==1)
        {
            strRange = [NSString stringWithFormat:@"%ld",([strRange integerValue] +50)];
           
        }
        else if (address==2)
        {
            strRange = [NSString stringWithFormat:@"%ld",([strRange integerValue] +100)];
           
        }
        else if (address==3) {
            strRange = [NSString stringWithFormat:@"%ld",([strRange integerValue] +300)];
           
        }
        else
        {
            strRange = [NSString stringWithFormat:@"%ld",([strRange integerValue] +10)];
           
        }
        
        if (!isMapHide) {
            isMapHide = YES;
            btnMap.hidden=YES;
        }
        
    }
    else
    {
        if (address>0)
        {
            strRange = [NSString stringWithFormat:@"10000"];
        }
        else
        {
            strRange = @"30";
        }
    }
    [self performSelectorInBackground:@selector(getLocationList) withObject:nil];
}


- (void)viewDidLayoutSubviews
{
    
    [super viewDidLayoutSubviews];
    
    if(isPulledToRefresh)
    {
        [pullToRefreshManager_ relocatePullToRefreshView];
    }
    else
    {
        [pullToRefreshManager_ removeFresherView];
    }
}




-(void)gotoLocationDetail
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationDetail];
    [request setPostValue:strLocationId forKey:@"locationid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getLocationDetailsFail:)];
    [request setDidFinishSelector:@selector(getLocationDetailsSuccess:)];
    [request startSynchronous];
    
}

-(void)getLocationDetailsFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getLocationDetailsSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            NSMutableDictionary *arrCategoryList=[responseData valueForKey:@"location"];
            
            locationDetail=[[RWPlaceDetail alloc]init];
            locationDetail.strLocationid=[arrCategoryList valueForKey:@"locationid"];
            locationDetail.strName=[arrCategoryList valueForKey:@"name"];
            locationDetail.strGenre=[arrCategoryList  valueForKey:@"genre"];
            locationDetail.strDescription=[arrCategoryList  valueForKey:@"description"];
            locationDetail.strWebsite=[arrCategoryList  valueForKey:@"website"];
            locationDetail.strPhone=[arrCategoryList valueForKey:@"phone"];
            locationDetail.strZipcode=[arrCategoryList valueForKey:@"zipcode"];
            locationDetail.strAddress=[arrCategoryList valueForKey:@"address"];
            locationDetail.strCity=[arrCategoryList  valueForKey:@"city"];
            locationDetail.strState=[arrCategoryList  valueForKey:@"state"];
            locationDetail.strContinent=[arrCategoryList valueForKey:@"continent"];
            locationDetail.strCountry=[arrCategoryList  valueForKey:@"country"];
            locationDetail.strLatitude=[arrCategoryList  valueForKey:@"latitude"];
            locationDetail.strLongitude=[arrCategoryList valueForKey:@"longitude"];
            locationDetail.strYelpLink=[arrCategoryList valueForKey:@"yelp_link"];
            locationDetail.strTicketUrl=[arrCategoryList valueForKey:@"ticket_url"];
            locationDetail.strStartDate=[arrCategoryList valueForKey:@"start_date_time"];
            locationDetail.strEndDate =[arrCategoryList valueForKey:@"end_date_time"];
             locationDetail.strSchoolname =[arrCategoryList valueForKey:@"school_name"];

            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self performSegueWithIdentifier:@"LocationDetails" sender:self];
            });
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}


-(void)getLocationDetailsFromDatabase
{
    address=helpAddress;
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locId = \"%@\"", strLocationId];
 
       @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
         
            while([resultSet next])
            {
                locationDetail=[[RWPlaceDetail alloc]init];
                locationDetail.strLocationid=[resultSet stringForColumn:@"locId"];
                locationDetail.strName=[resultSet stringForColumn:@"locName"];
                locationDetail.strGenre=[resultSet stringForColumn:@"locCategoryName"];
                locationDetail.strDescription=[resultSet stringForColumn:@"locDescription"];
                locationDetail.strWebsite=[resultSet stringForColumn:@"locWebsite"];
                locationDetail.strPhone=[resultSet stringForColumn:@"locPhone"];
                locationDetail.strZipcode=[resultSet stringForColumn:@"locZipcode"];
                locationDetail.strAddress=[resultSet stringForColumn:@"locAddress"];
                locationDetail.strCity=[resultSet stringForColumn:@"locCity"];
                locationDetail.strState=[resultSet stringForColumn:@"locState"];
                locationDetail.strContinent=[resultSet stringForColumn:@"locContinent"];
                locationDetail.strCountry=[resultSet stringForColumn:@"locCountry"];
                locationDetail.strLatitude=[resultSet stringForColumn:@"locLatitude"];
                locationDetail.strLongitude=[resultSet stringForColumn:@"locLongitude"];
                locationDetail.strYelpLink=[resultSet stringForColumn:@"locYelpLink"];
                locationDetail.strSocial_link=[resultSet stringForColumn:@"social_link"];

            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
       dispatch_async(dispatch_get_main_queue(), ^{
        
        [self performSegueWithIdentifier:@"LocationDetails" sender:self];
    });
}



-(NSString *)returnMyString:(NSString *)changeString
{
    NSString *mystr=[changeString substringToIndex:3];
    NSString *lastChar = [changeString substringFromIndex:3];
    NSString *finalStr = [NSString stringWithFormat:@"%@ ", mystr];
    finalStr = [finalStr stringByAppendingString:lastChar];
    return finalStr;
}




-(void)getLocationlistFromDatabase
{
    
    locationList = [[NSMutableArray alloc]init];
    NSMutableArray *arrLocationDatabase = [[NSMutableArray alloc]init];

    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    

    if(address == 1)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locCity like \"%@\" and locCategoryId = \"%@\"", [strAddressName stringByTrimmingCharactersInSet:
                                                                                                                                       [NSCharacterSet whitespaceCharacterSet]],strCategoryId];    }
    else if(address == 2)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locState like \"%@\" and locCategoryId = \"%@\"", [strAddressName stringByTrimmingCharactersInSet:
                                                                                                                                        [NSCharacterSet whitespaceCharacterSet]],strCategoryId];
    }
    else if(address == 3)
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locCountry like \"%@\" and locCategoryId =\"%@\"",[strAddressName stringByTrimmingCharactersInSet:
                                                                                                                                        [NSCharacterSet whitespaceCharacterSet]],strCategoryId];
    }
    else
    {
        query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locAddress like \"%@\" and locCategoryId = \"%@\"", [strAddressName stringByTrimmingCharactersInSet:
                                                                                                                                          [NSCharacterSet whitespaceCharacterSet]],strCategoryId];
    }
    @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
           
            while([resultSet next])
            {
                RWPlaceData *placeData = [[RWPlaceData alloc]init];
                placeData.strPlaceName = [resultSet stringForColumn:@"locName"];
                placeData.strLocationid = [resultSet stringForColumn:@"locId"];
                placeData.strPlaceLatitude = [resultSet stringForColumn:@"locLatitude"];
                placeData.strPlaceLongitude = [resultSet stringForColumn:@"locLongitude"];
                
                [arrLocationDatabase addObject:placeData];
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"strDistance" ascending:YES];
    NSArray *arrSortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    
    locationList = [[arrLocationDatabase sortedArrayUsingDescriptors:arrSortDescriptors] mutableCopy];
    if (locationList.count>0) {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           tblPlaces.hidden=NO;
                           lblLocation.hidden=YES;
                           
                           [tblPlaces reloadData];
                       });
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           locationList=nil;
                           
                           tblPlaces.hidden=YES;
                           lblLocation.hidden=NO;
                       });
        
       
    }
}


-(void)insertIntoFavDatabase
{
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    NSString *query1;
    
    query1 = [NSString stringWithFormat:@"select locId,locName,locCity from RoadWorkOutLocation where locId=\"%@\"",strFavLoactionId];
    
    
    RWPlaceData *placeData1 = [[RWPlaceData alloc]init];
    
    @try {
        
        [db open];
        if ([db executeQuery:query1])
        {
            FMResultSet *resultSet = [db executeQuery:query1];
            
            while([resultSet next])
            {
                
                placeData1.strPlaceName = [resultSet stringForColumn:@"locName"];
                placeData1.strLocationid = [resultSet stringForColumn:@"locId"];
                placeData1.strPlaceCity = [resultSet stringForColumn:@"locCity"];
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    
    query = [NSString stringWithFormat:@"INSERT into RoadWorkOutFavroiteList('favLocationId','favCityName', 'favLoactionName','favUserId')VALUES(\"%@\",\"%@\",\"%@\",\"%@\")",placeData1.strLocationid,placeData1.strPlaceCity,placeData1.strPlaceName,[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"]];
    
    @try
    {
        [db open];
        if ([db executeUpdate:query])
        {
            NSLog(@"success in Insertion");
            
        }
        else
        {
            NSLog(@"error in Insertion");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
}


-(void)deleteFromFavDatabase
{
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    query = [NSString stringWithFormat:@"Delete FROM RoadWorkOutFavroiteList where favLocationId = \"%@\" and favUserId = \"%@\"", strFavLoactionId,[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"]];
    
    @try
    {
        [db open];
        if ([db executeUpdate:query])
        {
            NSLog(@"success in Deletion");
            
        }
        else
        {
            NSLog(@"error in Deletion");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
}

///////////////////////////////////////DataBase END/////////////////////////////////////////////////




-(IBAction)setting:(id)sender
{
    if (address==2) {
        arrRange=arrRangeAdddress;
    }
    else if (address== 3 || address == 4 )
    {
        arrRange=arrRangeCountry;
    }
    else
    {
        arrRange=arrRangeAdddress;
    }
    
    viewRange.hidden=NO;
    CGRect frame = viewRange.frame;
    frame.origin.x = (isLeftToRight) ? 0 : -160;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewRange.frame = frame;
    [UIView commitAnimations];
    
    if (isLeftToRight)
    {
        isLeftToRight=NO;
    }
    else
    {
        isLeftToRight=YES;
    }
    [tblRange reloadData];
    
}

-(IBAction)categoryList:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
    viewRange.hidden=YES;
}


-(IBAction)gotoMapAge:(id)sender
{
    
    if (locationList.count == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"Message" message:@"Location is not available." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
           }
    else
    {
        [self performSegueWithIdentifier:@"MapView" sender:nil];
    }
    
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"MapView"])
    {
        RWMapViewController *map=(RWMapViewController*)[segue destinationViewController];
        if (searchBarCategories.text.length>0) {
             map.arrLocationList=arrSearchData;
        }
        else
        {
             map.arrLocationList=locationList;
        }
       
        map.strLati=strLocLatitude;
        map.strLongi=strLocLongitude;
        map.strMPAddress=strLocAddress;
        
    }
    if ([segue.identifier isEqualToString:@"LocationDetails"])
    {
        RWLocationDetailViewController *details=(RWLocationDetailViewController*)[segue destinationViewController];
        details.locationDetail=locationDetail;
    }
}

-(IBAction)gotoSettingPage:(id)sender
{
    [self performSegueWithIdentifier:@"SettingPageFromLoaction" sender:nil];
}

-(void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (!isTableLoadedFirstTime) {
        
        isTableLoadedFirstTime = YES;
        if ([tableView isEqual:tblPlaces])
        {
            if(isPulledToRefresh)
            {
                [pullToRefreshManager_ tableViewReloadFinished];
            }
        }
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
