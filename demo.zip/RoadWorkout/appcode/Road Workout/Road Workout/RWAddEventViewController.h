//
//  RWAddEventViewController.h
//  Road Workout
//
//  Created by Balkaran on 16/03/15.
//  Copyright (c) 2015 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "MBProgressHUD.h"
#import "RWAddEventInformationViewController.h"
#import "RWCategoriesListViewController.h"
#import "Validate.h"
#import "SAMTextView.h"
#import "RWPlaceData.h"

@interface RWAddEventViewController : UIViewController<AddEventInfoDelegate,UITextFieldDelegate,AddCategoriesSchoolInfoDelegate>{
     IBOutlet UIBarButtonItem *btnBack;
     IBOutlet UINavigationBar *navBar;
     MBProgressHUD *HUD;
    
    IBOutlet UITextField *txtEventName;
    IBOutlet UITextField *txtCategoryName;
    IBOutlet UITextField *txtPhoneNo;
    IBOutlet UITextField *txtCity;
    IBOutlet UITextField *txtState;
    IBOutlet UITextField *txtCountry;
    IBOutlet UITextField *txtContinenet;
    IBOutlet UITextField *txtEmailId;
    IBOutlet UITextField *txtWebUrl;
    IBOutlet UITextField *txtTicketUrl;
    IBOutlet UITextField *txtStartDateTime;
    IBOutlet UITextField *txtEndDateTime;
    IBOutlet UITextField *txtEventAddress;
    IBOutlet UITextField *txtZipCode;
    IBOutlet SAMTextView * txtviewDis;
    IBOutlet UITextField *txtSchool;
    IBOutlet UIButton *btnSubmit;
    IBOutlet UIButton *btnSchool;
     UIView *datePickerView;
     UIDatePicker *datePicker;
    NSString *continent_Id;
    NSString *country_Id;
    NSString *state_Id;
    NSString *categories_ID;
    NSString *chekBtnClik;
    NSString *school_ID;
    NSString *city_ID;
    NSString *strPoneNo;
    NSString *event_id;
    BOOL startDate;
     NSURL *url;
    NSDate *date1;
    NSDate *date2;
    
    
    
    
    
    IBOutlet TPKeyboardAvoidingScrollView *keybordHideView;
}
@property(nonatomic,strong)RWPlaceData *plcData;
- (IBAction)SubmitButton1:(id)sender;
- (IBAction)SubmitButton2:(id)sender;


@end
