//
//  RWAnnotationData.m
//  Road Workout
//
//  Created by user on 15/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWAnnotationData.h"

@implementation RWAnnotationData
@synthesize title,coordinate,subtitle,identity,Loactionid,place;
-(id) initWithPlace: (Place*) p
{
	self = [super init];
	if (self != nil) {
		coordinate.latitude = p.latitude;
		coordinate.longitude = p.longitude;
		self.place = p;
	}
	return self;
}




@end
