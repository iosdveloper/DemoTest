//
//  RWCityFilterDetails.h
//  Road Workout
//
//  Created by user on 11/12/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RWCityFilterDetails : NSObject


@property(nonatomic,strong)NSString *strCityName;
@property(nonatomic,strong)NSString *strCityType;
@property(nonatomic,strong)NSString *strAddress;
@property(nonatomic,strong)NSString *strCityLatitude;
@property(nonatomic,strong)NSString *strCityLongitude;




@end
