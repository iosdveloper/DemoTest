//
//  RWLocationDetailViewController.m
//  Road Workout
//
//  Created by user on 16/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWLocationDetailViewController.h"
#import "RWAnnotationData.h"

@interface RWLocationDetailViewController ()

@end

@implementation RWLocationDetailViewController
@synthesize locationDetail;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UITapGestureRecognizer *singleTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
    [ mpLoc addGestureRecognizer:singleTapGestureRecognizer];
      NSString *Url = [locationDetail.strTicketUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if ([Url isEqualToString:@""]) {
        btnTickets.hidden =YES;
    } else{
        
        btnTickets.hidden = NO;
    }

	   btnYelp.hidden = YES;
    self.navigationController.navigationBarHidden=YES;
    
    NSString *strLocationDetals = URL_LOCATION_DETAIL;
    urlLocationDetail=[NSURL URLWithString:strLocationDetals];

    routeView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, mpLoc.frame.size.width, mpLoc.frame.size.height)];
    routeView.userInteractionEnabled = NO;
    
    [mpLoc addSubview:routeView];
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(isAtLeast7)
    {
       mpLoc.rotateEnabled=NO;
    }
    
    if(!isAtLeast7)
    {
        
        UIImage* userLoaction = [UIImage imageNamed:@"btn_back.png"];
        CGRect imgBackframe = CGRectMake(0, 0, userLoaction.size.width, userLoaction.size.height);
        UIButton *backBtn = [[UIButton alloc] initWithFrame:imgBackframe];
        [backBtn setBackgroundImage:userLoaction forState:UIControlStateNormal];
        [backBtn addTarget:self action:@selector(back:)
          forControlEvents:UIControlEventTouchUpInside];
        [backBtn setShowsTouchWhenHighlighted:YES];
        
        
        UIImage* imageDone = [UIImage imageNamed:@"btn_setting1.png"];
        CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
        UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
        [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
        [doneBtn addTarget:self action:@selector(gotoSettingPage:)
          forControlEvents:UIControlEventTouchUpInside];
        
        btnBack =[[UIBarButtonItem alloc] initWithCustomView:backBtn];
        btnSetting =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
        
        self.navigationItem.leftBarButtonItem = btnBack;
        self.navigationItem.hidesBackButton = YES;
        
        self.navigationItem.rightBarButtonItem = btnSetting;
        
        [navBar pushNavigationItem:self.navigationItem animated:NO];
        navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
        
        self.navigationItem.title=@"Locations";
        
        
        if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
        {
            [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                            [UIColor whiteColor], UITextAttributeTextColor,
                                            [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                            nil]];
            [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
        }
    }

    
    
    lineColor = [UIColor blueColor];

    viewMapView.layer.cornerRadius=10.0;
    viewMapView.layer.borderWidth=1.0;
    viewMapView.layer.borderColor=[UIColor whiteColor].CGColor;
    
    mpLoc.layer.cornerRadius=10.0;
    mpLoc.layer.borderWidth=1.0;
    mpLoc.layer.borderColor=[UIColor whiteColor].CGColor;

    
    webDiscription.layer.cornerRadius=10.0;
    webDiscription.layer.borderWidth=1.0;
    webDiscription.layer.borderColor=[UIColor grayColor].CGColor;
    
    viewWeb.layer.cornerRadius=10.0;
    mpLoc.delegate=self;

    webLongDes.layer.cornerRadius=10.0;
    
    viewWeb.hidden=NO;
    
    if(IS_IPHONE_5)
    {
        
        lblName.frame = CGRectMake(0, 72, 320, 32);
        viewMapView.frame = CGRectMake(6, 120, 308, 180);
        imvPhone.frame = CGRectMake(58, 300, 26, 26);
        lblDot1.frame = CGRectMake(92, 301, 5, 21);
        btnPhoneNum.frame = CGRectMake(107, 302, 196, 20);
        imvLink.frame = CGRectMake(58, 329, 26, 26);
        lblDot2.frame = CGRectMake(92, 330, 5, 21);
        btnWebsite.frame = CGRectMake(107, 330, 196, 20);
        btnYelp.frame = CGRectMake(100, 362, 115, 25);
        viewbar1.frame = CGRectMake(6, 400, 98, 1);
        lbldiscription.frame = CGRectMake(112, 388, 100, 20);
        viewbar2.frame = CGRectMake(216, 400, 100, 1);
        webDiscription.frame = CGRectMake(6, 412, 308, 50);
        btnWebView.frame = CGRectMake(6, 412, 308, 50);
        viewWeb.frame = CGRectMake(8, 580, 304, 448);
        frameMap=viewMapView.frame;
    }
    else
    {
        
        lblName.frame = CGRectMake(0, 68, 320, 32);
        viewMapView.frame = CGRectMake(6, 102, 308, 125);
        imvPhone.frame = CGRectMake(50, 234, 26, 26);
        lblDot1.frame = CGRectMake(84, 236, 5, 21);
        btnPhoneNum.frame = CGRectMake(100, 236, 196, 20);
        imvLink.frame = CGRectMake(50, 262, 26, 26);
        lblDot2.frame = CGRectMake(84, 264, 5, 21);
        btnWebsite.frame = CGRectMake(100, 263, 196, 20);
        btnYelp.frame = CGRectMake(100, 292, 115, 25);
        viewbar1.frame = CGRectMake(6, 330, 98, 1);
        lbldiscription.frame = CGRectMake(116, 318, 100, 20);
        viewbar2.frame = CGRectMake(216, 330, 100, 1);
        webDiscription.frame = CGRectMake(6, 340, 308, 50);
        btnWebView.frame = CGRectMake(6, 340, 308, 50);
        viewWeb.frame = CGRectMake(10, 500, 300, 360);
        btnTickets.frame = CGRectMake(8, 400, 153, 30);
        btnShare.frame = CGRectMake(161, 400, 153, 30);
        
        frameMap=viewMapView.frame;
        
    }

    segUserControl.hidden=YES;
    segMapControl.hidden=YES;
    
    
    [segMapControl addTarget:self
                      action:@selector(changeMapMode:)
            forControlEvents:UIControlEventValueChanged];
    
    [segUserControl addTarget:self
                      action:@selector(changeAsUserWant:)
            forControlEvents:UIControlEventValueChanged];

    isMap=YES;
    isFullNot=YES;

    [self mapUpdate];
    lblName.text=locationDetail.strName;
    //ashu 28-5-15
    NSMutableString *stringts = [NSMutableString stringWithString:locationDetail.strPhone];
    [stringts insertString:@"(" atIndex:0];
    [stringts insertString:@")" atIndex:4];
    [stringts insertString:@" " atIndex:5];
    [stringts insertString:@"-" atIndex:9];
    NSString *strPhone = stringts;
    
    [btnPhoneNum setTitle:strPhone forState:UIControlStateNormal];
    [btnWebsite setTitle:locationDetail.strWebsite forState:UIControlStateNormal];
    
    [webDiscription loadHTMLString:[NSString stringWithFormat:@"<html><body>%@</body></html>",locationDetail.strDescription] baseURL:nil];
    [webLongDes loadHTMLString:[NSString stringWithFormat:@"<html><body>%@</body></html>",locationDetail.strDescription] baseURL:nil];
    
    if ([locationDetail.strYelpLink isEqualToString:@""])
    {
        btnYelp.hidden=YES;
    }
    else
    {
      btnYelp.hidden=YES;
    }
    if ([locationDetail.strPhone isEqualToString:@""])
    {
        imvPhone.hidden=YES;
        lblDot1.hidden=YES;
        btnPhoneNum.hidden=YES;
    }
    else
    {
        imvPhone.hidden=NO;
        lblDot1.hidden=NO;
        btnPhoneNum.hidden=NO;
    }
    
    if ([locationDetail.strWebsite isEqualToString:@""])
    {
        imvLink.hidden=YES;
        lblDot2.hidden=YES;
        btnWebsite.hidden=YES;
       
        if (IS_IPHONE_5)
        {
            viewMapView.frame = CGRectMake(6, 115, 308, 190);
            imvPhone.frame = CGRectMake(58, 320, 26, 26);
            lblDot1.frame = CGRectMake(92, 321, 5, 21);
            btnPhoneNum.frame = CGRectMake(107, 322, 196, 20);
            frameMap=viewMapView.frame;

        }
        else
        {
        
            viewMapView.frame = CGRectMake(6, 102, 308, 165);
            imvPhone.frame = CGRectMake(50, 272, 26, 26);
            lblDot1.frame = CGRectMake(84, 275, 5, 21);
            btnPhoneNum.frame = CGRectMake(100, 275, 196, 20);
            frameMap=viewMapView.frame;
        }

    }
    else
    {
        imvLink.hidden=NO;
        lblDot2.hidden=NO;
        btnWebsite.hidden=NO;
    }
    haveAlreadyReceivedCoordinates=NO;
    
   
}


- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
    if (haveAlreadyReceivedCoordinates) {
        return;
    }
    canAccessLocation=YES;
    haveAlreadyReceivedCoordinates=YES;
    strLatitude = [NSString stringWithFormat:@"%0.06f",newLocation.coordinate.latitude];
    strLongitude = [NSString stringWithFormat:@"%0.06f",newLocation.coordinate.longitude];
    
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
}


-(void)changeMapMode:(id)sender
{
    
    UISegmentedControl *segmentedControl = (UISegmentedControl *)sender;
    if (segmentedControl.selectedSegmentIndex==0) {
        isMap=YES;
    }
    else
    {
        isMap=NO;
    }
    [self mapUpdate];
}

-(void)changeAsUserWant:(id)sender
{
    
    UISegmentedControl *segmentedControl = (UISegmentedControl *)sender;
    
    if (segmentedControl.selectedSegmentIndex==0) {
          routeView.image=nil;
        routeView.hidden=YES;
        [mpLoc removeAnnotations:[mpLoc annotations]];
        [self mapUpdate];
    }
    else
    {
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
        [locationManager startUpdatingLocation];
        
        haveAlreadyReceivedCoordinates=NO;
        
        routeView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, mpLoc.frame.size.width, mpLoc.frame.size.height)];
        routeView.userInteractionEnabled = NO;
        [mpLoc addSubview:routeView];

        if ([RWUtils isConnectedToInternet])
        {
            
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(getDirectionFromUser) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }
}




-(void)mapUpdate
{
    HUD.hidden=YES;
    mpLoc.delegate=self;
	
    if (isMap)
    {
         mpLoc.mapType=MKMapTypeStandard;
    }
    else
    {
        mpLoc.mapType=MKMapTypeHybrid;
    }
    
    
	NSMutableArray* annotations=[[NSMutableArray alloc] init];
    
        CLLocationCoordinate2D theCoordinate;
        theCoordinate.latitude = [locationDetail.strLatitude floatValue];
        theCoordinate.longitude = [locationDetail.strLongitude floatValue];
        RWAnnotationData* myAnnotation=[[RWAnnotationData alloc] init];
        myAnnotation.coordinate=theCoordinate;
        myAnnotation.title=locationDetail.strName;
    myAnnotation.identity=1;
        myAnnotation.subtitle=[NSString stringWithFormat:@"%@, %@, %@, %@, %@ ",locationDetail.strAddress,locationDetail.strCity,locationDetail.strState,locationDetail.strZipcode , locationDetail.strCountry];
        [annotations addObject: myAnnotation];
        
    
    [mpLoc addAnnotations:annotations];
    MKMapRect flyTo = MKMapRectNull;
	for (id <MKAnnotation> annotation in annotations) {
		NSLog(@"fly to on");
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
        if (MKMapRectIsNull(flyTo)) {
            flyTo = pointRect;
        }
        else
        {
            flyTo = MKMapRectUnion(flyTo, pointRect);
			       
        }
        [mpLoc selectAnnotation:annotation animated:YES];
    }
    mpLoc.visibleMapRect = flyTo;
    
}

-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
    MKPinAnnotationView *pinView = nil;
    
    
    
    if([(RWAnnotationData*)annotation identity] == 1)
    {
        if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
                                         initWithAnnotation:annotation reuseIdentifier:@"com.invasivecode.pin"];
        pinView.pinColor =MKPinAnnotationColorGreen;
        pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
        NSLog(@"show");
        
    }
    else
    {
		pinView = (MKPinAnnotationView *)[mpLoc dequeueReusableAnnotationViewWithIdentifier:@"com.invasivecode.pin"];
		if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
                                         initWithAnnotation:annotation reuseIdentifier:@"com.invasivecode.pin"];
        
        
        pinView.pinColor =MKPinAnnotationColorRed ;
		pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
        NSLog(@"hide");
        
    }
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 26, 26);
    UIImage *btnImage = [UIImage imageNamed:@"arrow_select.png"];
    [btn setImage:btnImage forState:UIControlStateNormal];
    
    pinView.rightCalloutAccessoryView = btn;
    
  
    l1=[[UILabel alloc] init];
    l1.frame=CGRectMake(20, -10, 150, 90);
    l1.layer.cornerRadius =4.0;
    l1.layer.masksToBounds = YES;
   
    l1.backgroundColor = [UIColor whiteColor];
    l1.numberOfLines = 6;
   l1.text  = [NSString stringWithFormat:@" School:%@\n Start:%@\n End:%@",locationDetail.strSchoolname ,locationDetail.strStartDate,locationDetail.strEndDate];
    l1.font=[UIFont fontWithName:@"Helvetica" size:(10.0)];
    [l1 sizeToFit];
   
    [pinView addSubview:l1];
  
    l1.hidden = NO;
	return pinView;
    
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    
    NSString *add =locationDetail.strAddress;
    add =[add stringByReplacingOccurrencesOfString:@"\n"
                                        withString:@""];
    add =[add stringByReplacingOccurrencesOfString:@"\r"
                                        withString:@""];
    add =[add stringByReplacingOccurrencesOfString:@" "
                                        withString:@"+"];
   
   NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"comgooglemaps://?q=%@&center=%f,%f&zoom=50",add,[locationDetail.strLatitude floatValue],[locationDetail.strLongitude floatValue]]];
 
    if (![[UIApplication sharedApplication] canOpenURL:url]) {
        NSLog(@"Google Maps app is not installed");
           [[[UIAlertView alloc] initWithTitle:@"" message:@"please installed Google Maps app " delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        //left as an exercise for the reader: open the Google Maps mobile website instead!
    } else {
        [[UIApplication sharedApplication] openURL:url];
    }

}

-(IBAction)CrossBtbClicked:(id)sender{
    
}
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)getCall:(id)sender{
    
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"]) {
        [[UIApplication sharedApplication]
         openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",locationDetail.strPhone ]]];
    }else{
        
        [[[UIAlertView alloc]initWithTitle:@"Message" message:@"Calling not supported" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
    }
    
}
-(IBAction)gotoWebPage:(id)sender
{
    if ([RWUtils isConnectedToInternet]) {
        
        NSString *webSiteUrl = locationDetail.strWebsite;
        if ([webSiteUrl rangeOfString:@"http://"].location==NSNotFound) {
            
            webSiteUrl = [NSString stringWithFormat:@"http://%@",webSiteUrl];
        }
        [[UIApplication sharedApplication]
         openURL:[NSURL URLWithString:webSiteUrl]];
    }
    else
    {
        [RWUtils alertForNoInternetConnection];
    }
   
}
-(IBAction)gotoSettingPage:(id)sender
{
    [self performSegueWithIdentifier:@"gotoSettingPageFromDetails" sender:nil];
}


-(IBAction)gotoReviewYelpPage:(id)sender
{

    if ([RWUtils isConnectedToInternet]) {
        NSString *paymentUrl = [locationDetail.strSocial_link stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        if (paymentUrl  != nil) {
              [[UIApplication sharedApplication] openURL:[NSURL URLWithString:paymentUrl]];
            
        } else{
            
          
            [[[UIAlertView alloc] initWithTitle:@"" message:@"No yelpme Link Available" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        }
    }
    else{
        [RWUtils alertForNoInternetConnection];
    }
    
    
    
}






-(IBAction)openWebView:(id)sender
{viewWeb.hidden=NO;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if (IS_IPHONE_5) {
        webDiscription.frame = CGRectMake(6, 568, 308, 60);
        btnWebView.frame = CGRectMake(6, 568, 308, 60);
    }
    else{
        webDiscription.frame = CGRectMake(6, 480, 308, 60);
        btnWebView.frame = CGRectMake(6, 480, 308, 60);

    }
      [UIView commitAnimations];
    
    NSTimer *tim=[[NSTimer alloc]init];
    tim=[NSTimer scheduledTimerWithTimeInterval:0.0 target:self selector:@selector(initialDelayEnded1) userInfo:nil repeats:NO];
}


-(IBAction)gotoFullScreen:(id)sender
{
        if (isFullNot)
        {
        btnWebView.hidden=YES;
        webDiscription.hidden=YES;
        isFullNot=NO;
        segMapControl.hidden=NO;
        segUserControl.hidden=NO;
        lineColor = [UIColor blueColor];
        [btnFullScreen setImage:[UIImage imageNamed:@"exitFull_screen.png"] forState:UIControlStateNormal];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        if (IS_IPHONE_5)
        {
            viewMapView.frame = CGRectMake(6, 68, 308, 450);
        }
        else
        {
            viewMapView.frame = CGRectMake(6, 68, 308, 365);
           }
        [UIView commitAnimations];
    }
    else
    {
        [segUserControl setSelectedSegmentIndex:0];
        
        btnWebView.hidden=NO;
        webDiscription.hidden=NO;
        isFullNot=YES;
        segMapControl.hidden=YES;
        segUserControl.hidden=YES;
         lineColor = [UIColor clearColor];

        [btnFullScreen setImage:[UIImage imageNamed:@"Full_screen.png"] forState:UIControlStateNormal];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        if (IS_IPHONE_5)
        {
             viewMapView.frame = frameMap;
        }
        else
        {
            viewMapView.frame = frameMap;
        }
        [UIView commitAnimations];
    }
    
}



-(IBAction)closeWebView:(id)sender
{
   [UIView animateWithDuration:0.5 animations:^{
       if (IS_IPHONE_5) {
          viewWeb.frame = CGRectMake(6, 580, 308, 360);
       }else
       {
            viewWeb.frame = CGRectMake(6, 500, 308, 360);
           
       }
       

           }];
    
    NSTimer *tim=[[NSTimer alloc]init];
    tim=[NSTimer scheduledTimerWithTimeInterval:0.0 target:self selector:@selector(initialDelayEnded2) userInfo:nil repeats:NO];
    

}


-(void)initialDelayEnded1 {
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    if (IS_IPHONE_5) {
          viewWeb.frame = CGRectMake(6, 80, 308, 448);
    }
    else{
         viewWeb.frame = CGRectMake(6, 76, 308, 360);
    }
   
    [UIView commitAnimations];
    
 }
-(void)initialDelayEnded2 {
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    if (IS_IPHONE_5)
    {
        webDiscription.frame = CGRectMake(6, 410, 308, 60);
        btnWebView.frame = CGRectMake(6, 410, 308, 60);
    }
    else
    {
        webDiscription.frame = CGRectMake(6, 340, 308, 50);
        btnWebView.frame = CGRectMake(6, 340, 308, 50);
    }
    
        [UIView commitAnimations];
    
}


-(void)getDirectionFromUser
{
    
    Place* office = [[Place alloc] init];
    Place* home = [[Place alloc] init];
    home.latitude=[strLatitude doubleValue];
    home.longitude=[strLongitude doubleValue];

    
    CLLocationCoordinate2D theCoordinate;
    theCoordinate.latitude = [strLatitude floatValue];
    theCoordinate.longitude = [strLongitude floatValue];
    NSMutableArray* annotations=[[NSMutableArray alloc] init];
    RWAnnotationData* myAnnotation=[[RWAnnotationData alloc] init];
    myAnnotation.coordinate=theCoordinate;
    myAnnotation.title=@"Current User";
    myAnnotation.subtitle=@"I am here";
    
    [annotations addObject: myAnnotation];
    [mpLoc addAnnotations:annotations];
  
    office.latitude = [locationDetail.strLatitude floatValue];
    office.longitude = [locationDetail.strLongitude floatValue];
    if (canAccessLocation)
    {
        [self showRouteFrom:home to:office];
    }
    else
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"We need to know your Current Location. \n To re-enable, please go to Settings and turn on Location Service for this app." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
         [segUserControl setSelectedSegmentIndex:0];
    }
    
}

- (NSArray *)decodePolyLine:(NSMutableString *)encoded {
    [encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\"
                                options:NSLiteralSearch
                                  range:NSMakeRange(0, [encoded length])];

	[encoded replaceOccurrencesOfString:@"points:\"" withString:@""
                                options:NSLiteralSearch
                                  range:NSMakeRange(0, [encoded length])];

    NSInteger len = [encoded length];
    NSInteger index = 0;
    NSMutableArray *listCoordinates = [[NSMutableArray alloc] init];
    NSInteger lat=0;
    NSInteger lng=0;
    while (index < len - 1) {
        NSInteger b;
        NSInteger shift = 0;
        NSInteger result = 0;
        do {
			b = [encoded characterAtIndex:index++] - 63;
			result |= (b & 0x1f) << shift;
			shift += 5;
        } while (b >= 0x20);
        NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += dlat;
        shift = 0;
        result = 0;
        do {
			b = [encoded characterAtIndex:index++] - 63;
			result |= (b & 0x1f) << shift;
			shift += 5;
        } while (b >= 0x20);
        NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lng += dlng;
        NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
        NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];
        CLLocation *loc = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
		[listCoordinates addObject:loc];
    }

    return [NSArray arrayWithArray:listCoordinates];
}


-(NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t {
	NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
	NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];

	NSString* apiUrlStr = [NSString stringWithFormat:@"http://maps.google.com/maps?output=dragdir&saddr=%@&daddr=%@", saddr, daddr];
	NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
	NSLog(@"api url: %@", apiUrl);
    NSError* error = nil;
    NSString* apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
       //	NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl];

    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"points:\\\"([^\\\"]*)\\\""
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:nil];
    NSRange rangeOfFirstMatch = [regex rangeOfFirstMatchInString:apiResponse options:0 range:NSMakeRange(0, [apiResponse length])];
    if (NSEqualRanges(rangeOfFirstMatch, NSMakeRange(NSNotFound, 0))) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[[UIAlertView alloc]initWithTitle:@"Message" message:@"Couldn't find any Direction" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
            
        });
        return 0;
    }
    NSString *encodedPoints = [apiResponse substringWithRange:rangeOfFirstMatch];
	return [self decodePolyLine:[encodedPoints mutableCopy]];
}

-(void) centerMap {
	MKCoordinateRegion region;

	CLLocationDegrees maxLat = -90;
	CLLocationDegrees maxLon = -180;
	CLLocationDegrees minLat = 90;
	CLLocationDegrees minLon = 180;
	for(int idx = 0; idx < routes.count; idx++)
	{
		CLLocation* currentLocation = [routes objectAtIndex:idx];
		if(currentLocation.coordinate.latitude > maxLat)
			maxLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.latitude < minLat)
			minLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.longitude > maxLon)
			maxLon = currentLocation.coordinate.longitude;
		if(currentLocation.coordinate.longitude < minLon)
			minLon = currentLocation.coordinate.longitude;
	}
	region.center.latitude     = (maxLat + minLat) / 2;
	region.center.longitude    = (maxLon + minLon) / 2;
	region.span.latitudeDelta  = maxLat - minLat;
	region.span.longitudeDelta = maxLon - minLon;

	[mpLoc setRegion:region animated:YES];
}

-(void) showRouteFrom: (Place*) f to:(Place*) t{

	if(routes) {
		[mpLoc removeAnnotations:[mpLoc annotations]];

	}
	RWAnnotationData* from = [[RWAnnotationData alloc] initWithPlace:f];
	RWAnnotationData* to = [[RWAnnotationData alloc] initWithPlace:t];

	[mpLoc addAnnotation:from];
	[mpLoc addAnnotation:to];

	routes = [self calculateRoutesFrom:from.coordinate to:to.coordinate];

	 
    if (routes.count==0 || routes==nil) {
        
    }
    else{
        [self updateRouteView];
        
        [self centerMap];
    }
    
}

-(void) updateRouteView {
	CGContextRef context = 	CGBitmapContextCreate(nil,
												  routeView.frame.size.width,
												  routeView.frame.size.height,
												  8,
												  4 * routeView.frame.size.width,
												  CGColorSpaceCreateDeviceRGB(),
												  kCGImageAlphaPremultipliedLast);

	CGContextSetStrokeColorWithColor(context, lineColor.CGColor);
	CGContextSetRGBFillColor(context, 0.0, 0.0, 1.0, 1.0);
	CGContextSetLineWidth(context, 3.0);

	for(int i = 0; i < routes.count; i++) {
		CLLocation* location = [routes objectAtIndex:i];
		CGPoint point = [mpLoc convertCoordinate:location.coordinate toPointToView:routeView];

		if(i == 0) {
			CGContextMoveToPoint(context, point.x, routeView.frame.size.height - point.y);
		} else {
			CGContextAddLineToPoint(context, point.x, routeView.frame.size.height - point.y);
		}
	}

	CGContextStrokePath(context);

	CGImageRef image = CGBitmapContextCreateImage(context);
	UIImage* img = [UIImage imageWithCGImage:image];

	routeView.image = img;
	CGContextRelease(context);

}

#pragma mark mapView delegate functions
- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
	routeView.hidden = YES;
    NSLog(@"1");
    
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    if (segUserControl.selectedSegmentIndex==0) {
        routeView.hidden = YES;
        NSLog(@"2");
    }
    else{
        [self updateRouteView];
        routeView.hidden = NO;
        NSLog(@"3");
        [routeView setNeedsDisplay];
    }
	
}


-(IBAction)btnTicketDidClicked:(id)sender{
    
    
    
    if ([RWUtils isConnectedToInternet]) {
        NSString *Url = [locationDetail.strTicketUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        if ([Url isEqualToString:@""]) {
            [[[UIAlertView alloc] initWithTitle:@"" message:@"No Tickets are Available" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        } else{
           
              NSURL *myURL = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@",locationDetail.strTicketUrl]];
            [[UIApplication sharedApplication] openURL:myURL];
        }
    }
    else{
        [RWUtils alertForNoInternetConnection];
    }

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)shareBtnPressed:(UIButton *)sender{
    
    
    
    
    UIPasteboard *pb = [UIPasteboard generalPasteboard];
    // This code assumes that you have created the outlet for UITextField as 'textField1'. // Update the below code, if you have given different name
    [pb setString:[NSString stringWithFormat:@"EventName:%@\nAddress:%@\nCity:%@\nStart Date:%@\nEnd Date:%@\nSchool Name:%@",locationDetail.strName,locationDetail.strAddress,locationDetail.strCity,locationDetail.strStartDate,locationDetail.strEndDate,locationDetail.strSchoolname]];
     [[[UIAlertView alloc] initWithTitle:@"" message:@"The event information has been copied for pasting into your favorite social media app." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    
}

-(void)handleSingleTapGesture:(UITapGestureRecognizer *)tapGestureRecognizer{
    if (l1.isHidden) {
        l1.hidden = NO;

    }
    else{
        l1.hidden = YES;
    }
}


@end
