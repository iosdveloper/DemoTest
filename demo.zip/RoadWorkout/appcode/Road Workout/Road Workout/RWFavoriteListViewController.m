//
//  RWFavoriteListViewController.m
//  Road Workout
//
//  Created by user on 14/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWFavoriteListViewController.h"
#import "RWLocationDetailViewController.h"
#import "RWPlaceData.h"
#import "RWUtils.h"
#import "RWPlaceCell.h"

@interface RWFavoriteListViewController ()

@end

@implementation RWFavoriteListViewController
@synthesize arrFavoriteList;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden=YES;
    
    NSString *strLocationDetail=URL_LOCATION_DETAIL;
    urlLocationDetail=[[NSURL alloc]initWithString:strLocationDetail];
    
    UIImage *searchFieldImage = [UIImage imageNamed:@"searchBar_bg.png"];
    [searchBarCategories setBackgroundImage:[UIImage imageNamed:@"searchBar_bg.png"]];
    [searchBarCategories setSearchFieldBackgroundImage:searchFieldImage forState:UIControlStateNormal];
    
    searchBarCategories.delegate = self;
    searchBarCategories.placeholder = @"Favorite Place Name";

    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)
        
        
        if(!isAtLeast7)
            
            
            if(!isAtLeast7)
            {
                
                UIImage* imageDone = [UIImage imageNamed:@"btn_back.png"];
                CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
                UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
                [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
                [doneBtn addTarget:self action:@selector(back:)
                  forControlEvents:UIControlEventTouchUpInside];
                
                btnBack =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
                
                
                self.navigationItem.leftBarButtonItem = btnBack;
                self.navigationItem.hidesBackButton = YES;
                
                
                
                [navBar pushNavigationItem:self.navigationItem animated:NO];
                
                navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
                
                self.navigationItem.title=@"Favorite List";
                
                if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
                {
                    [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                    [UIColor whiteColor], UITextAttributeTextColor,
                                                    [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                                    nil]];
                    [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
                }
                
            }
    
    
    

    
    
    // Do any additional setup after loading the view.
    arrCities=[[NSMutableArray alloc]init];
    arrHistoryDetails = [[NSMutableArray alloc]init];
    arrClassData=[[NSMutableArray alloc]init];
    arrSearchData = [[NSMutableArray alloc]init];
    [self updateArrayWithCities];
    
}

-(void)updateArrayWithCities
{
  
    for (int i = 0; i<[arrFavoriteList count]; i++)
    {
        RWPlaceData *historyHolder = [[RWPlaceData alloc]init];
        historyHolder = [arrFavoriteList objectAtIndex:i];
        
        [arrCities addObject: historyHolder.strPlaceCity];
    }
    ///////////////
    
    
    NSArray *copy = [arrCities copy];
    NSInteger index = [copy count] - 1;
    for (id object in [copy reverseObjectEnumerator]) {
        if ([arrCities indexOfObject:object inRange:NSMakeRange(0, index)] != NSNotFound) {
            [arrCities removeObjectAtIndex:index];
        }
        index--;
    }
    
    
    
    for(int i=0; i<[arrCities count]; i++)
    {
        NSMutableArray *arrData = [[NSMutableArray alloc]init];
        for(int j = 0; j<[arrFavoriteList count]; j++)
        {
            RWPlaceData *historyHolder = [[RWPlaceData alloc]init];
            historyHolder = [arrFavoriteList objectAtIndex:j];
           
            NSString *strDate1 = [arrCities objectAtIndex:i];
            
            NSString *strDate2 = historyHolder.strPlaceCity;
            
            if ([strDate1 isEqualToString:strDate2])
            {
                [arrData addObject:historyHolder];
            }
        }
        [arrHistoryDetails addObject:arrData];
        NSLog(@"%@", arrHistoryDetails);
    }
    
    [tblFavList reloadData];

}




-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
}

-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (searchBarCategories.text.length>0) {
        return 1;
    }
    else
    {
         return [arrCities count];
    }
   
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (searchBarCategories.text.length>0)
    {
        return [arrSearchData count];
    }
    else
    {
        return [[arrHistoryDetails objectAtIndex:section] count];
    }
      NSLog(@"%d", [[arrHistoryDetails objectAtIndex:section] count]);
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    RWPlaceCell *cell;
    RWPlaceData *placeData;
    if (searchBarCategories.text.length>0)
    {
       placeData= [arrSearchData objectAtIndex:indexPath.row];
    }
    else
    {
        placeData= [[arrHistoryDetails objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    }

    
    
        if(isAtLeast7)
    {
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    else
    {
        cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" ];
    }
    
    if (cell == nil) {
        cell = [[RWPlaceCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    
    [tableView setSeparatorColor:[UIColor grayColor]];
    cell.lblAddress.textColor = [UIColor darkTextColor];
    cell.lblAddress.text = placeData.strPlaceName;
    return cell;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (searchBarCategories.text.length>0) {
        return nil;
    }
    else
    {
        return [arrCities objectAtIndex:section];
    }
    
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    RWPlaceData *placeData;
    if(searchBarCategories.text.length>0)
    {
        placeData = [arrSearchData objectAtIndex:indexPath.row];
    }
    else
    {
        placeData = [[arrHistoryDetails objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    }

   
    strLocationId=placeData.strLocationid;
    
    if([RWUtils isConnectedToInternet])
    {
        HUD=[[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        [HUD showWhileExecuting:@selector(gotoLocationDetail) onTarget:self withObject:nil animated:TRUE];
    
    }
    else
    {
        [self getLocationDetailsFromDatabase];
    }
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSString *sectionTitle = [self tableView:tableView titleForHeaderInSection:section];
    
    if (searchBarCategories.text.length>0 || [[arrHistoryDetails objectAtIndex:section]count] == 0) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
        [view setBackgroundColor:[UIColor clearColor]];
        
        return view;
    }
    else
    {
        UILabel *lbltitle=[[UILabel alloc]initWithFrame:CGRectMake(8, 1, 200, tableView.sectionHeaderHeight)];
        lbltitle.text=sectionTitle;
        [lbltitle setTextColor:[UIColor blackColor]];
        lbltitle.backgroundColor=[UIColor clearColor];
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, tableView.sectionHeaderHeight)];
        [view setBackgroundColor:[UIColor colorWithRed:211/255.0 green:211/255.0 blue:211/255.0 alpha:1]];
        [view addSubview:lbltitle];
        return  view;
    }
}



- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        RWPlaceData *placeData = [[arrHistoryDetails objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        strfavLocationID = placeData.strLocationid;
        if([RWUtils isConnectedToInternet])
        {
            
            [[arrHistoryDetails objectAtIndex:indexPath.section] removeObjectAtIndex:indexPath.row];
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(deleteFavorite:) onTarget:self withObject:placeData.strLocationid animated:TRUE];
            
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
            
            
        }

    }
}

-(void)deleteFavorite:(NSString *)locationId{
    
    NSString *strDeleteFavoriteUrl = URL_DELETE_FAVORITE;
    NSURL *urlDeleteFavorite = [NSURL URLWithString:strDeleteFavoriteUrl];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlDeleteFavorite];
    [request setPostValue:locationId forKey:@"locationid"];
    [request setPostValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"] forKey:@"userid"];
    
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getDeleteFavoriteFail:)];
    [request setDidFinishSelector:@selector(getDeleteFavoriteSuccess:)];
    [request startSynchronous];
    
}



-(void)getDeleteFavoriteFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}




-(void)getDeleteFavoriteSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                        
                               isDelete=YES;
                               [tblFavList reloadData];

                           });
             [self performSelectorInBackground:@selector(deleteFromFavDatabase) withObject:nil];
            
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}

-(void)deleteFromFavDatabase
{
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    query = [NSString stringWithFormat:@"Delete FROM RoadWorkOutFavroiteList where favLocationId = \"%@\" and favUserId = \"%@\"", strfavLocationID,[[NSUserDefaults standardUserDefaults] valueForKey:@"userid"]];
    
    @try
    {
        [db open];
        if ([db executeUpdate:query])
        {
            NSLog(@"success in Deletion");
            
        }
        else
        {
            NSLog(@"error in Deletion");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
}






-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
   
       RWLocationDetailViewController *detailViewController = (RWLocationDetailViewController*)[segue destinationViewController];
    detailViewController.locationDetail = locationDetail;
}



-(void)gotoLocationDetail
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlLocationDetail];
    [request setPostValue:strLocationId forKey:@"locationid"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(getLocationDetailsFail:)];
    [request setDidFinishSelector:@selector(getLocationDetailsSuccess:)];
    [request startSynchronous];
    
}

-(void)getLocationDetailsFail:(ASIFormDataRequest *)request
{
    
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)getLocationDetailsSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    SBJSON *parser = [[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    
    NSMutableDictionary *responseData = [results valueForKey:@"response"];
    if(responseData)
    {
        NSString *status=[responseData valueForKey:@"error_code"];
        
        if ([status isEqualToString:@"0"])
        {
            NSMutableDictionary *arrCategoryList=[responseData valueForKey:@"location"];
            
            locationDetail=[[RWPlaceDetail alloc]init];
            locationDetail.strLocationid=[arrCategoryList valueForKey:@"locationid"];
            locationDetail.strName=[arrCategoryList valueForKey:@"name"];
            locationDetail.strGenre=[arrCategoryList  valueForKey:@"genre"];
            locationDetail.strDescription=[arrCategoryList  valueForKey:@"description"];
            locationDetail.strWebsite=[arrCategoryList  valueForKey:@"website"];
            locationDetail.strPhone=[arrCategoryList valueForKey:@"phone"];
            locationDetail.strZipcode=[arrCategoryList valueForKey:@"zipcode"];
            locationDetail.strAddress=[arrCategoryList valueForKey:@"address"];
            locationDetail.strCity=[arrCategoryList  valueForKey:@"city"];
            locationDetail.strState=[arrCategoryList  valueForKey:@"state"];
            locationDetail.strContinent=[arrCategoryList valueForKey:@"continent"];
            locationDetail.strCountry=[arrCategoryList  valueForKey:@"country"];
            locationDetail.strLatitude=[arrCategoryList  valueForKey:@"latitude"];
            locationDetail.strLongitude=[arrCategoryList valueForKey:@"longitude"];
            locationDetail.strYelpLink=[arrCategoryList valueForKey:@"yelp_link"];
            locationDetail.strSchoolname =[arrCategoryList valueForKey:@"school_name"];
            locationDetail.strStartDate =[arrCategoryList valueForKey:@"start_date_time"];
             locationDetail.strEndDate=[arrCategoryList valueForKey:@"end_date_time"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self performSegueWithIdentifier:@"favItem" sender:self];
            });
        }
        else
        {
            NSString *strErrorMessage = [responseData valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [HUD hide];
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
            
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
    
}

-(void)getLocationDetailsFromDatabase
{
    
    
    if (!db)
    {
        db = [[FMDatabase alloc]initWithPath:[RWUtils getDatabasePathFromName:@"RoadWorkOutNewData"]];
    }
    
    NSString *query;
    
    query = [NSString stringWithFormat:@"Select * FROM RoadWorkOutLocation where locId = \"%@\"", strLocationId];
    
    @try
    {
        [db open];
        if ([db executeQuery:query])
        {
            FMResultSet *resultSet = [db executeQuery:query];
            
            while([resultSet next])
            {
                locationDetail=[[RWPlaceDetail alloc]init];
                locationDetail.strLocationid=[resultSet stringForColumn:@"locId"];
                locationDetail.strName=[resultSet stringForColumn:@"locName"];
                locationDetail.strGenre=[resultSet stringForColumn:@"locCategoryName"];
                locationDetail.strDescription=[resultSet stringForColumn:@"locDescription"];
                locationDetail.strWebsite=[resultSet stringForColumn:@"locWebsite"];
                locationDetail.strPhone=[resultSet stringForColumn:@"locPhone"];
                locationDetail.strZipcode=[resultSet stringForColumn:@"locZipcode"];
                locationDetail.strAddress=[resultSet stringForColumn:@"locAddress"];
                locationDetail.strCity=[resultSet stringForColumn:@"locCity"];
                locationDetail.strState=[resultSet stringForColumn:@"locState"];
                locationDetail.strContinent=[resultSet stringForColumn:@"locContinent"];
                locationDetail.strCountry=[resultSet stringForColumn:@"locCountry"];
                locationDetail.strLatitude=[resultSet stringForColumn:@"locLatitude"];
                locationDetail.strLongitude=[resultSet stringForColumn:@"locLongitude"];
                locationDetail.strYelpLink=[resultSet stringForColumn:@"locYelpLink"];
                
                
            }
        }
        else
        {
            NSLog(@"error in insertation");
        }
        [db close];
    }
    @catch (NSException *e)
    {
        NSLog(@"%@",e);
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self performSegueWithIdentifier:@"favItem" sender:self];
    });
    
    
    
    
    
}



-(void)searchViewShouldBeginEditing:(UISearchBar *)searchBar
{

}

-(void)searchViewShouldSearchButtonClick:(UISearchBar *)searchBar searchText:(NSString *)searchText
{
    if (![searchBar.text isEqualToString:currentSearchText])
    {
        if(searchText.length == 0)
        {
            dispatch_async(dispatch_get_main_queue(), ^
            {
                [searchBarCategories resignFirstResponder];
            });
        }
        else
        {
            [arrSearchData removeAllObjects];
            
            for (RWPlaceData *contact in arrFavoriteList)
            {
                NSString *strName = [NSString stringWithFormat:@"%@", contact.strPlaceName];
                NSRange nameRange = [strName rangeOfString:searchText options:NSCaseInsensitiveSearch];
                
                if(nameRange.location != NSNotFound)
                {
                    [arrSearchData addObject:contact];
                }
                
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [tblFavList reloadData];
                       });
    }
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [self searchViewShouldBeginEditing:searchBar];
    
    for(id subview in [searchBar subviews])
    {
        if ([subview isKindOfClass:[UIButton class]]) {
            [subview setEnabled:YES];
        }
    }
    return YES;
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    if(searchBarCategories.text.length == 0)
    {
        [searchBarCategories resignFirstResponder];
    }
    
    [self searchViewShouldSearchButtonClick:searchBar searchText:searchBar.text];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [self.searchDisplayController.searchBar setText:@""];
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [tblFavList reloadData];
                   });
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
        [searchBar setShowsCancelButton:NO animated:YES];
        [searchBar resignFirstResponder];
        [self searchViewShouldSearchButtonClick:searchBar searchText:searchBar.text];
        
        if (![searchBar.text isEqualToString:currentSearchText])
        {
            currentSearchText = searchBar.text;
        }
  
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
       [searchBarCategories resignFirstResponder];
}



-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if([[arrHistoryDetails objectAtIndex:section]count] == 0 || searchBarCategories.text.length > 0)
    {
        return 0;
    }
    else
    {
        return tableView.sectionHeaderHeight;
    }
}

@end
