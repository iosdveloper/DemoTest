//
//  RWFavoriteListViewController.h
//  Road Workout
//
//  Created by user on 14/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RWPlaceDetail.h"
#import "MBProgressHUD.h"
#import "RWSeachBar.h"
@interface RWFavoriteListViewController : UIViewController<UISearchBarDelegate>{
    
    NSMutableArray *arrFavoriteList;
    NSMutableArray *arrCities;
    NSMutableArray *arrHistoryDetails;
    NSMutableArray *arrClassData;
    NSMutableArray *arrSearchData;

    
    IBOutlet RWSeachBar *searchBarCategories;

    RWPlaceDetail *locationDetail;
    MBProgressHUD *HUD;
    
    IBOutlet UIView *container;
    IBOutlet UITableView *tblFavList;
    IBOutlet UIBarButtonItem *btnBack;
    IBOutlet UINavigationBar *navBar;
    
    NSString *strLocationId;
    NSString *strfavLocationID;
    NSString *currentSearchText;
    
    NSURL *urlLocationDetail;
}
@property(nonatomic,retain)NSMutableArray *arrFavoriteList;
-(IBAction)back:(id)sender;
@end
