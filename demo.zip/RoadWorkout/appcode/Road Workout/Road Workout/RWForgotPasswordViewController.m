//
//  RWForgotPasswordViewController.m
//  Road Workout
//
//  Created by user on 09/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWForgotPasswordViewController.h"

@interface RWForgotPasswordViewController ()

@end

@implementation RWForgotPasswordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    btnSubmit.layer.cornerRadius = 4.0f;
    btnSubmit.layer.masksToBounds=YES;
	
    self.navigationController.navigationBarHidden=YES;
    
    NSString *strForgotPassword = URL_FORGOTPASSWORD;
    urlForgotPassword = [[NSURL alloc]initWithString:strForgotPassword];
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL isAtLeast7 = [version floatValue] >= 7.0;
    if(!isAtLeast7)

    
    if(!isAtLeast7)
    {
                
        UIImage* imageDone = [UIImage imageNamed:@"btn-cancel.png"];
        CGRect imgDoneframe = CGRectMake(0, 0, imageDone.size.width, imageDone.size.height);
        UIButton *doneBtn = [[UIButton alloc] initWithFrame:imgDoneframe];
        [doneBtn setBackgroundImage:imageDone forState:UIControlStateNormal];
        [doneBtn addTarget:self action:@selector(btnCancelClicked:)
          forControlEvents:UIControlEventTouchUpInside];
        
        btnCan =[[UIBarButtonItem alloc] initWithCustomView:doneBtn];
        
        
        self.navigationItem.leftBarButtonItem = btnCan;
        self.navigationItem.hidesBackButton = YES;
        
      
        
        [navBar pushNavigationItem:self.navigationItem animated:NO];
        
        navBar.backgroundColor=[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1];
        
        self.navigationItem.title=@"Forgot Password";
        
        if ([[UINavigationBar class] respondsToSelector:@selector(appearance)])
        {
            [navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                            [UIColor whiteColor], UITextAttributeTextColor,
                                            [UIFont fontWithName:@"HelveticaNeue" size:17.0], UITextAttributeFont,
                                            nil]];
            [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:79.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1]];
        }
        
    }

    

}



-(void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
}




-(IBAction)btnSubmitClicked:(id)sender
{
    BOOL isValid = YES;
    
    if (![Validate isValidEmailId:txtEmail.text])
    {
        [[[UIAlertView alloc]initWithTitle:@"" message:@"email is not valid" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil] show];
        isValid = NO;
    }
    if(isValid)
    {
        [txtEmail resignFirstResponder];
        [self setViewOnResignTextField];
        if([RWUtils isConnectedToInternet])
        {
            HUD=[[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            [HUD showWhileExecuting:@selector(forgotPassword) onTarget:self withObject:nil animated:TRUE];
        }
        else
        {
            [RWUtils alertForNoInternetConnection];
        }
    }
}

-(void)setViewOnResignTextField
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    if(!IS_IPHONE_5)
    {
        self.view.frame = CGRectMake(0, 0, 320, 480);
    }
    [UIView commitAnimations];
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if(!IS_IPHONE_5)
    {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];
        self.view.frame = CGRectMake(0, -10, 320, 480);
        [UIView commitAnimations];
    }
    
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(!IS_IPHONE_5)
    {
        [textField resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];
        self.view.frame = CGRectMake(0, 0, 320, 480);
        [UIView commitAnimations];
    }
    
    return YES;
}

-(void)forgotPassword
{
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:urlForgotPassword];
    
    [request setPostValue:txtEmail.text forKey:@"email"];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(requestForForgotPasswordFail:)];
    [request setDidFinishSelector:@selector(requestForForgotPasswordSuccess:)];
    [request startSynchronous];
}

-(void)requestForForgotPasswordFail:(ASIFormDataRequest *)request
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       [RWUtils alertForServerNotResponding];
                   });
}

-(void)requestForForgotPasswordSuccess:(ASIFormDataRequest *)request
{
    NSString *responseString = [request responseString];
    responseString = [[responseString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    SBJSON *parser=[[SBJSON alloc]init];
    
    NSDictionary *results = [parser objectWithString:responseString error:nil];
    NSMutableDictionary *responseDict = ((NSMutableDictionary *)[results objectForKey:@"response"]);
    
    if(responseDict)
    {
        NSString *status= [responseDict objectForKey:@"error_code"];
        
        if (![status isEqualToString:@"0"])
        {
            NSString *strErrorMessage = [responseDict valueForKey:@"error_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [[[UIAlertView alloc]initWithTitle:nil message:strErrorMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
        else
        {
            NSString *strSuccessMessage = [responseDict valueForKey:@"success_msg"];
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               [[[UIAlertView alloc]initWithTitle:nil message:strSuccessMessage delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil] show];
                           });
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^
                       {
                           [RWUtils alertForServerNotResponding];
                       });
    }
}

-(IBAction)btnCancelClicked:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtEmail resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
