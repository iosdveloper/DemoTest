//
//  RWSettingViewController.h
//  Road Workout
//
//  Created by user on 14/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import <MessageUI/MessageUI.h>

@interface RWSettingViewController : UIViewController
{
    
    MBProgressHUD *HUD;
    
    NSMutableArray *arrFavList;
    NSMutableArray *arrMyEvntList;
    
    IBOutlet UIImageView *imvBorder;
    IBOutlet UILabel *lblBorder;
    IBOutlet UIBarButtonItem *btnBack;
    IBOutlet UINavigationBar *navBar;
   
}

@property(nonatomic,strong) MBProgressHUD *hud;
-(IBAction)gotoFavoritePage:(id)sender;
-(IBAction)gotoChangePasswordPage:(id)sender;
-(IBAction)logout:(id)sender;
-(IBAction)back:(id)sender;
- (IBAction)gotoMyEvents:(id)sender;

@end
