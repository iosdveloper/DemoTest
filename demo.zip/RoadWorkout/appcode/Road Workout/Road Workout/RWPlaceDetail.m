//
//  RWPlaceDetail.m
//  Road Workout
//
//  Created by user on 16/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import "RWPlaceDetail.h"

@implementation RWPlaceDetail
@synthesize strLocationid,strAddress,strCity,strContinent,strCountry,strDescription,strGenre,strName,strPhone,strState,strWebsite,strZipcode,strLatitude,strLongitude,strYelpLink,strAddedOn,strUpdatedOn,strCategoryId,strDistance,strTicketUrl;

@end
