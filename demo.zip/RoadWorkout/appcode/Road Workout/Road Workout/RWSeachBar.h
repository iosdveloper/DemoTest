//
//  RWSeachBarView.h
//  Road Workout
//
//  Created by vishnu on 11/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWSeachBar : UISearchBar

@end
