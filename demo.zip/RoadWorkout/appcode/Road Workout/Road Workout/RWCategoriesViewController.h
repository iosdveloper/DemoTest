//
//  RWCategoriesViewController.h
//  Road Workout
//
//  Created by vishnu on 11/11/13.
//  Copyright (c) 2013 Aryavrat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RWSeachBar.h"
#import <CoreLocation/CoreLocation.h>
#import "MBProgressHUD.h"
#import "RWCategoryData.h"
#import "RWCategoryCell.h"
#import "RWLocationsViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "RWPlaceDetail.h"
#import "RWCityFilterDetails.h"
#import "MLTableAlert.h"

@interface RWCategoriesViewController : UIViewController<UISearchBarDelegate, CLLocationManagerDelegate,UITableViewDataSource,UITableViewDelegate>{

    
 
    NSString *strAddress;
    NSString *currentSearchText;
    NSString *strCatLatitude;
    NSString *strCatLongitude;
    NSString *strAddressName;
    NSString *strSchoolName;
    NSString *strCurrentCountry;
    NSString *strCurrentCity;
  
  
    NSURL *urlCategoryList;
    NSURL *urlLocationList;
    NSURL *urlSchoolList;
    NSURL *urlLocationData;
    
    NSMutableArray *arrCategoryData;
    NSMutableArray *arrCategoryName;
    NSMutableArray *arrClassData;
    NSMutableArray *arrSearchData;
    NSMutableArray *categoryList;
    NSMutableArray *locationList;
    NSMutableArray *arrLocationData;
    NSMutableArray *arrUpdateDate;
    NSMutableArray *arrCityList;
       
    RWPlaceDetail *locationDetail;
    MBProgressHUD *HUD;
    RWCategoryData *categoryListData;
    CLLocationManager *locationManager;
    
    IBOutlet RWSeachBar *searchBarLocation;
    IBOutlet RWSeachBar *searchBarCategories;
        
    IBOutlet UITableView *tblCategory;
    IBOutlet UITableView *tblSelectChoice;
    IBOutlet UITableView *tblCityAddress;
    
    IBOutlet UIBarButtonItem *btnUserLoc;
    IBOutlet UIBarButtonItem *btnSetting;
    IBOutlet UINavigationBar *navBar;
   
    IBOutlet UIButton *btnSelectChoice;
    
    IBOutlet UILabel *lblBorder;
    IBOutlet UILabel *lblCategory;
    
    IBOutlet UIView *viewTable;
    IBOutlet UIView *viewselectadd;
    IBOutlet UILabel *lblschoolnames;
    IBOutlet UIImageView *imvBorder;
    IBOutlet UIButton *btnAddEvent;
    IBOutlet UIButton *btnSchoollist;
    BOOL isLeftToRight;
    BOOL haveAlreadyReceivedCoordinates;
    NSMutableArray *arrSchool;
    
    
    int helpAddress;
    int strAddressTag;
    
    NSArray *arrAddressOption;
    
}
@property (strong, nonatomic) MLTableAlert *popUp;
-(IBAction)getCurrentUserLoaction:(id)sender;
-(IBAction)showGotoAddressPage:(id)sender;

-(IBAction)gotoSettingPage:(id)sender;
@end
